import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import locale from 'js/AwcLocalizationUtil';
import uwPropertyService from 'js/uwPropertyService';
import _ from 'lodash';
import $ from 'jquery';
import AwcQueryUtil from "js/AwcQueryUtil";
import soaService from 'soa/kernel/soaService';

var exports = {};
let localeText = "lgspQmsNewInspectionMessages";

export let pageLoaded = async ( data, ctx ) => {
    const interval = setInterval( async () => {
        if( data.a2CheckObject ) {
            clearInterval( interval );
    
            await AwcObjectUtil.getProperty( ctx.selected, "a2Id", true );
            let a2Id = ctx.selected.props.a2Id.dbValues[0];
            uwPropertyService.setDisplayValue( data.a2CheckObject, [ a2Id ] );
            uwPropertyService.setWidgetDisplayValue( data.a2CheckObject, [ a2Id ] );
            
            let createType = data.objCreateInfo.createType;
            let sampleType = "";
            let attrs = [];
            switch(createType){
                case "A2QSampleStaticRuntime"   : sampleType = "SampleStatic";      attrs = [ "a2Ac", "a2Re", "a2SampleSize" ];    break;
                case "A2QSampleAQLRuntime"      : sampleType = "SampleAQL";         attrs = [ "a2AQLLevel", "a2AcReLevel" ];       break;
                case "A2QSampleRangeRuntime"    : sampleType = "SampleRange";       attrs = [ "a2SampleRange" ];                   break;
                case "A2QAllSampleRuntime"      : sampleType = "SampleAll";         attrs = [ "a2Ac", "a2Re"  ];                   break;
                case "A2QVariableSampleRuntime" : sampleType = "SampleVariable";    attrs = [ "a2Ac", "a2Re"  ];                   break;
            }
            attrs.push( "a2SampleMethod" );
            uwPropertyService.setValue( data.a2SampleType, [ locale.getLocalizedText( "lgspQmsNewInspectionMessages", sampleType ) ] );
            await AwcObjectUtil.getProperties( ctx.selected, attrs );
    
            if( sampleType.includes( ctx.selected.props.a2SampleMethod.dbValue ) ) {
                for(const attr of attrs){
                    if(data.hasOwnProperty(attr)){
                        let value = ctx.selected.props[ attr ].uiValues[0];
                        uwPropertyService.setValue( data[ attr ], String( value ) );
                        uwPropertyService.setDisplayValue( data[ attr ], [ String( value ) ] );
                    }
                }
            }
        } else if( data.a2TargetRange ) {
            clearInterval( interval );
            let setProps = [ "a2Lsl", "a2Usl", "a2TargetValue", "a2TargetRange" ];
            await AwcObjectUtil.getProperties( ctx.selected, setProps );
            for( const prop of setProps ) {
                uwPropertyService.setValue( data[ prop ], String( ctx.selected.props[ prop ].dbValue ) );
                uwPropertyService.setDisplayValue( data[ prop ], [ String( ctx.selected.props[ prop ].dbValue ) ] );
            }
        }
    } );
}

let _AcReValidation = ( data ) => {
    if( String( data.a2Ac.dbValue ).includes( "." ) || String( data.a2Re.dbValue ).includes( "." ) || 
        data.a2SampleSize && String( data.a2SampleSize.dbValue ).includes( "." ) ) {
        return {
            result : false,
            errMsg : "dotInclude"
        };
    }

    if( data.a2Ac.dbValue > 100000 || data.a2Re.dbValue > 100000 || 
        data.a2SampleSize && data.a2SampleSize.dbValue > 100000 ) {
        return {
            result : false,
            errMsg : "overMaxSize"
        };
    }

    if( data.a2Ac.dbValue >= data.a2Re.dbValue ) {
        return {
            result : false,
            errMsg : "ACBig"
        };
    }
    return {
        result : true,
        errMsg : ""
    };
}

export let ApplyAction = async ( data, ctx ) => {
    if( data.a2AQLLevel && data.a2AcReLevel ) {
        let valArr = [ "a2AQLLevel", "a2AcReLevel" ];
        for( const target of valArr ) {
            if( !data[ target ].dbValue ) {
                AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, target + "Empty" ) );
                return false;
            }
        }
    }

    if( data.a2SampleRange ) {
        if( !data.a2SampleRange.dbValue ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "a2SampleRangeEmpty" ) );
            return false;
        }
    }

    let checkItem = ctx.selected;
    let createType = data.objCreateInfo.createType;
    
    if( data.a2Ac && data.a2Re ) {
        if( !_AcReValidation( data ).result ) {
            AwcNotificiationUtil.show("ERROR", locale.getLocalizedText( localeText, _AcReValidation( data ).errMsg ) );
            return;
        }
    }

    let attributes = ["a2SampleSize", "a2Ac", "a2Re", "a2AQLLevel", "a2AcReLevel", "a2SampleRange"];

    let attrValues = new Array();
    attrValues.push({a2CheckObject: checkItem.uid});
    for(const attr of attributes){
        if(data.hasOwnProperty(attr)){
            attrValues.push({[attr] : String(data[attr].dbValue)});
        }
    }

    AwcObjectUtil.createRuntimeObject(
        attrValues, createType
    ).then( async () => {
        // eventBus.publish( 'primaryWorkarea.reset' );
        // eventBus.publish('ObjectSet_1_Provider.plTable.reload');
        await AwcObjectUtil.getProperties( ctx.selected, [ "a2QSampleString", "a2MachineClass1", "a2MachineClass2", "a2MachineClass3", "a2MachineClass4", "a2TargetRange", "a2Lsl", "a2Usl", "a2TargetValue" ] );
        AwcPanelUtil.closeCommandPanel();
    });
}

export let A2QInsObjUseListAction = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsView", "true" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    } );
}

export let A2QInsObjUnUseListAction = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsView", "false" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    } );
}

const _getMaxIndex = async ( ctx, parentType ) => {
    await AwcObjectUtil.getProperties( ctx.xrtSummaryContextObject, [ "a2Contents", "contents", "a2WorkingView", "a2InspItemList" ] );
    let parentContentsArr = new Array();
    if( parentType == "A2QMgmtFolder" ) {
        parentContentsArr = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.a2Contents.dbValues );
    } else if( parentType == "A2QInsTreeObject" || parentType == "ItemRevision" ) {
        parentContentsArr = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.contents.dbValues );
    } else if( parentType.includes( "InsItemRevision" ) || parentType.includes( "PTItemRevision" ) ) {
        parentContentsArr = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.a2WorkingView.dbValues );
    } else if (parentType == "A2QPartIPItemRevision"){
        parentContentsArr = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.a2InspItemList.dbValues );
    }
    let a2Index = 10;
    if( parentContentsArr.length > 0 ) {
        await AwcObjectUtil.getProperty( parentContentsArr, "a2Index" );
        let indexArr = Object.keys( parentContentsArr ).map( ( idx ) => {
            return parentContentsArr[ idx ].props.a2Index.dbValues[0];
        } );
        a2Index = Math.max.apply( null, indexArr ) + 10;
    }
    return String( a2Index );
}

/**
 * 기준정보에서 생성시 a2Code가 같거나 object_name 중 같은게 있다면 return
 * 부품검사주기 생성시 같은 정보로 생성된게 있으면 return
 */
const _codeValidation = async ( data, ctx ) => {
    if( data.a2Code ) {
        await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2Contents" );
        let parentArr   = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.a2Contents.dbValues );
        let object_name = data.a2ObjectName.dbValues[0];
        let a2Code      = data.a2Code.dbValues[0];
        await AwcObjectUtil.getProperty( parentArr, "a2Code" );
        let existCheck  = parentArr.some( ( content ) => {
            return content.props.a2Code.dbValues[0] == a2Code || content.props.object_name.dbValues[0] == object_name;
        } );
        if( existCheck ) {
            AwcNotificiationUtil.show("WARNING", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "ExistWSO" ));
            return false;
        }
    } else if( data.objCreateInfo.createType == "A2QPartInsPeriodRuntime" ) {
        let InspectionPlanId = data.a2InspectionPlan.dbValue;
        let PartString       = data.a2PartString.dbValue;
        let SupplierString   = data.a2SupplierString.dbValue;
        let result = await AwcQueryUtil.executeSavedQuery( "_Inspection_getPeriodRevision",
                                                        [  "A2InspectionPlanId", "A2PartString", "A2SupplierString" ],
                                                        [  InspectionPlanId, PartString, SupplierString ] );
        if( result && result.length > 0 ) {
            AwcNotificiationUtil.show("ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "ExistPeriod" ));
            return false;
        }
    }
    return true;
}

/**
 * _checkItemValidation() : 검사 기준 생성시 목표값, LSL, USL에 대한 Validation -> 기준에 벗어나면 Error
 * _getGroupInfo() : 제품 출하검사의 검사 기준 생성시 a2Group1은 A2QCheckSheet, a2Group2는 A2QCheckGroup or A2QCheckSet, a2Group3은 A2QCheckSet or null
 * _getParentInfo() : 생성하는 객체 부모 정보 저장
 * _getCheckSheetObject() : Check Sheet 하위 객체 생성할 때 Check Sheet의 정보를 저장
 * parentType == 'ItemRevision' 일 때는 생성 객체가 CheckSheet라 a2CheckSheetObject를 넣지 않음
 */
const _getTreeObjProps = async ( ctx, data, parentType, parentObj ) => {
    let inspectionObject = parentObj.props.a2InspectionObject ? parentObj.props.a2InspectionObject.dbValues[0] : parentObj.uid;
    let createProperties = [
        { a2Index            : await _getMaxIndex( ctx, ctx.xrtSummaryContextObject.modelType.parentTypeName ) },
        { a2InspectionObject : inspectionObject },
    ];

    let objType = data.objCreateInfo.createType;
    if( objType.includes( "CheckItemRuntime" ) ) {
        if( !_checkItemValidation( data, ctx ) ) return;

        if( objType == "A2QCheckItemRuntime" || objType == "A2QProdIPCheckItemRuntime" ) {
            createProperties = createProperties.concat( _getGroupInfo( data, ctx ) );
        }
        // let checkArr = [ "a2TargetValue", "a2Usl", "a2Lsl" ];
        // let decimalLengthArr = checkArr.map( ( prop ) => {
        //     let first = `${ prop }Length`;
        //     let second = String( data[ prop ].dbValues[0].split( "." )[1].length ); 
        //     return {
        //         [ first ] : second
        //     }
        // } );
        // createProperties = createProperties.concat( decimalLengthArr );
    }

    if(objType != "A2QPartInspResultRuntime"){
        createProperties = createProperties.concat( _getParentInfo( objType, data, ctx, parentType ) );
    }
    
    if( parentType != "ItemRevision" ) {
        let checkSheet = await _getCheckSheetObject( data, parentObj, ctx.xrtSummaryContextObject.modelType.parentTypeName );
        
        if(objType == "A2QPartInspResultRuntime"){
            let checkSheetObj = await AwcObjectUtil.getObject(checkSheet);
            let a2ParentId = checkSheetObj.props.a2Id.dbValues[0];
            let a2ParentRevId = checkSheetObj.props.a2RevId.dbValues[0];
            createProperties.push({ a2ParentId : a2ParentId });
            createProperties.push({ a2ParentRevId : a2ParentRevId });
        }

        createProperties.push(
            { a2CheckSheetObject : checkSheet }
        );
    }
    return createProperties;
}

const _getGroupInfo = ( data, ctx ) => {
    let objType = data.objCreateInfo.createType;
    let createProperties = [];
    if( objType == "A2QCheckItemRuntime" ) {
        createProperties.push(
            { a2Group1 : ctx.xrtSummaryContextObject.props.a2CheckSheetObject.displayValues[0].split( "-" )[1] },
            { a2Group2 : ctx.pselected.type == "A2QCheckGroup" ? 
                            ctx.pselected.props.object_name.dbValues[0] : 
                            ctx.xrtSummaryContextObject.props.object_name.dbValues[0] },
            { a2Group3 : ctx.pselected.type == "A2QCheckGroup" ? ctx.xrtSummaryContextObject.props.object_name.dbValues[0] : "" },
        )
    } else if( objType == "A2QProdIPCheckItemRuntime" ) {
        createProperties.push(
            { a2Group1 : data.a2CheckSheet.displayValues[0].split( "-" )[1] },
            { a2Group2 : data.a2CheckGroup.dbValue ? 
                            data.a2CheckGroup.displayValues[0].split( "-" )[1] : 
                            data.a2CheckSet.displayValues[0].split( "-" )[1] },
            { a2Group3 : data.a2CheckGroup.dbValue ? data.a2CheckSet.displayValues[0].split( "-" )[1] : "" }
        )
    }
    
    createProperties.push(
        { a2LslEmpty: String( data.a2Lsl.dbValue === "" ) },
        { a2UslEmpty: String( data.a2Usl.dbValue === "" ) }
    )
    return createProperties;
}


/**
 * 검사항목 분류(a2Class1Obj), 검사항목 명(a2Class2Obj) 개체 Validation
 * 1. 필수 입력 Check
 * 2. a2Class2Obj 값이 a2Class1Obj의 하위 Casecade Object 인지 Check
 * 3. 기 등록된 검사항목명 중복 Check
 */
 export let iPCheckItemValidation = async ( cls1Uids, cls2Uids, principal, ctx ) => {

    var class2CodeList = [];
    var class2StringList = [];
    
    
    for( var i = 0; i < cls1Uids.length; i++ ) {

        let cls1Uid = cls1Uids[i];
        let cls2Uid = cls2Uids[i];

        if( !cls1Uid ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "enterIPCheckClass1Value" ) );
            return false;
        }
        else if( !cls2Uid ){
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "enterIPCheckClass2Value" ) );
            return false;
        }else {
    
            let cls1Obj = await AwcObjectUtil.loadObjects(cls1Uid);
            let cls2Obj = await AwcObjectUtil.loadObjects(cls2Uid);
        
            await AwcObjectUtil.getProperty(cls1Obj, "a2Class1Code");
            let cls1Code1 = cls1Obj.props.a2Class1Code.dbValues[0];
        
            await AwcObjectUtil.getProperties(cls2Obj, ["a2Class1Code", "a2Class2Code", "a2Class2String"]);
            let cls1Code2 = cls2Obj.props.a2Class1Code.dbValues[0];
            let cls2Code = cls2Obj.props.a2Class2Code.dbValues[0];
            let cls2String = cls2Obj.props.a2Class2String.dbValues[0];
        
            // class1Obj 선택 -> class2Obj 선택 -> class1Obj 변경 : 이 경우 class2Obj 값 Check
            if(cls1Code1 != cls1Code2){
                AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "invalidIPCheckClass2Value" ) );
                return false;
            }else{
                class2CodeList.push(cls2Code);
                class2StringList.push(cls2String);
            }
            
        
        }
    }
    var dupList = [];
    for( var j = 0; j < class2CodeList.length; j++ ) {
        var cnt = 0;
        for( const cls2Code_1 of class2CodeList ) {
            if(class2CodeList[j] == cls2Code_1){
                cnt++;
            }

        }
        if( cnt > 1){
            dupList.push(class2StringList[j]);
        }
    }

    if(dupList.length > 0){
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "duplicateIPCheckClass2Value" )+dupList );
        return false;
    }

    // 기 등록된 검사항목명 중복 Check
    let parentObj = AwcObjectUtil.getObject( ctx.xrtSummaryContextObject.uid );
    await AwcObjectUtil.getProperties( parentObj, [ "item_id", "item_revision_id", "object_type"] );
    let parentType = parentObj.props.object_type.dbValues[0];
    let checkItemType = "";

    if( parentType == "A2QPartCheckSheet" ){
        checkItemType = "A2QPartCheckItem";

        // 부품 템플릿 체크시트 하위에 검사항목을 추가하는 경우 체크시트 상위 템플릿 개체 하위에 존재하는 모든 검사항목 중복체크 수행
        await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2InspectionObject");
        let inspPlanUid = ctx.xrtSummaryContextObject.props.a2InspectionObject.dbValues[0];
        parentObj = AwcObjectUtil.getObject(inspPlanUid);

    }else if(parentType == "A2QPartIPItemRevision"){
        checkItemType = "A2QPartIPCheckItem";
    }else if(parentType == "A2QPartIRItemRevision"){
        checkItemType = "A2QPartInspectionResult";
    }else{
        return false;
    }

    let queryName = "_Inspection_getChildrenObjects";
    let queryData = [ "A2ParentId", "A2ParentRevId"];
    let queryValue = [ parentObj.props.item_id.dbValues[0], parentObj.props.item_revision_id.dbValues[0]];

    let res = await AwcQueryUtil.executeSavedQuery( queryName, queryData, queryValue );

    if( res ) {
        for( const checkItem of res ) {
            if(checkItem.type == checkItemType){
                await AwcObjectUtil.getProperties( checkItem, ["a2Class2Code","a2Class2String","a2Principal2"]);
                for( const cls2Code of class2CodeList ) {
                    // 기 등록된 검사항목의 이름/검사주체(사내/사외)가 일치하는 항목이 있으면 중복처리
                    if( checkItem.props.a2Class2Code.dbValues[0] == cls2Code && principal == checkItem.props.a2Principal2.dbValues[0]) {
                        dupList.push(checkItem.props.a2Class2String.dbValues[0]);
                    } 
                }
            }
        }
    }

    if(dupList.length > 0){
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "duplicateIPCheckClass2Value" )+dupList );
        return false;
    }

    return true;
}

/**
 * _decimalValidation() : 목표값, LSL, USL에서 소수점 7글자 초과시 Error
 */
const _checkItemValidation = ( data, ctx ) => {
    let lsl = data.a2Lsl.dbValue;
    let usl = data.a2Usl.dbValue;
    let targetValue = data.a2TargetValue.dbValue;
    let targetRange = data.a2TargetRange.dbValue;
    if( data.a2InsInputType.dbValue == "Continuous" ) {
        let msg = "";
        switch( targetRange ) {
            case "LSL<X"    :
                if( lsl >= targetValue ) msg = "invalidLslTargetValue";
                break;
            case "LSL<X<USL"    :
                if( lsl >= targetValue ) msg = "invalidLslTargetValue";
                if( usl <= targetValue ) msg = "invalidUslTargetValue";
                if( lsl >= usl ) msg = "invalidLslUsl";
                break;
            case "LSL<X≤USL"    :
                if( lsl >= targetValue ) msg = "invalidLslTargetValue";
                if( usl < targetValue ) msg = "invalidUslTargetValue";
                if( lsl >= usl ) msg = "invalidLslUsl";
                break;
            case "X<USL"    :
                if( usl <= targetValue ) msg = "invalidUslTargetValue";
                break;
            case "LSL≤X"    :
                if( lsl > targetValue ) msg = "invalidLslTargetValue";
                break;
            case "LSL≤X<USL"    :
                if( lsl > targetValue ) msg = "invalidLslTargetValue";
                if( targetValue >= usl ) msg = "invalidUslTargetValue";
                if( lsl >= usl ) msg = "invalidLslUsl";
                break;
            case "LSL≤X≤USL"    :
                if( lsl > targetValue ) msg = "invalidLslTargetValue";
                if( targetValue > usl ) msg = "invalidUslTargetValue";
                if( lsl >= usl ) msg = "invalidLslUsl";
                break;
            case "X≤USL"    :
                if( targetValue > usl ) msg = "invalidUslTargetValue";
                break;
        }
        
        if( msg ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", msg ) );
            return false;
        }
        if( !_decimalValidation( data ) ) return false;
    }

    return true;
}

const _decimalValidation = ( data ) => {
    let decimalCheck = [ "a2TargetValue", "a2Lsl", "a2Usl" ].some( ( prop ) => {
        return data[ prop ].dbValue.toString().includes( "." ) && data[ prop ].dbValue.toString().split( "." )[1].length > 7;
    } );
    if( decimalCheck ) {
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "decimalOver" ) );
        return false;
    } else {
        let maxCheck = [ "a2TargetValue", "a2Lsl", "a2Usl" ].map( ( prop ) => {
            if( data[ prop ].dbValue > 100000 || data[ prop ].dbValue < -100000 ) {
                return locale.getLocalizedText( "lgspQmsNewInspectionMessages", prop );
            }
        } ).filter( ( prop ) => {
            return prop !== undefined;
        } );
        if( maxCheck.length > 0 ) {
            AwcNotificiationUtil.show( "ERROR", `\n${maxCheck.toString()}${locale.getLocalizedText( "lgspQmsNewInspectionMessages", "milionOver" )}` );
            return false;
        } else {
            return true;
        }
    }
}

const _getParentInfo = ( type, data, ctx, parentType ) => {
    let a2ParentId = null;
    let a2ParentRevId = null;
    let parentObj = AwcObjectUtil.getObject( ctx.xrtSummaryContextObject.uid );
    if( parentType.includes( "InsItemRevision" ) || parentType.includes( "PTItemRevision" ) ) {
        let lastObj = type.includes( "ProdIP" ) ? "a2CheckSet" : "a2CheckSheet";
        a2ParentId = data[ lastObj ].uiValue.split( "/" )[0];
        a2ParentRevId = data[ lastObj ].uiValue.split( "/" )[1].split( "-" )[0];
    } else {
        a2ParentId = parentObj.props.a2Id ? parentObj.props.a2Id.dbValues[0] : parentObj.props.item_id.dbValues[0];
        a2ParentRevId = parentObj.props.a2RevId ? parentObj.props.a2RevId.dbValues[0] : parentObj.props.item_revision_id.dbValues[0];
    }
    return [
        { a2ParentId : a2ParentId },
        { a2ParentRevId : a2ParentRevId }
    ];
}

const _getCheckSheetObject = async ( data, parentObj, parentType ) => {
    let a2CheckSheetObject = null;
    if( parentType == "A2QInsTreeObject" ) {
        a2CheckSheetObject = parentObj.props.a2CheckSheetObject && parentObj.props.a2CheckSheetObject.dbValues[0] != null ? parentObj.props.a2CheckSheetObject.dbValues[0] : parentObj.uid;
    } else if( parentType.includes( "InsItemRevision" ) || parentType.includes( "PTItemRevision" ) ) {
        a2CheckSheetObject = data.a2CheckSheet && data.a2CheckSheet.dbValue ? data.a2CheckSheet.dbValue : data.a2PartCheckSheet.dbValue;
    } else if(parentType == "A2QPartIPItemRevision") {
        a2CheckSheetObject = await _getPhantomCheckSheet(parentObj);
    }
    return a2CheckSheetObject;
}

const _getPhantomCheckSheet = async ( parentObj ) => {
    let phantomCheckSheet;
    let contents = parentObj.props.contents;
    if(contents.dbValues.length > 0){
        phantomCheckSheet = contents.dbValues[0];
    }else{
        phantomCheckSheet = await _createPhantomCheckSheet(parentObj);
    }
    return phantomCheckSheet;
}

const _createPhantomCheckSheet = async ( parentObj ) => {
    let createType = "A2QPartIRCheckSheet";
    let propertyPolicyOverride = {
        vAttachInfo: [
            { typeName: createType, propName: 'a2Id' }
        ]
    };
    let pattern = await soaService.post( 'Core-2008-06-DataManagement', 'getNRPatternsWithCounters', propertyPolicyOverride );
    let a2Id = await AwcObjectUtil.getNextIds( createType, 'a2Id', pattern.patterns[0].patternStrings[0] );

    let props = [
        {a2Index: '10'},
        {a2InspectionObject: parentObj.uid},
        {a2ParentId: parentObj.props.item_id.dbValues[0]},
        {a2ParentRevId: parentObj.props.item_revision_id.dbValues[0]},
        {a2Id: a2Id},
        {object_name: 'RETURN_NG_SHEET'}
    ];

    let res = await AwcObjectUtil.createAttachAndSubmitObjects(props, createType);
    return res.output[0].objects[0].uid;
}

/**
 * QMS Inspection 기준정보, 제품/부품 템플릿, 제품/부품 체크시트, 그룹, 세트, 검사항목 
 * Runtime객체의 Create Post Action으로 ITK에서 객체 생성을 위한 통합 function
 * _getTreeObjProps() : 제품/부품 템플릿에서 사용하는 객체( *CheckSheet / *CheckGroup / 등) 생성
 * 각 함수에서 return 하는 배열을 concat한다.
 * 배열이 아닌 빈 값으로 return 될 경우 함수를 끝낸다.
 * _codeValidation() : 같은 a2Code / object_name이 있다면 return
 * _getMaxIndex() : a2Index 속성을 사용하는 객체의 값중 가장 큰 수 가져옴
 * a2Index는 연간계획, 부품 주기 관리는 사용하지 않아 return
 */

export let RuntimeCreate = async ( data, ctx ) => {
    let parentObj = AwcObjectUtil.getObject( ctx.xrtSummaryContextObject.uid );
    await AwcObjectUtil.getProperties( parentObj, [ "item_id", "a2OrgCode", "a2ProdGroupCode", 
                                                    "a2PartGroupCode", "a2Id", "a2RevId", 
                                                    "a2InspectionObject", "a2CheckSheetObject" ] );
    let parentType = ctx.xrtSummaryContextObject.modelType.parentTypeName;
    let objType = data.objCreateInfo.createType;
    let principal;

    let createProperties = [];
    if(objType == "A2QPartInspResultRuntime"){
        createProperties.push({ object_type   : "A2QPartInspectionResultRuntime" });
        createProperties.push({ a2Principal2  : "InSide" });
        principal = "InSide";
    }else{
        createProperties.push({ object_type   : objType });
        if( data.a2Principal2 ) {
            principal = data.a2Principal2.dbValue;
        }
    }


    let createPropArr = [];
    /**
     * 1. parentType : A2QMgmtFolder => 기준 정보에서 생성되는 항목들( A2QOrgInfo, A2QProdGroupInfo, A2QProdInsItem ... )
     * 2. parentType : ItemRevision / A2QInsTreeObject => 검사/부품 템플릿에서 생성되는 항목들( A2QCheckSheet, A2QCheckSet, A2QCheckItem, A2QProdPTPCheckItem ... )
     * 3. ..SummaryType : A2QAnnualPlanFor => 연간시험 계획에서 생성되는 항목들( A2QAPProdEntryRevision, a2QAPPartEntryRevision )
     */
    if( parentType === "A2QMgmtFolder" ) {
        if( !await _codeValidation( data, ctx ) ) return;
        if( !ctx.xrtSummaryContextObject.type.includes( "A2QAnnualPlanFor" ) && objType !== "A2QPartInsPeriodRuntime" ) {
            createProperties.push( { a2Index : await _getMaxIndex( ctx, ctx.xrtSummaryContextObject.modelType.parentTypeName ) } );
        }
    } else if( ( parentType.includes( "ItemRevision" ) || parentType == "A2QInsTreeObject" ) && objType != "A2QPartInsPeriodRuntime" ) {
        createPropArr = await _getTreeObjProps( ctx, data, parentType, parentObj );
        if( createPropArr ) {
            createProperties = createProperties.concat( createPropArr );
        } else {
            return;
        }
    } else if( ctx.xrtSummaryContextObject.type.includes( "A2QAnnualPlanFor" ) ) {
        createProperties.push( 
            { a2OrgCodeRT : parentObj.props.a2OrgCode.dbValues[0] }
         )
    }

    if(objType == "A2QPartCheckItemRuntime" || objType == "A2QPartIPCheckItemRuntime" || objType == "A2QPartInspResultRuntime"  ){
        let valid = await iPCheckItemValidation( [data.a2Class1Obj.dbValue], [data.a2Class2Obj.dbValue], principal , ctx );
        if(!valid){
            return;
        }
    }

    /**
     * data.objCreateInfo.propNamesForCreate : *Create.xml StyleSheet에서 입력한 property들 ( <property name='item_id' /> 같은 )
     */
    for( const prop of data.objCreateInfo.propNamesForCreate ) {

        if( data[ prop ] && data[ prop ].dbValue )
        {
            if( prop === "a2PartGroupMasterObject" ) {
                const partMasterObject = AwcObjectUtil.getObject( data[ prop ].dbValue );
                await AwcObjectUtil.getProperties( partMasterObject, [ "a2CategoryPath", "a2ClassCode" ] );
                createProperties.push(
                    // { a2PartGroupMasterObject : data[ prop ].dbValue },
                    { a2PartGroupPath : partMasterObject.props.a2CategoryPath.dbValues[0] },
                    { a2PartGroupCode : partMasterObject.props.a2ClassCode.dbValues[0] }
                )
                //break;
            } else if( prop === "a2ProdGroupMasterObject" ) {
                const prodMasterObject = AwcObjectUtil.getObject( data[ prop ].dbValue );
                await AwcObjectUtil.getProperties( prodMasterObject, [ "a2CategoryPath", "a2Id" ] );
                createProperties.push(
                    // { a2ProdGroupMasterObject : data[ prop ].dbValue },
                    { a2ProdGroupPath : prodMasterObject.props.a2CategoryPath.dbValues[0] },
                    { a2ProdGroupCode : prodMasterObject.props.a2Id.dbValues[0] }
                )
            }
            let value = data[ prop ].dbValue ? data[ prop ].dbValue : data[ prop ].dbValues[0] ? data[ prop ].dbValues[0] : "";
            if( _.isNumber( value ) ) value = String( value );
            createProperties.push(
                { [ prop ] : value }
            )
    
        }
    }

    //AwcObjectUtil.createAttachAndSubmitObjects( 
    AwcObjectUtil.createRuntimeObject( 
            createProperties,
        objType
    ).catch( ( e ) => {
        AwcNotificiationUtil.show( "ERROR", e.message );
    } ).finally( () => {
        AwcPanelUtil.closeCommandPanel();
        eventBus.publish( 'primaryWorkarea.reset' );
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
        if(objType == "A2QPartInspResultRuntime"){
            eventBus.publish( 'ObjectSet_2_Provider.plTable.reload' );
        }



    } );
}

export const reAssignAction = ( data, ctx ) => {
    AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "checkForReassign"), ["YES", "NO"], [
        async () => {
            await AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2Status", "Create" );
            AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( localeText, "statusReset" ) );
            await AwcObjectUtil.getProperties( ctx.xrtSummaryContextObject, [ "a2Status", "a2SupplierStatus", "fnd0InProcess" ] );
            eventBus.publish('cdm.relatedModified', {
                refreshLocationFlag: true,
                relatedModified: [ctx.xrtSummaryContextObject]
            });
        },
        () => {}
    ])
}

export let RuntimeLoad = ( data, ctx ) => {
    const load = setInterval( async () => {
        if( ctx.xrtSummaryContextObject ){
            if( data.objCreateInfo ) {
                clearInterval( load );


                if( ctx.xrtSummaryContextObject.type.includes( "A2QAnnualPlanForProd" ) ) {
                    if( data.a2AnnaulPlanRT && data.a2QModelSuffixRT ) {
                        uwPropertyService.setValue( data.a2AnnaulPlanRT, [ ctx.xrtSummaryContextObject.uid ] );
                    }
                } else if( ctx.xrtSummaryContextObject.type.includes( "A2QAnnualPlanForPart" ) ) {
                    if( data.a2AnnaulPlanRT && data.a2QSupplierRT ) {
                        uwPropertyService.setValue( data.a2AnnaulPlanRT, [ ctx.xrtSummaryContextObject.uid ] );
                    }
                } else if( data.objCreateInfo.createType == "A2QMeasureMachineRuntime" ) {
                    await AwcObjectUtil.getProperty( ctx.selected, "a2InspectionObject" );
                    const a2InspectionObject = AwcObjectUtil.getObject( ctx.selected.props.a2InspectionObject.dbValue );
                    await AwcObjectUtil.getProperty( a2InspectionObject, "a2OrgCode" );
                    uwPropertyService.setValue( data.a2TargetObject, [ ctx.selected.uid ] );
                    uwPropertyService.setValue( data.a2OrgCode, [ a2InspectionObject.props.a2OrgCode.dbValues[0] ] );
                    if( ctx.selected.props.a2MachineClass4.dbValue ) {
                        [ "a2MachineClass1", "a2MachineClass2", "a2MachineClass3", "a2MachineClass4" ].forEach( ( prop ) => {
                            uwPropertyService.setValue( data[ prop.replace( "Machine", "" ) ], [ ctx.selected.props[ prop ].dbValue ] );
                            uwPropertyService.setDisplayValue( data[ prop.replace( "Machine", "" ) ], [ ctx.selected.props[ prop ].dbValue ] );
                        } );
                    }
                } 
            }
        }
    } );
}

export const setMeasureMachine = () => {
    AwcPanelUtil.openCommandPanel( "A2QSetMeasureMachine" );
}

export const setRuntimeProps = ( data, ctx ) => {
    AwcObjectUtil.setProperties( ctx.selected, [ "a2MachineClass1", "a2MachineClass2", "a2MachineClass3", "a2MachineClass4" ], 
                                               [ data.a2Class1.dbValue, data.a2Class2.dbValue, data.a2Class3.dbValue ,data.a2Class4.dbValue ] ).catch( ( e ) => {
        AwcNotificiationUtil.show( "ERROR", e.message );
    } ).finally( async () => {
        AwcPanelUtil.closeCommandPanel();
        // eventBus.publish( 'primaryWorkarea.reset' );
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
        await AwcObjectUtil.getProperties( ctx.selected, [ "a2MachineClass1", "a2MachineClass2", "a2MachineClass3", "a2MachineClass4" ] );
    } );
    
}
export const setRange = async ( data, ctx ) => {
    let a2Lsl, a2Usl, a2TargetValue, a2LslEmpty, a2UslEmpty, msg;

    switch( data.a2TargetRange.dbValue ) {
        case "LSL<X"   : 
            a2Lsl = String( data.a2Lsl.dbValue ); 
            a2Usl = ""; 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "false";
            a2UslEmpty = "true";
            if( parseFloat( a2Lsl ) >= parseFloat( a2TargetValue) ) msg = "invalidLslTargetValue";
            break;
        case "LSL<X<USL"   : 
            a2Lsl = String( data.a2Lsl.dbValue ); 
            a2Usl = String( data.a2Usl.dbValue ); 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "false";
            a2UslEmpty = "false";
            if( parseFloat( a2Lsl ) >= parseFloat( a2TargetValue) ) msg = "invalidLslTargetValue";
            if( parseFloat( a2TargetValue ) >= parseFloat( a2Usl) ) msg = "invalidUslTargetValue";
            if( parseFloat( a2Lsl ) >= parseFloat( a2Usl) ) msg = "invalidLslUsl";
            break;
        case "LSL<X≤USL"   : 
            a2Lsl = String( data.a2Lsl.dbValue ); 
            a2Usl = String( data.a2Usl.dbValue ); 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "false";
            a2UslEmpty = "false";
            if( parseFloat( a2Lsl ) >= parseFloat( a2TargetValue) ) msg = "invalidLslTargetValue";
            if( parseFloat( a2TargetValue ) > parseFloat( a2Usl) ) msg = "invalidUslTargetValue";
            if( parseFloat( a2Lsl ) >= parseFloat( a2Usl) ) msg = "invalidLslUsl";
            break;
        case "X<USL"   : 
            a2Lsl = ""; 
            a2Usl = String( data.a2Usl.dbValue ); 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "true";
            a2UslEmpty = "false";
            if( parseFloat( a2TargetValue ) >= parseFloat( a2Usl) ) msg = "invalidUslTargetValue";
            break;
        case "X=Target"   : 
            a2Lsl = ""; 
            a2Usl = ""; 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "true";
            a2UslEmpty = "true";
            break;
        case "LSL≤X"   : 
            a2Lsl = String( data.a2Lsl.dbValue ); 
            a2Usl = ""; 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "false";
            a2UslEmpty = "true";
            if( parseFloat( a2Lsl ) > parseFloat( a2TargetValue) ) msg = "invalidLslTargetValue";
            break;
        case "LSL≤X<USL"   : 
            a2Lsl = String( data.a2Lsl.dbValue ); 
            a2Usl = String( data.a2Usl.dbValue );
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "false";
            a2UslEmpty = "false";
            if( parseFloat( a2Lsl ) > parseFloat( a2TargetValue) ) msg = "invalidLslTargetValue";
            if( parseFloat( a2TargetValue ) > parseFloat( a2Usl) ) msg = "invalidUslTargetValue";
            if( parseFloat( a2Lsl ) >= parseFloat( a2Usl) ) msg = "invalidLslUsl";
            break;
        case "LSL≤X≤USL"   : 
            a2Lsl = String( data.a2Lsl.dbValue ); 
            a2Usl = String( data.a2Usl.dbValue ); 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "false";
            a2UslEmpty = "false";
            if( parseFloat( a2Lsl ) > parseFloat( a2TargetValue) ) msg = "invalidLslTargetValue";
            if( parseFloat( a2TargetValue ) > parseFloat( a2Usl) ) msg = "invalidUslTargetValue";
            if( parseFloat( a2Lsl ) >= parseFloat( a2Usl) ) msg = "invalidLslUsl";
            break;
        case "X≤USL"   : 
            a2Lsl = ""; 
            a2Usl = String( data.a2Usl.dbValue ); 
            a2TargetValue = String( data.a2TargetValue.dbValue ); 
            a2LslEmpty = "true";
            a2UslEmpty = "false";
            if( parseFloat( a2TargetValue ) > parseFloat( a2Usl) ) msg = "invalidUslTargetValue";
            break;
    }
    if( !_decimalValidation( data ) ) {
        return;
    }
    if( msg ) {
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( "lgspQmsNewInspectionMessages", msg ) );
        return;
    }
    await AwcObjectUtil.setProperties( ctx.selected, [ "a2Lsl", "a2Usl", "a2TargetValue", "a2LslEmpty", "a2UslEmpty", "a2TargetRange" ], 
                                                     [ a2Lsl, a2Usl, a2TargetValue, a2LslEmpty, a2UslEmpty, data.a2TargetRange.dbValue ] ).finally( async () => {
                                                         AwcPanelUtil.closeCommandPanel();
                                                         eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
                                                         await AwcObjectUtil.getProperties( ctx.selected, [ "a2Lsl", "a2Usl", "a2TargetValue", "a2LslEmpty", "a2UslEmpty", "a2TargetRange" ] );
                                                     } );
}

const deleteMeasureMachine = async ( data, ctx ) => {
    await AwcObjectUtil.setProperties4( ctx.selected, [ "a2MachineClass1", "a2MachineClass2", "a2MachineClass3", "a2MachineClass4" ], [ "", "", "", "" ] ).then( () => {
        AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( "lgspQmsNewInspectionMessages", "machineClearComplete" ) );
        AwcPanelUtil.closeCommandPanel();
    } );
}

export default exports = {
    ApplyAction,
    pageLoaded,
    A2QInsObjUseListAction,
    A2QInsObjUnUseListAction,
    RuntimeCreate,
    reAssignAction,
    RuntimeLoad,
    iPCheckItemValidation,
    setMeasureMachine,
    setRuntimeProps,
    setRange,
    deleteMeasureMachine
};
app.factory('A2QCheckService', () => exports);