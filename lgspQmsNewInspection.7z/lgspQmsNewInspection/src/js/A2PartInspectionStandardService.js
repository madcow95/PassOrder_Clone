/**
 * QMSCommonService
 *
 * @module js/A2InspectionTemplateService
 */

import app from 'app';
import AwcPanelUtil from 'js/AwcPanelUtil';

var exports = {};


export async function a2PartPeriodCreate(data, ctx) {
    // if (AwcObjectUtil.instanceOf2(ctx.selected, ctx.selected.type)){
    //     // cosole.log("panel open");
    //     appCtxService.registerCtx(ctx.selected.type, ctx.selected);
    // }
    AwcPanelUtil.openCommandPanel("A2StandardItemRuntimeCreate");
}



export default exports = {
    a2PartPeriodCreate
};
app.factory('A2PartInspectionTemplateService', () => exports);