/**
 * QMSCommonService
 *
 * @module js/A2InspectionTemplateService
 */

 import app from 'app';
 import AwcObjectUtil from 'js/AwcObjectUtil';
 import eventBus from 'js/eventBus';
 import AwcPanelUtil from 'js/AwcPanelUtil';
 import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
 import soaService from 'soa/kernel/soaService';
 import appCtxService from 'js/appCtxService';
 import locale from 'js/AwcLocalizationUtil';
 import uwPropertyService from 'js/uwPropertyService';
 import viewModelService from 'js/viewModelService';
 import viewModelObjectSvc from 'js/viewModelObjectService';
 import AwcQueryUtil from 'js/AwcQueryUtil';
 import preferenceService from 'soa/preferenceService';

 import $ from 'jquery';

 var exports = {};
 let localeText = "lgspQmsNewInspectionMessages";

 export function _getInitialLOVValues(lovName, typeName, operationName="Edit") {
    let soaInputParam = {
        initialData: {
          propertyName: lovName,
          filterData: {
            filterString: "",
            maxResults: 4500,
            numberToReturn: 999,
            order: 1,
            sortPropertyName: ""
          },
          lov: {
            uid: "AAAAAAAAAAAAAA",
            type: "unknownType"
          },
          lovInput: {
            owningObject: null,
            operationName: operationName,
            boName: typeName,
            propertyValues: {}
          }
        }
      }
      return soaService.post( 'Core-2013-05-LOV', 'getInitialLOVValues', soaInputParam );
}

/**
 *검사결과생성 
 */
export let A2QPartIRCreateAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel( "A2QPartIRCreateRuntime" );
}

export function a2PartInspectionResultOpen(data, ctx) {
    let selected = appCtxService.ctx.selected;
    //validation추가. 생성, 대기 완료일때 검색 의뢰 결과창X
    if( !selected.props.a2Status ) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "SPCNoSelectResult"));
        return false;
    }
    let myStatus = selected.props.a2Status.dbValue;

    if ( myStatus == "Create" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidCreateStatus"));
    } else if ( myStatus == "Stand By" ){
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidStandStatus"));
    } else if ( myStatus == "Reject" ){
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidRejectStatus"));
    } else {
        AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);
    }
 }

export let A2QPartIRCreateItem = async (data, ctx, type) => {
    let target = ctx.xrtSummaryContextObject;
    let createType = data.objCreateInfo.createType;       //A2QProdIRCreateRuntime
    
    let a2InspectionPlan = data.a2InspectionPlan.dbValue;       //검사 기준
    let a2RequestType = data.a2RequestType.dbValue;

    let inspectionPlan = await AwcObjectUtil.loadObjects(a2InspectionPlan);
    await AwcObjectUtil.getProperties(inspectionPlan, ["a2InspTypeName", "a2TemplateType", "a2BasedOnId"], true);
    let inspTypeName = inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : "";
    let basedOnId = inspectionPlan.props.a2BasedOnId.dbValues[0];
    let templateType = basedOnId.substring(0, basedOnId.indexOf("/"));
    let InsRequestType = target.type == "A2QPartIRSearchObject" ? "InSide" : "OutSide";

    AwcObjectUtil.createRuntimeObject(
        [
            { a2InspTypeName: inspTypeName },
            { a2InspectionPlan: a2InspectionPlan },
            { a2PartString: data.a2PartString.dbValues[0] },
            { a2SupplierString: data.a2SupplierString.dbValues[0] },
            { a2TemplateType: templateType },
            { a2RequestType: a2RequestType },
            { a2ProgramPlan: data.a2ProgramPlan.dbValue ? data.a2ProgramPlan.dbValue : "" },
            { a2InsRequestType: InsRequestType }
            // { a2SeverityLevel: inspectionPlan.props.a2SeverityLevel.dbValues[0] ? inspectionPlan.props.a2SeverityLevel.dbValues[0] : ""}
        ],
        createType
    ).then( async (created) => {
        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRCreateRuntimeSuc"));
        AwcPanelUtil.closeCommandPanel();
        
        let viewModelElement = document.getElementById('inspectionRequestHeader');
        let viewModel = viewModelService.getViewModelUsingElement(viewModelElement);   //테이블명으로 vmo 가져오기
        // a2PartInspectionRequestSearch(viewModel, ctx, false);

        // 선택 된 객체가 검증 항목인 경우
        if(target.type == "A2CRVerificationRevision") {
            // 1. 생성 된 A2QPartIRItemRevision을 가져옴
            let createdA2QPartIRRev = await getCreatedQPartIRRev(created);

            let currentPartIRs = await AwcObjectUtil.getReferencedProperties(target, "A2InspectionRequestRel");
            
            if(currentPartIRs && currentPartIRs.length > 0) {
                let resultPartIRUids = currentPartIRs.map((currentPartIR) => {
                    return currentPartIR.uid;
                });

                resultPartIRUids = [...resultPartIRUids, ...[createdA2QPartIRRev.uid]];

                let soaInputParam = {
                    info: [
                        {
                            object: target, 
                            vecNameVal: [
                                {
                                    name: "A2InspectionRequestRel", 
                                    values: resultPartIRUids
                                }
                            ]
                        }
                    ]
                };

                await soaService.post( 'Core-2010-09-DataManagement', 'setProperties', soaInputParam );
            } else {
                // 2. A2QPartIRItemRevision를 검증 항목의 Rel에 붙임
                await AwcObjectUtil.setProperty(target, "A2InspectionRequestRel", createdA2QPartIRRev.uid);
            }

            eventBus.publish('cdm.relatedModified', {
                refreshLocationFlag: false,
                relatedModified: [target]
            });
        }
    })

}

async function getCreatedQPartIRRev(created) {
    let createdServiceData = created.ServiceData;
   
    let createdModelObjects = createdServiceData.modelObjects;
    let createdUpdatedUids = createdServiceData.updated;
   
    let createdUpdatedObjects = createdUpdatedUids.map((createdUpdatedUid) => {return createdModelObjects[createdUpdatedUid]});
   
    let createdA2QPartIRRev = createdUpdatedObjects.filter((createdUpdatedObject) => {
       return createdUpdatedObject.type == "A2QPartIRItemRevision";
    });
   
    return createdA2QPartIRRev[0];
}

function leftPad(value) { if (value >= 10) { return value; } return `0${value}`; } function toStringByFormatting(source, delimiter = '-') { const year = source.getFullYear(); const month = leftPad(source.getMonth() + 1); const day = leftPad(source.getDate()); return [year, month, day].join(delimiter); }
/**
 * 검색 의뢰 결과 팝업. OOTB가 제공해주는 닫기 버튼 실행 X
 */
export let A2QIR = (data, ctx) => {
    // cosole.log("검색의뢰결과 클릭");
    AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);
}

//SPC 조회
export function A2QSPCReferenceAction(data, ctx){
    // cosole.log("1");
    if (ctx.selected.type === "A2QPartInspectionResult") {
        AwcPanelUtil.openPopup("A2InspectionSPCPopup", "SPC", "1400", "800", true, false, true).then(() => {
        });
    } else {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "SPCNoSelectResult")); 
    }
}

//SN 조회
export async function A2QSNReferenceAction(data, ctx){
    let selected = appCtxService.ctx.selected;
    await AwcObjectUtil.getProperty( selected, "a2CheckSheetObjet" );
    let sheetUid = selected.props.a2CheckSheetObject.dbValues[0];  //selected.uid

    let sheetModelObj = await AwcObjectUtil.loadObjects(sheetUid);
    // cosole.log(sheetModelObj);

    await AwcObjectUtil.getProperties( sheetModelObj, [ "a2Id", "a2RevId" ]);
    let id = sheetModelObj.props.a2Id.dbValues[0];
    let revId = sheetModelObj.props.a2RevId.dbValues[0];
    // cosole.log(id, revId, sheetModelObj.object_name);

    const res = await AwcQueryUtil.executeSavedQuery("_Inspection_getSerial", ["A2CheckSheetId", "A2CheckSheetRevId"], [id, revId]);
    // cosole.log(res);

    let serialData = new Array();

    if(res){
        await AwcObjectUtil.getProperties(res, ["a2SerialNumber", "a2IsDeleted"], true);
        for (const queryResult of res) {
            serialData.push({
                seq: queryResult.props.object_name.dbValues[0],
                serial: queryResult.props.a2SerialNumber.dbValues[0]
            });
        }
        serialData.sort((a,b) => a.seq > b.seq ? 1 : -1);
    }
    appCtxService.registerCtx('serialData', serialData);
}

function _dynamicSort2(property1, property2) {
    var sortOrder = 1;
    if(property1[0] === "-") {
        sortOrder = -1;
        property1 = property1.substr(1);
    }
    return function (a,b) {
        /* next line works with strings and numbers, 
         * and you may want to customize it to your needs
         */
        var result = (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  < b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? -1 : (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  > b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? 1 : 0;
        return result * sortOrder;
    }
}

let _getLatestRev = async ( rev ) => {
    let itemsUidArrSet = new Set( rev );
    let itemsUidArr = [...itemsUidArrSet]
    let itemsArr = new Array();
    let returnArr = new Array();

    itemsUidArr.forEach( ( uid ) => {
        itemsArr.push( AwcObjectUtil.getObject( uid ) );
    });

    await AwcObjectUtil.getProperty( itemsArr, "revision_list" );
    itemsArr.forEach( ( item ) => {
        let arrIndex = item.props.revision_list.dbValues.length > 1 ? item.props.revision_list.dbValues.length - 2 : item.props.revision_list.dbValues.length - 1;
        returnArr.push( AwcObjectUtil.getObject( item.props.revision_list.dbValues[ arrIndex ] ) );
    });
    return returnArr;
}


export function A2QPartIRCreateItemPreAction(data, ctx) {
    if(data.a2InspectionPlan == null){
        setTimeout( () => {
            A2QPartIRCreateItemPreAction(data, ctx);
        }, 10 );
    } else{
        //let cmdSvc = viewModelService.getViewModelUsingElement(document.getElementById("requestCreateListBox"));
        // ctx.a2InspectionPlan = ctx.a2PartInspectionPlanListBox;
        data.a2InspectionPlan = data.a2PartInspectionPlanListBox;
        if( data.a2PartString.dbValue && data.a2SupplierString.dbValue ) {
            ctx.a2PartInspectionPlanListBoxValues = {
                "type": "STRING",
                "dbValue": [{
                    "propDisplayValue": "",
                    "propDisplayDescription": "",
                    "dispValue": "",
                    "propInternalValue": "",
                    "iconName": ""
                }]
            };
            //data.a2RequestName = data.a2ObjectName;
            AwcQueryUtil.executeSavedQuery("_Inspection_getPartInspectionPlan", 
                ["a2SearchPartStringRT", "a2SearchSupplierStringRT"], 
                [data.a2PartString.dbValue == null ? "*" : data.a2PartString.dbValue,
                data.a2SupplierString.dbValue == null ? "*" : data.a2SupplierString.dbValue]
            ).then( async (results) => {
                if(results) {
                    let LastedRevArr = [];
                    await AwcObjectUtil.getProperties(results, ["release_status_list", "a2LatestYNRT", "a2IsDeleted"], true);
                    let sortedArray = [];
                    for (const sortElement of results) {
                        // if( sortElement.props.a2LatestYNRT.dbValues[0] == "NO" || sortElement.props.a2IsDeleted.dbValues[0] == "YES") {
                        //     continue;
                        // }
                        // if ( sortElement.props.release_status_list.dbValues.length > 0 ) {
                        //     sortedArray.push(sortElement);
                        // }
                        if( sortElement.type != "A2QPartIPItemRevision" || sortElement.props.a2IsDeleted.dbValues[0] == "YES") continue;
                        if( sortElement.props.release_status_list.dbValues.length > 0 ) sortedArray.push( sortElement.props.items_tag.dbValues[0] );
                    }
                    LastedRevArr = await _getLatestRev( sortedArray );
                    LastedRevArr.sort(_dynamicSort2("item_id", "item_revision_id"));
                    // cosole.log({LastedRevArr});
                    for (const modelObject of LastedRevArr) {
                        await AwcObjectUtil.getProperty( modelObject, "item_id" );
                        let vmo = viewModelObjectSvc.constructViewModelObjectFromModelObject(modelObject);
                        await AwcObjectUtil.getProperties( vmo, [ "item_id", "item_revision_id" ] );
                        let displayString = vmo.props.item_id.dbValues[0] + "/" + vmo.props.item_revision_id.dbValues[0];
                        var listBoxRow = {
                            "propDisplayValue": displayString,
                            "propDisplayDescription": vmo.props.object_name.dbValues[0],
                            "dispValue": displayString,
                            "propInternalValue": vmo.uid,
                            "iconName": "typeQcControlInspectionPlan48"
                        };
                        ctx.a2PartInspectionPlanListBoxValues.dbValue.push(listBoxRow);
                    }
                }
            });
        }
    }
}

export function a2PartStringChanged(data, ctx) {
    A2QPartIRCreateItemPreAction( data, ctx );
    if( data.a2PartString.dbValue ) {
        uwPropertyService.setDisplayValue( data.a2PartString, [ data.a2PartString.dbValues[0] + "/" + data.a2PartString.selectedLovEntries[0].propDisplayDescription ] );
        uwPropertyService.setWidgetDisplayValue( data.a2PartString, [ data.a2PartString.dbValues[0] + "/" + data.a2PartString.selectedLovEntries[0].propDisplayDescription ] );
    } else {
        uwPropertyService.setDisplayValue( data.a2PartString, [ ""] );
        uwPropertyService.setWidgetDisplayValue( data.a2PartString, [ "" ] );
        ctx.a2PartInspectionPlanListBoxValues.dbValue = "";
    }
}

export function a2SupplierStringChanged(data, ctx) {
    A2QPartIRCreateItemPreAction( data, ctx );
    if( data.a2SupplierString.dbValue ) {
        uwPropertyService.setDisplayValue( data.a2SupplierString, [ data.a2SupplierString.dbValues[0] + "/" + data.a2SupplierString.selectedLovEntries[0].propDisplayDescription ] );
        uwPropertyService.setWidgetDisplayValue( data.a2SupplierString, [ data.a2SupplierString.dbValues[0] + "/" + data.a2SupplierString.selectedLovEntries[0].propDisplayDescription ] );
    } else {
        uwPropertyService.setDisplayValue( data.a2SupplierString, [ "" ] );
        uwPropertyService.setWidgetDisplayValue( data.a2SupplierString, [ "" ] );
        ctx.a2PartInspectionPlanListBoxValues.dbValue = "";
    }
}

export async function A2PartInspectionRequestConfirm(data, ctx) {

    let tenantID = ctx.preferences.A2_SITE_TENANT_ID[0];


    let selected = ctx.selected;
    if( selected.type != "A2QPartIRItemRevision" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "IRTypeInvalid"));
        return;
    }
    if( !selected.props.a2Status ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "SPCNoSelectResult"));
        return false;
    }
    if( selected.props.a2Status.dbValues[0] != "Receipt" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "IRStatusInvalid"));
        return;
    }
    if( selected.props.a2Result.dbValues[0] != "OK" && selected.props.a2Result.dbValues[0] != "NG" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "IRResultInvalid"));
        return;
    }



    
    AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRConfirmCheck"), ["YES", "NO"], 
    [
        async function() {

            // LG 이노텍인 경우 
            if(tenantID === "L1300" && selected.type == "A2QPartIRItemRevision"){
                await AwcObjectUtil.getProperty(ctx.selected, "a2OrgCode");
                let orgCode = ctx.selected.props.a2OrgCode.dbValues[0];

                // 특정 ORG인 경우 LOT 분할 출발이 가능하므로 VMILOT 정보가 존재하면 무검사 대상
                let skippablelOrgs = data.preferences.QMS_VMI_ORG;
                if(skippablelOrgs.includes(orgCode) ){

                    await AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "VMILotCheck"), ["Yes", "No"], [
                        //YES button function
                        function () {
                            AwcObjectUtil.setProperty(ctx.selected, "a2IsApplyVMILot",  "true" );
                            //AwcObjectUtil.setProperty(ctx.selected, "a2EventProperty",  "SETVMILOT" )
                            _confirmInspectionRequest(ctx);
                        },
                        //NO button function
                        function () {
                            _confirmInspectionRequest(ctx);
                        }
                    ]);

                }else{
                    _confirmInspectionRequest(ctx);
                }
            }else{
                await AwcObjectUtil.getProperty(ctx.selected, "a24MStatus");
                let check4M = ctx.selected.props.a24MStatus.dbValues[0];

                if(check4M == "4M_Check") 
                {
                    await AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "4MConfirmCheck"), ["Yes", "No"], [
                        //YES button function
                        function () {
                            AwcObjectUtil.setProperty(ctx.selected, "a24MChecked",  "true" );
                            _confirmInspectionRequest(ctx);
                        },
                        //NO button function
                        function () {
                            AwcObjectUtil.setProperty(ctx.selected, "a24MStatus",  "4M_Skip" );
                            _confirmInspectionRequest(ctx);
                        }
                    ]);
                }else{
                    _confirmInspectionRequest(ctx);
                }
            }

        },
        function() {
            AwcPanelUtil.closeCommandPanel();
            AwcPanelUtil.closePopup();
        }
    ]);
}


let _confirmInspectionRequest = ( ctx ) => { 


    AwcObjectUtil.getProperties(ctx.selected, [ "HasParticipant", "a2IsAutoRequest", "a2PartPeriodListRT" ]).then( () => {
        if(ctx.selected.props.HasParticipant.dbValues.length > 0 || ctx.selected.props.a2IsAutoRequest ) {
            let soaInputParam = {
                name: "[QMS] Confirm Inspection Request",
                description: " ",
                contextData:{
                    attachmentCount : 1,
                    attachments: [ctx.selected.uid],
                    processTemplate : "[QMS] Confirm Inspection Request",
                    attachmentTypes : [1],
                }
            }
            soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( async (e)=>{
                await AwcObjectUtil.getProperty( ctx.selected, "a2IsShowMessage" );
                if( ctx.selected.props.a2IsShowMessage.dbValue ) {
                    _updatePeriodRev( ctx );
                } else {
                    AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRConfirmSuccess"));
                }
                // cosole.log(e);
            }).catch( (e) => {
                AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "IRConfirmFailed") +"\n"+e.message);
            }).finally( async () => {
                eventBus.publish('cdm.relatedModified', {
                    refreshLocationFlag: true,
                    relatedModified: [ctx.selected]
                });
            }); 
        } else {
            AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "IRConfirmFailed") +"\nThere's no participants in this inspection request.");
            return;
        }
    })
}





let _updatePeriodRev = async ( ctx ) => {
    if( ctx.selected.props.a2PartPeriodListRT.dbValues[0] ) {
        let periodRevision = AwcObjectUtil.getObject( ctx.selected.props.a2PartPeriodListRT.dbValues[0] );
        await AwcObjectUtil.getProperties( periodRevision, [ "a2ConversionRule", "a2InspectionPeriod" ] );
        let conversionRule = periodRevision.props.a2ConversionRule.dbValues[0];
        let inspectionPeriod = periodRevision.props.a2InspectionPeriod.dbValues[0];
        let msg = null;
        if( conversionRule == "I-P-N" ) {
            if( inspectionPeriod == "Inspection") {
                msg = `${ locale.getLocalizedText( localeText, "updateConditionSuc" ) }\n${ locale.getLocalizedText( localeText, "IToP" ) }${ locale.getLocalizedText( localeText, "changeAsk" ) }`;
            } else if( inspectionPeriod == "Period-Inspection" ) {
                msg = `${ locale.getLocalizedText( localeText, "updateConditionSuc" ) }\n${ locale.getLocalizedText( localeText, "PToN" ) }${ locale.getLocalizedText( localeText, "changeAsk" ) }`;
            } else {
                msg = null;
            }
        } else {
            if( inspectionPeriod == "Inspection" ) {
                msg = `${ locale.getLocalizedText( localeText, "updateConditionSuc" ) }\n${ locale.getLocalizedText( localeText, "IToN" ) }${ locale.getLocalizedText( localeText, "changeAsk" ) }`;
            } else {
                msg = null;
            }
        }
        if( msg != null ) {
            AwcNotificiationUtil.show( "INFO", msg, [ "YES", "NO" ],
            [
                async () => {
                    let soaInputParam = {
                        name: "[QMS] Update Period Property",
                        description: "",
                        contextData:{
                            attachmentCount : 1,
                            attachments: [ periodRevision.uid ],
                            processTemplate : "[QMS] Update Period Property",
                            attachmentTypes : [1],
                        }
                    }
                    soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( () => {
                        AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( localeText, "IRConfirmSuccess" ) );
                    } );
                },
                () => {}
            ])
        }
    }
}

export function A2QReturnNGCreatePanelAction(data, ctx) {
    let errMsg;
    if(ctx.selected.type != "A2QPartIRItemRevision" || ctx.mselected.length != 1){
        errMsg = "PleaseSelectOneRequest";
    }else if (ctx.selected.props.a2Status.dbValue != 'Completed'){
        errMsg = "PleaseSelectCompletedRequest";
    }else if (ctx.selected.props.a2Result.dbValue != 'OK'){
        errMsg = "ResultNotOK";
    }

    if(errMsg){
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, errMsg));
        return;
    }

    AwcPanelUtil.openCommandPanel("A2QReturnNGCreate");
}

export function A2QReturnNGCreatePreAction(data, ctx) {
    if(data.a2ReturnNGUser == null){
        setTimeout( () => {
            A2QReturnNGCreatePreAction(data, ctx);
        }, 10 );
    }else{
        uwPropertyService.setValue(data.a2ReturnNGUser, ctx.user.uid);
        uwPropertyService.setDisplayValue(data.a2ReturnNGUser, [ctx.user.props.object_string.dbValue]);
        uwPropertyService.setValue(data.a2ReturnNGDate, new Date());
    }
}

export function A2QReturnNGCreateAction(data, ctx) {
    let name = ctx.selected.props.object_name.dbValue;
    let id = ctx.selected.props.item_id.dbValue;
    let rev = ctx.selected.props.item_revision_id.dbValue;
    let user = data.a2ReturnNGUser.dbValue;
    let date = data.a2ReturnNGDate.uiValue;
    let desc = data.object_desc.dbValue;

    AwcObjectUtil.createRuntimeObject(
        [
            {object_name: name},
            {a2PartIRItemId: id},
            {a2PartIRItemRev: rev},
            {a2ReturnNGUser: user},
            {a2ReturnNGDate: date},
            {object_desc: desc}

            
        ],
        data.objCreateInfo.createType
    ).then( async (created) => {
        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "ReturnNGCreateSuccess"));
        AwcPanelUtil.closeCommandPanel();
        
        // 선택된 부품검사의뢰의 Return NG관련 속성 Update(검사의뢰는 Released 상태이므로 Workflow를 생성하여 Update)
        _returnNGPartIRUpdate(ctx, created.ServiceData.created[0]);

    });
}

let _returnNGPartIRUpdate = ( ctx, createdUid ) => { 


    let soaInputParam = {
        name: "[QMS] Return NG Part IR Update",
        description: " ",
        contextData:{
            attachmentCount : 1,
            attachments: [createdUid],
            processTemplate : "[QMS] Return NG Part IR Update",
            attachmentTypes : [1],
        }
    }
    soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( async (e)=>{
        
    }).catch( (e) => {
        AwcNotificiationUtil.show("ERROR", "Part IR Update Failed.\n"+e.message);
    }).finally( async () => {
        eventBus.publish('cdm.relatedModified', {
            refreshLocationFlag: true,
            relatedModified: [ctx.selected]
        });
    }); 
}



export default exports = {
    a2PartInspectionResultOpen,
    A2QPartIRCreateAction,
    A2QPartIRCreateItem,
    A2QIR,
    a2SupplierStringChanged,
    A2QSNReferenceAction,
    A2QSPCReferenceAction,
    A2QPartIRCreateItemPreAction,
    a2PartStringChanged,
    A2PartInspectionRequestConfirm,
    A2QReturnNGCreatePanelAction,
    A2QReturnNGCreatePreAction,
    A2QReturnNGCreateAction
};
app.factory('A2InspectionTemplateService', () => exports);