import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import viewModelObjectSvc from 'js/viewModelObjectService';
import AwcQueryUtil from 'js/AwcQueryUtil';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import locale from 'js/AwcLocalizationUtil';
import soaService from 'soa/kernel/soaService';
import uwPropertyService from 'js/uwPropertyService';
import appCtxService from 'js/appCtxService';
import AwcLocalizationUtil from 'js/AwcLocalizationUtil';

var exports = {};
/**
 * Localization File의 이름.
 */
let localeText = "lgspQmsNewInspectionMessages";

/**
 * Array.sort의 매개변수에서 Sorting을 도와주는 함수
 * Property1/Property2 와 같은 형태로 만들어 Sorting 한다.
 * @param {string} property1 Object의 Property 명
 * @param {string} property2 Object의 Property 명
 * @returns 
 */
function _dynamicSort2(property1, property2) {
    var sortOrder = 1;
    if(property1[0] === "-") {
        sortOrder = -1;
        property1 = property1.substr(1);
    }
    return function (a,b) {
        var result = (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  < b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? -1 : (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  > b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? 1 : 0;
        return result * sortOrder;
    }
}

/**
 * 
 * @param {DeclView} data 
 * @param {contextData} ctx 
 * @param {string} type - 오브젝트 타입
 * @returns 
 */
 export async function A2QProdCreateRuntime(data, ctx, type) {
    if(type == "A2QProdIPCreateRuntime") {
        if(!ctx.pselected) {
            AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "createInspectionPlanFailed"));
            return; 
        }
        if(!( ctx.selected.type == "A2QProdInsItemRevision" || AwcObjectUtil.instanceOf(ctx.selected, "A2QInsTreeObject") ) ) {
            AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "createInspectionPlanFailed"));
            return;
        }
        if( AwcObjectUtil.instanceOf(ctx.selected, "A2QInsTreeObject" ) ) {
            await AwcObjectUtil.getProperty(ctx.selected, "a2InspectionObject");
            let topObject = await AwcObjectUtil.loadObjects(ctx.selected.props.a2InspectionObject.dbValues[0]);
            await AwcObjectUtil.getProperties(topObject, ["a2OrgCode", "a2ProdGroupCode"], true);
            ctx.a2OrgCode = topObject.props.a2OrgCode.dbValues[0];
            ctx.a2ProdGroupCode = topObject.props.a2ProdGroupCode.dbValues[0];
            ctx.a2InspectionTemplateId = topObject.uid;
            ctx.a2InspectionTemplate = topObject.props.item_id.dbValues[0] + "/" + topObject.props.item_revision_id.dbValues[0] + "-" + topObject.props.object_name.dbValues[0];
        } else {
            await AwcObjectUtil.getProperties(ctx.selected, ["a2OrgCode", "a2ProdGroupCode"], true);
            ctx.a2OrgCode = ctx.selected.props.a2OrgCode.dbValues[0];
            ctx.a2ProdGroupCode = ctx.selected.props.a2ProdGroupCode.dbValues[0];
            ctx.a2InspectionTemplateId = ctx.selected.uid;
            ctx.a2InspectionTemplate = ctx.selected.props.item_id.dbValues[0] + "/" + ctx.selected.props.item_revision_id.dbValues[0] + "-" + ctx.selected.props.object_name.dbValue;
        }
    }
    let panel = AwcPanelUtil.openCommandPanel(type);
}


export function A2QProdCreateRuntimePreAction(data, ctx) {
    if(data.a2TemplateType == null){
        setTimeout( () => {
            A2QProdCreateRuntimePreAction(data, ctx);
        }, 10 );
    }else{
        uwPropertyService.setValue(data.a2OrgCode, ctx.a2OrgCode);
        uwPropertyService.setValue(data.a2ProdGroupCode, ctx.a2ProdGroupCode);
        uwPropertyService.setValue(data.a2InspectionTemplateId, ctx.a2InspectionTemplateId);
        uwPropertyService.setValue(data.a2TemplateType, ctx.a2InspectionTemplate);
        ctx.a2OrgCode = undefined;
        ctx.a2ProdGroupCode = undefined;
        ctx.a2InspectionTemplateId = undefined;
        ctx.a2InspectionTemplate = undefined;
    }
}

export async function A2QProdCreateRuntimeAction(data, ctx) {
    let createType = data.objCreateInfo.createType;
    let inspTempId = data.a2InspectionTemplateId.dbValue;
    let a2ModelSuffix = data.a2ModelSuffix.dbValue;
    let a2ModelName = data.a2ModelSuffix.uiValue;
    a2ModelName = a2ModelName.substr(a2ModelName.indexOf("/") + 1, a2ModelName.length);
    
    let inspTemp = AwcObjectUtil.getObject(inspTempId);
    await AwcObjectUtil.getProperties(inspTemp, ["a2OrgCode", "a2ProdGroupCode", "a2SeverityLevel"], true);
    let item_id = inspTemp.props.item_id.dbValues[0];
    let item_revision_id = inspTemp.props.item_revision_id.dbValues[0];
    let object_name = inspTemp.props.object_name.dbValues[0];
    if(!inspTemp.props.a2OrgCode){
        await AwcObjectUtil.getProperty(inspTemp, "a2OrgCode");
    }
    let a2OrgCode = inspTemp.props.a2OrgCode.dbValues[0];
    if(!inspTemp.props.a2ProdGroupCode){
        await AwcObjectUtil.getProperty(inspTemp, "a2ProdGroupCode");
    }
    let a2ProdGroupCode = inspTemp.props.a2ProdGroupCode.dbValues[0];
    let a2TemplateType = item_id + "/" + item_revision_id + "-" + object_name;
    let checkDuplicate = false;
    let createProperties = [
        {a2ModelSuffix: a2ModelSuffix},
        {a2ModelName: a2ModelName},
        {a2TemplateType: a2TemplateType},
        {a2InspTypeName: object_name},
        {a2OrgCode: a2OrgCode},
        {a2ProdGroupCode: a2ProdGroupCode}
    ]
    await AwcQueryUtil.executeSavedQuery( "_Inspection_getInspectionPlan", ["a2SearchOrgCodeRT", "a2SearchProdGroupCodeRT", "a2SearchModelSuffixRT", "a2SearchTemplateTypeRT"],
        [a2OrgCode, a2ProdGroupCode, a2ModelSuffix, item_id]
    ).then( ( searchResult ) => {
        /**
         * Todo 생성 공통함수 만들어서 줄여야지
         */
        if( searchResult && searchResult.length > 0 ) {
            checkDuplicate = true;
        }
        if( checkDuplicate ) {
            AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "existPlan"), ["Yes", "No"], [
                () => {
                    _createProdIPItem( createProperties, createType );
                },
                () => {}
            ])
        } else {
            _createProdIPItem( createProperties, createType );
        }
    })
}

const _createProdIPItem = ( props , type ) => {
    AwcObjectUtil.createRuntimeObject(props, type ).then( async () => {
        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "inspectionPlanCreateSuccess"));
        AwcPanelUtil.closeCommandPanel();
    }).catch( ( e ) => {
        AwcNotificiationUtil.show("ERROR", e.message);
    });
}

export function A2QInsTreeFolderDeleteAction(data, ctx){
    AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "checkDeleteSelected"), ["Yes", "No"], [
        async function () {//YES button function
            let userId = ctx.user.uid;
            await AwcObjectUtil.getProperty(ctx.mselected, "owning_user", "contents");
            let owners = ctx.mselected.map(temp => temp.props.owning_user.dbValue);
            let arrContents = ctx.mselected.map(temp => temp.props.contents.dbValue);

            for (const contents of arrContents) {
                if(contents.length > 0){
                    AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "SubTemplatesExist"));
                    return;
                }
            }
            
            for (const owner of owners) {
                if(userId != owner){
                    AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "DeleteErrorNotOwner"));
                    return;
                }
            }

            let delObjs = {
                objects: []
            }

            for(const uid of ctx.mselected.map(obj => obj.uid)){
                delObjs.objects.push({uid});
            }

            soaService.post( 'Core-2006-03-DataManagement', 'deleteObjects', delObjs ).then( async () => {
                // await A2QmsReIndex(ctx);
                let selectedObjectSetId = Object.values(data.commandPlacements)[0].uiAnchor;
                eventBus.publish( selectedObjectSetId + "_Provider.plTable.reload");
    
                eventBus.publish( 'cdm.relatedModified', {
                    refreshLocationFlag: false,
                    relatedModified: [ ctx.selected ]
                });
            }).catch( (e) => {
                AwcNotificiationUtil.show("ERROR", e.message);
            });

        },
        function () { //NO button function
            return;
        }
    ]);
}
let _getLatestRev = async ( rev ) => {
    let itemsUidArrSet = new Set( rev );
    let itemsUidArr = [...itemsUidArrSet]
    let itemsArr = new Array();
    let returnArr = new Array();

    itemsUidArr.forEach( ( uid ) => {
        itemsArr.push( AwcObjectUtil.getObject( uid ) );
    });

    await AwcObjectUtil.getProperty( itemsArr, "revision_list" );
    itemsArr.forEach( ( item ) => {
        let arrIndex = item.props.revision_list.dbValues.length > 1 ? item.props.revision_list.dbValues.length - 2 : item.props.revision_list.dbValues.length - 1;
        returnArr.push( AwcObjectUtil.getObject( item.props.revision_list.dbValues[ arrIndex ] ) );
    });
    return returnArr;
}


export async function A2QmsReIndex(ctx){
    let objArr = undefined;
    if(ctx.pselected.type.includes('Folder')) {
        await AwcObjectUtil.getProperty(ctx.pselected, "a2Contents", false);
        objArr = ctx.pselected.props.a2Contents.dbValues;
    } else {
        await AwcObjectUtil.getProperty(ctx.pselected, "contents", false);
        objArr = ctx.pselected.props.contents.dbValues;
    }
    objArr = AwcObjectUtil.getObjects(objArr);
    await AwcObjectUtil.getProperty(objArr, "a2Index");
    objArr.sort( ( a, b ) => {
        return Number( a.props.a2Index.dbValues[0] ) - Number( b.props.a2Index.dbValues[0] );
    });

    let idx = 0;
    let soaInputParam = {
        info: []
    };

    for(const obj of objArr){
        let temp = {
            object: obj,
            vecNameVal: [{name:"a2Index", values: [String(idx += 10)]}]
        }
        soaInputParam.info.push(temp);
    }

    await soaService.post( 'Core-2010-09-DataManagement', 'setProperties', soaInputParam );
}

export function A2QProdSimCPCreateRuntimePreAction(data, ctx) {
    if(data.a2ProdInspectionPlan == null){
        setTimeout( () => {
            A2QProdSimCPCreateRuntimePreAction(data, ctx);
        }, 10 );
    }else{
        data.a2ProdInspectionPlan = data.a2ProductTypeId;
        document.getElementById("simCreateListBox").setAttribute("style", "visibility: hidden;");
        ctx.a2ProductTypeIdValues = {
            "type": "STRING",
            "dbValue": [{
                "propDisplayValue": "",
                "propDisplayDescription": "",
                "dispValue": "",
                "propInternalValue": "",
                "iconName": ""
            }]
        };
        AwcQueryUtil.executeSavedQuery("_Inspection_getInspectionPlan", 
            ["a2SearchModelSuffixRT"], 
            ["*"]
        ).then( async (results) => {
            if(results) {
                let LastedRevArr = [];
                await AwcObjectUtil.getProperties(results, ["release_status_list"], true);
                let sortedArray = [];
                for (const sortElement of results) {
                    if( sortElement.type != "A2QProdIPItemRevision" || sortElement.props.a2IsDeleted.dbValues[0] == "YES") continue;
                    if( sortElement.props.release_status_list.dbValues.length > 0 ) sortedArray.push( sortElement.props.items_tag.dbValues[0] );
                }
                LastedRevArr = await _getLatestRev( sortedArray );
                LastedRevArr.sort(_dynamicSort2("item_id", "item_revision_id"));
                // cosole.log({LastedRevArr});
                for (const modelObject of LastedRevArr) {
                    let vmo = viewModelObjectSvc.constructViewModelObjectFromModelObject(modelObject);
                    let displayString = vmo.props.item_id.dbValues[0] + "/" + vmo.props.item_revision_id.dbValues[0];
                    var listBoxRow = {
                        "propDisplayValue": displayString,
                        "propDisplayDescription": vmo.props.object_name.dbValues[0],
                        "dispValue": displayString,
                        "propInternalValue": vmo.uid,
                        "iconName": "typeQcControlInspectionPlan48"
                    };
                    ctx.a2ProductTypeIdValues.dbValue.push(listBoxRow);
                }
                return;
            } else {
                ctx.a2ProductTypeIdValues.dbValue = null;
            }
        });
        // uwPropertyService.setValue(data.a2InspectionTemplateId, ctx.a2InspectionTemplateId);
        // uwPropertyService.setValue(data.a2TemplateType, ctx.a2InspectionTemplate);
        // ctx.a2InspectionTemplateId = undefined;
        // ctx.a2InspectionTemplate = undefined;
    }
}

export async function A2QProdSimCPCreateRuntimeAction(data, ctx) {
    let inspectionPlanUid = data.a2ProductTypeId.dbValue;
    let inspectionPlan = await AwcObjectUtil.loadObjects(inspectionPlanUid);
    await AwcObjectUtil.getProperties(inspectionPlan, ["a2ModelSuffix", "a2ModelName", "a2InspTypeName", "a2TemplateType", "a2OrgCode", "a2ProdGroupCode"], true)
    let a2ModelSuffix = data.a2ModelSuffix.dbValue;
    let a2ModelName = data.a2ModelSuffix.selectedLovEntries[0].propDisplayDescription;
    
    let inspId = inspectionPlan.props.item_id.dbValues[0];
    let inspRevId = inspectionPlan.props.item_revision_id.dbValues[0];
    let inspName = `[${ inspectionPlan.props.a2InspTypeName.dbValues[0] }] ${ a2ModelSuffix } ${ locale.getLocalizedText(localeText, "inspPlan") }`;
    let a2TemplateType = inspId + "/" + inspRevId + "-" + inspName;
    let a2OrgCode = inspectionPlan.props.a2OrgCode.dbValues[0] ? inspectionPlan.props.a2OrgCode.dbValues[0] : "";
    let a2ProdGroupCode = inspectionPlan.props.a2ProdGroupCode.dbValues[0] ? inspectionPlan.props.a2ProdGroupCode.dbValues[0] : "";
    // let item_id = inspectionPlan.props.item_id.dbValues[0];
    let checkDuplicate = false;

    await AwcQueryUtil.executeSavedQuery( "_Inspection_getInspectionPlan", ["a2SearchOrgCodeRT", "a2SearchProdGroupCodeRT", "a2SearchModelSuffixRT", "a2SearchTemplateTypeRT"],
        [ a2OrgCode, a2ProdGroupCode, a2ModelSuffix, inspectionPlan.props.a2TemplateType.dbValues[0] ]
    ).then( ( res ) => {
        if( res && res.length > 0 ) {
            checkDuplicate = true;
        }
        if( checkDuplicate ) {
            AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "existPlan"), ["Yes", "No"], [
                () => {
                    AwcObjectUtil.createRuntimeObject(
                        [
                            {a2ModelSuffix: a2ModelSuffix}, 
                            {a2ModelName:  a2ModelName}, 
                            {a2TemplateType: a2TemplateType},
                            {a2InspTypeName: inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : ""},
                            {a2OrgCode: a2OrgCode},
                            {a2ProdGroupCode: a2ProdGroupCode},
                            {a2ProdInspectionPlan: inspectionPlan.props.item_id.dbValues[0] + "/" + inspectionPlan.props.item_revision_id.dbValues[0] + "-" +  inspectionPlan.props.object_name.dbValues[0]}
                        ],
                        "A2QProdSimCPCreateRuntime"
                    ).then( async () => {
                        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "inspectionPlanCreateSuccess"));
                        AwcPanelUtil.closeCommandPanel();
                        return;
                    }).catch( (e) => {
                        AwcNotificiationUtil.show("INFO", e.message);
                    });
                },
                () => {}
            ])
        } else {
            AwcObjectUtil.createRuntimeObject(
                [
                    {a2ModelSuffix: a2ModelSuffix}, 
                    {a2ModelName:  a2ModelName}, 
                    {a2TemplateType: a2TemplateType},
                    {a2InspTypeName: inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : ""},
                    {a2OrgCode: a2OrgCode},
                    {a2ProdGroupCode: inspectionPlan.props.a2ProdGroupCode.dbValues[0] ? inspectionPlan.props.a2ProdGroupCode.dbValues[0] : ""},
                    {a2ProdInspectionPlan: inspectionPlan.props.item_id.dbValues[0] + "/" + inspectionPlan.props.item_revision_id.dbValues[0] + "-" +  inspectionPlan.props.object_name.dbValues[0]}
                ],
                "A2QProdSimCPCreateRuntime"
            ).then( async () => {
                AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "inspectionPlanCreateSuccess"));
                AwcPanelUtil.closeCommandPanel();
                return;
            }).catch( (e) => {
                AwcNotificiationUtil.show("INFO", e.message);
            });
        }
    } )
}

export let A2QSevertyLevelRuntimeAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel('A2QSevertyLevelRuntime');
}

export let A2QShowFMEACTQRTAction = (data, ctx) => {

    AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, "a2EventProperty", "VIEWFMEACTQLIST").then( async () => {

        await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2FMEACTQListCountRT");
        if(ctx.xrtSummaryContextObject.props.a2FMEACTQListCountRT.dbValues[0] == 0){

            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOCTQResult"));
 
            return;
        }

        eventBus.publish( 'cdm.relatedModified', {
            efreshLocationFlag: true,
            relatedModified: [
                appCtxService.ctx.locationContext.modelObject
            ]
        });
    }).catch((error)=> {
        AwcNotificiationUtil.show("ERROR", error.message);
    });
}


export let A2QShowPARTQualifyRTAction = (data, ctx) => {

    AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, "a2EventProperty", "VIEWPARTQUALIFY").then( async () => {

        await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2PartQualifyListCountRT");
        if(ctx.xrtSummaryContextObject.props.a2PartQualifyListCountRT.dbValues[0] == 0){

            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOPQResult"));
 
            return;
        }

        eventBus.publish( 'cdm.relatedModified', {
            efreshLocationFlag: true,
            relatedModified: [
                appCtxService.ctx.locationContext.modelObject
            ]
        });
    }).catch((error)=> {
        AwcNotificiationUtil.show("ERROR", error.message);
    });
}


export let A2QShowProdQualifyRTAction = (data, ctx) => {

    AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, "a2EventProperty", "VIEWPRODQUALIFY").then( async () => {

        await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2ProdQualifyListCountRT");
        if(ctx.xrtSummaryContextObject.props.a2ProdQualifyListCountRT.dbValues[0] == 0){

            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOProdQResult"));
 
            return;
        }

        eventBus.publish( 'cdm.relatedModified', {
            efreshLocationFlag: true,
            relatedModified: [
                appCtxService.ctx.locationContext.modelObject
            ]
        });
    }).catch((error)=> {
        AwcNotificiationUtil.show("ERROR", error.message);
    });
}

export let A2QShowProdFMEACTQRTAction = (data, ctx) => {

    AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, "a2EventProperty", "VIEWFMEACTQLIST").then( async () => {

        await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2FMEACTQListCountRT");
        if(ctx.xrtSummaryContextObject.props.a2FMEACTQListCountRT.dbValues[0] == 0){

            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOCTQResult"));
 
            return;
        }

        eventBus.publish( 'cdm.relatedModified', {
            efreshLocationFlag: true,
            relatedModified: [
                appCtxService.ctx.locationContext.modelObject
            ]
        });
    }).catch((error)=> {
        AwcNotificiationUtil.show("ERROR", error.message);
    });
}



export let A2QCreatePartIPCheckItemByCTQAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel('A2QCreatePartIPCheckItemByCTQ');

    //AwcPanelUtil.openCommandPanel('A2QCTQRuntime');
    return;
}


export let A2QCTQRuntimeAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel('A2QCTQRuntime');
}

export let A2QSevertyLevelRuntimePreProcess = async (data, ctx) => {
    if(data.a2Target == null){
        setTimeout( () => {
            A2QSevertyLevelRuntimePreProcess(data, ctx);
        }, 10 );
    }else{
        await AwcObjectUtil.getProperties(ctx.xrtSummaryContextObject, ["a2SeverityLevel", "a2NextCount", "a2PrevCount_1"], true);
        let uid = ctx.xrtSummaryContextObject.uid;
        let item_id = ctx.xrtSummaryContextObject.props.item_id.dbValue;
        let object_name = ctx.xrtSummaryContextObject.props.object_name.dbValue;
        let a2SeverityLevel = ctx.xrtSummaryContextObject.props.a2SeverityLevel.dbValue;
        let a2SeverityLevelDisplay = ctx.xrtSummaryContextObject.props.a2SeverityLevel.displayValues;
        let a2NextCount = ctx.xrtSummaryContextObject.props.a2NextCount.dbValue;
        let a2PrevCount = ctx.xrtSummaryContextObject.props.a2PrevCount_1.dbValue;

        uwPropertyService.setValue(data.a2Target, uid);
        uwPropertyService.setDisplayValue(data.a2Target, [item_id + "-" + object_name]);
        uwPropertyService.setValue(data.a2SeverityLevel, a2SeverityLevel);
        uwPropertyService.setDisplayValue(data.a2SeverityLevel, a2SeverityLevelDisplay);
        uwPropertyService.setValue(data.a2NextCount, a2NextCount);
        uwPropertyService.setValue(data.a2PrevCount, a2PrevCount);
    }
}

export let setSevertyLevel = (data, ctx) => {
    let a2Target = ctx.xrtSummaryContextObject.uid;
    let a2SeverityLevel = data.a2SeverityLevel.dbValue;
    let a2NextCount = data.a2NextCount.dbValue;
    let a2PrevCount = data.a2PrevCount.dbValue;

    AwcObjectUtil.createRuntimeObject(
        [
            {a2Target: a2Target},
            {a2SeverityLevel: a2SeverityLevel},
            {a2NextCount: String(a2NextCount)},
            {a2PrevCount: String(a2PrevCount)}
        ],
        data.objCreateInfo.createType
    ).then( async (res) => {
        eventBus.publish( 'cdm.relatedModified', {
            refreshLocationFlag: false,
            relatedModified: [ ctx.selected ]
        });
        AwcPanelUtil.closeCommandPanel();
        return;
    }).catch( (e) => {
        AwcNotificiationUtil.show("INFO", e.message);
    });
}

export let A2QCTQRuntimePreProcess = async (data, ctx) => {
    if(data.a2Target == null && data.a2IsCTQ == null ){
        setTimeout( () => {
            A2QCTQRuntimePreProcess(data, ctx);
        }, 10 );
    }else{
        await AwcObjectUtil.getProperties(ctx.selected, ["a2IsCTQ", "a2CTQMgmtMethod", "a2CTQMgmtSpec", "a2CTQLotCount", "a2Id"], true);
        let uid = ctx.selected.uid;
        let a2Id = ctx.selected.props.a2Id.dbValue;
        let object_name = ctx.selected.props.object_name.dbValue;
        let a2IsCTQ = ctx.selected.props.a2IsCTQ.dbValue;
        let a2CTQMgmtMethod = ctx.selected.props.a2CTQMgmtMethod.dbValue;
        let a2CTQMgmtMethodDisplay = ctx.selected.props.a2CTQMgmtMethod.displayValues;
        let a2CTQMgmtSpec = ctx.selected.props.a2CTQMgmtSpec.dbValue;
        let a2CTQLotCount = ctx.selected.props.a2CTQLotCount.dbValue;

        uwPropertyService.setValue(data.a2Target, uid);
        uwPropertyService.setDisplayValue(data.a2Target, [a2Id + "-" + object_name]);
        uwPropertyService.setValue(data.a2IsCTQ, a2IsCTQ);
        uwPropertyService.setValue(data.a2CTQMgmtMethod, a2CTQMgmtMethod);
        uwPropertyService.setDisplayValue(data.a2CTQMgmtMethod, a2CTQMgmtMethodDisplay);
        uwPropertyService.setValue(data.a2CTQMgmtSpec, a2CTQMgmtSpec);
        uwPropertyService.setValue(data.a2CTQLotCount, a2CTQLotCount);
    }
}

export let setCTQ = (data, ctx) => {
    let a2Target = ctx.selected.uid;
    let a2IsCTQ = data.a2IsCTQ.dbValue;
    let a2CTQMgmtMethod = data.a2CTQMgmtMethod.dbValue;
    let a2CTQMgmtSpec = data.a2CTQMgmtSpec.dbValue;
    let a2CTQLotCount = data.a2CTQLotCount.dbValue;

    if( a2IsCTQ && [ a2CTQMgmtMethod, a2CTQMgmtSpec, a2CTQLotCount ].some( prop => !prop ) ) {
        AwcNotificiationUtil.show( "ERROR", AwcLocalizationUtil.getLocalizedText( localeText, "CTQEmpty" ) );
        return;
    }

    AwcObjectUtil.createRuntimeObject(
        [
            {a2Target: a2Target},
            {a2IsCTQ: String(a2IsCTQ)},
            {a2CTQMgmtMethod: a2CTQMgmtMethod},
            {a2CTQMgmtSpec: String(a2CTQMgmtSpec)},
            {a2CTQLotCount: String(a2CTQLotCount)}
        ],
        data.objCreateInfo.createType
    ).then( async (res) => {
        eventBus.publish( 'cdm.relatedModified', {
            refreshLocationFlag: false,
            relatedModified: [ ctx.selected ]
        });
        AwcPanelUtil.closeCommandPanel();
        return;
    }).catch( (e) => {
        AwcNotificiationUtil.show("INFO", e.message);
    });
}

export let lovValueChanged = ( data, ctx, param ) => {
    let lovValue = param.eventData.lovValue;
    if(lovValue.propDisplayDescription){
        let displayValues = lovValue.propDisplayValue + "/" + lovValue.propDisplayDescription;
        uwPropertyService.setDisplayValue(data[param.propName], [displayValues]);
    }
}

export default exports = {
    A2QProdCreateRuntime,
    A2QProdCreateRuntimePreAction,
    A2QProdCreateRuntimeAction,
    A2QInsTreeFolderDeleteAction,
    A2QProdSimCPCreateRuntimePreAction,
    A2QProdSimCPCreateRuntimeAction,
    A2QSevertyLevelRuntimeAction,
    A2QSevertyLevelRuntimePreProcess,
    setSevertyLevel,
    A2QCTQRuntimeAction,
    A2QCTQRuntimePreProcess,
    setCTQ,
    lovValueChanged,
    A2QShowFMEACTQRTAction,
    A2QCreatePartIPCheckItemByCTQAction,
    A2QShowPARTQualifyRTAction,
    A2QShowProdQualifyRTAction,
    A2QShowProdFMEACTQRTAction
};
app.factory('A2InspectionTemplateService', () => exports);