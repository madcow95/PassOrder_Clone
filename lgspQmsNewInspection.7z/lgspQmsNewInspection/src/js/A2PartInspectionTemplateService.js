/**
 * QMSCommonService
 *
 * @module js/A2InspectionTemplateService
 */

 import app from 'app';
 import AwcObjectUtil from 'js/AwcObjectUtil';
 import eventBus from 'js/eventBus';
 import viewModelObjectSvc from 'js/viewModelObjectService';
 import AwcQueryUtil from 'js/AwcQueryUtil';
 import AwcPanelUtil from 'js/AwcPanelUtil';
 import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
 import locale from 'js/AwcLocalizationUtil';
 import soaService from 'soa/kernel/soaService';
 import uwPropertyService from 'js/uwPropertyService';
 
 var exports = {};
 let localeText = "lgspQmsNewInspectionMessages";
 
 function _dynamicSort2(property1, property2) {
     var sortOrder = 1;
     if(property1[0] === "-") {
         sortOrder = -1;
         property1 = property1.substr(1);
     }
     return function (a,b) {
         /* next line works with strings and numbers, 
          * and you may want to customize it to your needs
          */
         var result = (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  < b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? -1 : (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  > b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? 1 : 0;
         return result * sortOrder;
     }
 }

 /**
  *  제품 검사기준, 제품 유사 검사기준 생성
  */
  export async function A2QPartCreateRuntime(data, ctx, type) {
     if(type == "A2QPartIPCreateRuntime") {
         if(!ctx.pselected) {
             AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "createInspectionPlanFailed"));
             return; 
         }
         if(!( ctx.selected.type == "A2QPartInsItemRevision" || AwcObjectUtil.instanceOf(ctx.selected, "A2QInsTreeObject") ) ) {
             AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "createInspectionPlanFailed"));
             return;
         }
         // await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2SeverityLevel");
         // if(!ctx.xrtSummaryContextObject.props.a2SeverityLevel.dbValue){
         //     AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "EnterSeverity"));
         //     return;
         // }
         if( AwcObjectUtil.instanceOf(ctx.selected, "A2QInsTreeObject" ) ) {
             await AwcObjectUtil.getProperty(ctx.selected, "a2InspectionObject");
             let topObject = await AwcObjectUtil.loadObjects(ctx.selected.props.a2InspectionObject.dbValues[0]);
             await AwcObjectUtil.getProperties(topObject, ["a2OrgCode", "a2PartGroupCode"], true);
             ctx.a2OrgCode = topObject.props.a2OrgCode.dbValues[0];
             ctx.a2PartGroupCode = topObject.props.a2PartGroupCode.dbValues[0];
             ctx.a2PartInspectionTemplateId = topObject.uid;
             ctx.a2PartInspectionTemplate = topObject.props.item_id.dbValues[0] + "/" + topObject.props.item_revision_id.dbValues[0] + "-" + topObject.props.object_name.dbValues[0];
         } else {
             await AwcObjectUtil.getProperties(ctx.selected, ["a2OrgCode", "a2PartGroupCode"], true);
             ctx.a2OrgCode = ctx.selected.props.a2OrgCode.dbValues[0];
             ctx.a2PartGroupCode = ctx.selected.props.a2PartGroupCode.dbValues[0];
             ctx.a2PartInspectionTemplateId = ctx.selected.uid;
             ctx.a2PartInspectionTemplate = ctx.selected.props.item_id.dbValues[0] + "/" + ctx.selected.props.item_revision_id.dbValues[0] + "-" + ctx.selected.props.object_name.dbValue;
         }
     } else {
         AwcPanelUtil.openCommandPanel(type);    
     }
     AwcPanelUtil.openCommandPanel(type);
 }

export async function A2QPartCreateRuntimePreAction(data, ctx) {
    if(data.a2TemplateType == null){
        setTimeout( () => {
            A2QPartCreateRuntimePreAction(data, ctx);
        }, 10 );
    }else{
        AwcObjectUtil.getInitialLOVValues("a2SupplierPeriod", "A2QPartIPCreateRuntime").then( ( res ) => {
            let lovValues = res.lovValues;
            for(let lov of lovValues){
                data.a2SupplierPeriodValues.dbValue.push({
                    "propDisplayValue": lov.propDisplayValues.lov_values[0],
                    "propDisplayDescription": "",
                    "dispValue": lov.propDisplayValues.lov_values[0],
                    "propInternalValue": lov.propInternalValues.lov_values[0],
                    "iconName": ""
                });
            }
        });
        uwPropertyService.setValue(data.a2PartInspectionTemplateId, [ctx.a2PartInspectionTemplateId]);
        uwPropertyService.setDisplayValue( data.a2PartInspectionTemplateId, [ ctx.a2PartInspectionTemplateId ] );
        uwPropertyService.setWidgetDisplayValue( data.a2PartInspectionTemplateId, [ ctx.a2PartInspectionTemplateId ] );
        uwPropertyService.setValue(data.a2TemplateType, [ctx.a2PartInspectionTemplate]);
        uwPropertyService.setDisplayValue( data.a2TemplateType, [ ctx.a2PartInspectionTemplate ] );
        uwPropertyService.setWidgetDisplayValue( data.a2TemplateType, [ ctx.a2PartInspectionTemplate ] );
        uwPropertyService.setValue(data.a2PartGroupCode, [ctx.a2PartGroupCode]);
    }
}

export async function A2QPartCreateRuntimeAction(data, ctx) {
    let createType = document.getElementById("xrtCreate").attributes["object-type"].nodeValue;
    let inspTempId = data.a2PartInspectionTemplateId.dbValue;
    let SupplierString = data.a2SupplierString.dbValue;
    let PartString = data.a2PartString.dbValue;
    let partName = data.a2PartString.uiValue;
    let supplierName = data.a2SupplierString.uiValue;
    let inspObj = null;
    if( ctx.xrtSummaryContextObject.type === "A2QPartInsItemRevision" ) {
        inspObj = ctx.xrtSummaryContextObject;
        await AwcObjectUtil.getProperties( inspObj, [ "a2PartGroupCode", "a2PartGroupPath" ] );
    } else {
        await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2InspectionObject" );
        inspObj = await AwcObjectUtil.getObject( ctx.xrtSummaryContextObject.props.a2InspectionObject.dbValues[0] );
        await AwcObjectUtil.getProperties( inspObj, [ "a2PartGroupCode", "a2PartGroupPath" ] );
    }
    let a2PartGroupCode = inspObj.props.a2PartGroupCode.dbValues[0];
    let a2PartGroupPath = inspObj.props.a2PartGroupPath.dbValues[0];

    partName = partName.substr(partName.indexOf("/") + 1, partName.length);
    supplierName = supplierName.substr(supplierName.indexOf("/") + 1, supplierName.length);
    
    let inspTemp = AwcObjectUtil.getObject(inspTempId);
    await AwcObjectUtil.getProperties(inspTemp, ["a2OrgCode", "a2PartGroupCode"], true);
    let item_id = inspTemp.props.item_id.dbValues[0];
    let item_revision_id = inspTemp.props.item_revision_id.dbValues[0];
    let object_name = inspTemp.props.object_name.dbValues[0];
    if(!inspTemp.props.a2OrgCode){
        await AwcObjectUtil.getProperty(inspTemp, "a2OrgCode");
    }
    let a2OrgCode = inspTemp.props.a2OrgCode.dbValues[0];
    if(!inspTemp.props.a2PartGroupCode){
        await AwcObjectUtil.getProperty(inspTemp, "a2PartGroupCode");
    }
    // let a2PartGroupCode = inspTemp.props.a2PartGroupCode.dbValues[0];
    let a2TemplateType = item_id + "/" + item_revision_id + "-" + object_name;
    // let a2SeverityLevel = inspTemp.props.a2SeverityLevel.dbValues[0];
    let supplierPeriod = data.a2SupplierPeriod.dbValue;
    await AwcQueryUtil.executeSavedQuery( "_Inspection_getPartInspectionPlan", ["a2SearchOrgCodeRT", "a2SearchPartGroupCodeRT", "a2SearchPartStringRT", "a2SearchSupplierStringRT", "a2SearchTemplateTypeRT"],
        [a2OrgCode, a2PartGroupCode, PartString, SupplierString, item_id]
    ).then( ( searchResult ) => {
        /**
         * Todo 생성 공통함수 만들어서 줄여야지
         */
        let props =  [
            {a2SupplierString: SupplierString},
            {a2SupplierName: supplierName},
            {a2TemplateType: a2TemplateType},
            {a2InspTypeName: object_name},
            {a2OrgCode: a2OrgCode},
            {a2PartString: PartString},
            {a2PartName: partName},
            {a2PartGroupCode: a2PartGroupCode},
            {a2SupplierPeriod: supplierPeriod},
            {a2PartGroupPath: a2PartGroupPath},
        ];
        if( searchResult && searchResult.length > 0 ) {
            AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "existPlan"), ["Yes", "No"], [
                () => {
                    AwcObjectUtil.createRuntimeObject( props, createType ).then( async () => {
                        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "inspectionPlanCreateSuccess"));
                        AwcPanelUtil.closeCommandPanel();
                        return;
                    }).catch( (e) => {
                        AwcNotificiationUtil.show("ERROR", e.message);
                    });
                },
                () => {}
            ])
        } else {
            AwcObjectUtil.createRuntimeObject( props, createType ).then( async () => {
                AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "inspectionPlanCreateSuccess"));
                AwcPanelUtil.closeCommandPanel();
                return;
            }).catch( (e) => {
                AwcNotificiationUtil.show("INFO", e.message);
            });
        }
    })
}

export async function A2QPartSimCPCreateRuntimeAction(data, ctx) {
    let inspectionPlanUid = data.a2PartInspectionPlan.dbValue;
    let inspectionPlan = await AwcObjectUtil.loadObjects(inspectionPlanUid);
    await AwcObjectUtil.getProperties(inspectionPlan, ["a2SupplierString", "a2SupplierName", "a2TemplateType", "a2InspTypeName", "a2OrgCode", "a2PartGroupCode", "a2PartString", "a2PartName", "a2SupplierPeriod"], true);
    let a2PartString = data.a2PartString.dbValue;
    let a2PartName = data.a2PartString.selectedLovEntries[0].propDisplayDescription;
    let a2SupplierString = data.a2SupplierString.dbValue;
    let a2SupplierName = data.a2SupplierString.selectedLovEntries[0].propDisplayDescription;
    
    let inspId = inspectionPlan.props.item_id.dbValues[0];
    let inspRevId = inspectionPlan.props.item_revision_id.dbValues[0];
    let inspName = `[${ inspectionPlan.props.a2InspTypeName.dbValues[0] }] ${ a2PartString }(${ a2SupplierString }) ${ locale.getLocalizedText(localeText, "inspPlan") }`;
    let a2TemplateType = inspId + "/" + inspRevId + "-" + inspName;

    let inspPlan = AwcObjectUtil.getObject( data.a2PartInspectionPlan.dbValue );
    await AwcObjectUtil.getProperties( inspPlan, [ "a2PartGroupCode", "a2PartGroupPath" ] );
    let a2PartGroupCode = inspPlan.props.a2PartGroupCode.dbValues[0];
    let a2PartGroupPath = inspPlan.props.a2PartGroupPath.dbValues[0];
    let a2OrgCode = inspectionPlan.props.a2OrgCode.dbValues[0] ? inspectionPlan.props.a2OrgCode.dbValues[0] : "";
    let checkDuplicate = false;

    await AwcQueryUtil.executeSavedQuery( "_Inspection_getPartInspectionPlan", ["a2SearchOrgCodeRT", "a2SearchPartGroupCodeRT", "a2SearchPartStringRT", "a2SearchSupplierStringRT", "a2SearchTemplateTypeRT"],
        [ a2OrgCode, a2PartGroupCode, a2PartString, a2SupplierString, inspectionPlan.props.a2TemplateType.dbValues[0] ]
    ).then( ( res ) => {
        if( res && res.length > 0 ) {
            checkDuplicate = true;
        }
        if( checkDuplicate ) {
            AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "existPlan"), ["Yes", "No"], [
                () => {
                    AwcObjectUtil.createRuntimeObject(
                        [
                            {a2SupplierString: a2SupplierString},
                            {a2SupplierName: a2SupplierName},
                            {a2TemplateType: a2TemplateType},
                            {a2InspTypeName: inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : ""},
                            {a2OrgCode: inspectionPlan.props.a2OrgCode.dbValues[0] ? inspectionPlan.props.a2OrgCode.dbValues[0] : ""},
                            {a2PartString: a2PartString},
                            {a2PartName: a2PartName},
                            {a2PartGroupCode: inspectionPlan.props.a2PartGroupCode.dbValues[0] ? inspectionPlan.props.a2PartGroupCode.dbValues[0] : ""},
                            {a2PartInspectionPlan: inspectionPlan.props.item_id.dbValues[0] + "/" + inspectionPlan.props.item_revision_id.dbValues[0] + "-" +  inspectionPlan.props.object_name.dbValues[0]},
                            {a2SupplierPeriod: inspectionPlan.props.a2SupplierPeriod.dbValues[0] ? inspectionPlan.props.a2SupplierPeriod.dbValues[0] : ""},
                            {a2PartGroupCode: a2PartGroupCode},
                            {a2PartGroupPath: a2PartGroupPath},
                        ],
                        "A2QPartSimCPCreateRuntime"
                    ).then( () => {
                        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "inspectionPlanCreateSuccess"));
                        AwcPanelUtil.closeCommandPanel();
                        return;
                    });
                },
                () => {}
            ])
        } else {
            AwcObjectUtil.createRuntimeObject(
                [
                    {a2SupplierString: a2SupplierString},
                    {a2SupplierName: a2SupplierName},
                    {a2TemplateType: a2TemplateType},
                    {a2InspTypeName: inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : ""},
                    {a2OrgCode: inspectionPlan.props.a2OrgCode.dbValues[0] ? inspectionPlan.props.a2OrgCode.dbValues[0] : ""},
                    {a2PartString: a2PartString},
                    {a2PartName: a2PartName},
                    {a2PartGroupCode: inspectionPlan.props.a2PartGroupCode.dbValues[0] ? inspectionPlan.props.a2PartGroupCode.dbValues[0] : ""},
                    {a2PartInspectionPlan: inspectionPlan.props.item_id.dbValues[0] + "/" + inspectionPlan.props.item_revision_id.dbValues[0] + "-" +  inspectionPlan.props.object_name.dbValues[0]},
                    {a2SupplierPeriod: inspectionPlan.props.a2SupplierPeriod.dbValues[0] ? inspectionPlan.props.a2SupplierPeriod.dbValues[0] : ""},
                    {a2PartGroupCode: a2PartGroupCode},
                    {a2PartGroupPath: a2PartGroupPath},
                ],
                "A2QPartSimCPCreateRuntime"
            ).then( () => {
                AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "inspectionPlanCreateSuccess"));
                AwcPanelUtil.closeCommandPanel();
                return;
            });
        }
    } );
}

 export function A2QPartTreeFolderDeleteAction(data, ctx){
     AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "checkDeleteSelected"), ["Yes", "No"], [
         async function () {//YES button function
             let userId = ctx.user.uid;
             let owners = await AwcObjectUtil.getProperty(ctx.mselected, "owning_user", true);
             for (const owner of owners) {
                 if(userId != owner){
                     await AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "DeleteErrorNotOwner"));
                     return;
                 }
             }
 
             let delObjs = {
                 objects: []
             }
 
             for(const uid of ctx.mselected.map(obj => obj.uid)){
                 delObjs.objects.push({uid});
             }
 
             soaService.post( 'Core-2006-03-DataManagement', 'deleteObjects', delObjs ).then( async () => {
                //  await AwcObjectUtil.getProperty( ctx.pselected, "contents" );
 
                //  let reIndexArr = []
                 
                //  if( ctx.pselected.props.contents.dbValues.length > 0 ) {
                //      ctx.pselected.props.contents.dbValues.forEach( ( uid ) => {
                //          reIndexArr.push( AwcObjectUtil.getObject( uid ) );
                //      });
                //      await AwcObjectUtil.getProperty( reIndexArr, "a2Index" );
                //      let index = 1;
                //      reIndexArr.sort( ( a, b ) => {
                //          return Number( a.props.a2Index.dbValues[0] ) - Number( b.props.a2Index.dbValues[0] );
                //      });
                //      reIndexArr.forEach( ( obj ) => {
                //          AwcObjectUtil.setProperty( obj, "a2Index", String( index * 10 ) );
                //          index++;
                //      });
                //  }
 
                 let selectedObjectSetId = Object.values(data.commandPlacements)[0].uiAnchor;
                 eventBus.publish( selectedObjectSetId + "_Provider.plTable.reload");
     
                 eventBus.publish( 'cdm.relatedModified', {
                     refreshLocationFlag: false,
                     relatedModified: [ ctx.selected ]
                 });
             }).catch( (e) => {
                 AwcNotificiationUtil.show("ERROR", e.message);
             });
 
         },
         function () { //NO button function
             return;
         }
     ]);
 }
 
 
 let PartLOVChanged = ( data, ctx ) => {
     A2QPartSimCPCreateRuntimePreAction( data, ctx );
 }
 let SupplierLOVChanged = ( data, ctx ) => {
     A2QPartSimCPCreateRuntimePreAction( data, ctx );
 }
 
 let _getLatestRev = async ( rev ) => {
     let itemsUidArrSet = new Set( rev );
     let itemsUidArr = [...itemsUidArrSet]
     let itemsArr = new Array();
     let returnArr = new Array();
 
     itemsUidArr.forEach( ( uid ) => {
         itemsArr.push( AwcObjectUtil.getObject( uid ) );
     });
 
     await AwcObjectUtil.getProperty( itemsArr, "revision_list" );
     itemsArr.forEach( ( item ) => {
         let arrIndex = item.props.revision_list.dbValues.length > 1 ? item.props.revision_list.dbValues.length - 2 : item.props.revision_list.dbValues.length - 1;
         returnArr.push( AwcObjectUtil.getObject( item.props.revision_list.dbValues[ arrIndex ] ) );
     });
     return returnArr;
 }
 
 export function A2QPartSimCPCreateRuntimePreAction(data, ctx) {
    if(!data.a2PartInspectionPlan){
        setTimeout( () => {
            A2QPartSimCPCreateRuntimePreAction(data, ctx);
        }, 10 );
    }else{
        data.a2PartInspectionPlan = data.a2PartTypeId;
        ctx.a2PartTypeIdValues = {
            "type": "STRING",
            "dbValue": [{
                "propDisplayValue": "",
                "propDisplayDescription": "",
                "dispValue": "",
                "propInternalValue": "",
                "iconName": ""
            }]
        };
        // await AwcObjectUtil.getProperties( ctx.selected, [ "a2OrgCode", "a2PartString" ] );
        AwcQueryUtil.executeSavedQuery("_Inspection_getPartInspectionPlan", 
            ["a2SearchPartStringRT", "a2SearchSupplierStringRT"], 
            ["*", "*"]
        ).then( async (results) => {
            if(results) {
                let LastedRevArr = [];
                AwcObjectUtil.getProperty(results, "release_status_list" );
                let sortedArray = [];
                for (const sortElement of results) {
                    //// cosole.log(sortElement.props.release_status_list.dbValues.length);
                    // if ( sortElement.props.release_status_list.dbValues.length > 0 ) {
                    //     sortedArray.push(sortElement);
                    // }
                    if( sortElement.type != "A2QPartIPItemRevision" || sortElement.props.a2IsDeleted.dbValues[0] == "YES") continue;
                    if( sortElement.props.release_status_list.dbValues.length > 0 ) sortedArray.push( sortElement.props.items_tag.dbValues[0] );
                }
                LastedRevArr = await _getLatestRev( sortedArray );
                LastedRevArr.sort(_dynamicSort2("item_id", "item_revision_id"));
                // cosole.log({LastedRevArr});
                for (const modelObject of LastedRevArr) {
                    if(modelObject.props.a2IsDeleted.dbValues[0] == "YES") {
                        continue;
                    }
                    let vmo = viewModelObjectSvc.constructViewModelObjectFromModelObject(modelObject);
                    let displayString = vmo.props.item_id.dbValues[0] + "/" + vmo.props.item_revision_id.dbValues[0];
                    var listBoxRow = {
                        "propDisplayValue": displayString,
                        "propDisplayDescription": vmo.props.object_name.dbValues[0],
                        "dispValue": displayString,
                        "propInternalValue": vmo.uid,
                        "iconName": "typeQcControlInspectionPlan48"
                    };
                    ctx.a2PartTypeIdValues.dbValue.push(listBoxRow);
                }
                return;
            } else {
                ctx.a2PartTypeIdValues.dbValue = null;
            }
        });
        // uwPropertyService.setValue(data.a2PartInspectionTemplateId, ctx.a2PartInspectionTemplateId);
        // uwPropertyService.setValue(data.a2PartTemplateType, ctx.a2PartInspectionTemplate);
        // ctx.a2PartInspectionTemplateId = undefined;
        // ctx.a2PartInspectionTemplate = undefined;
    }
}
 
 
 export let A2QSevertyLevelRuntimeAction = (data, ctx) => {
     AwcPanelUtil.openCommandPanel('A2QSevertyLevelRuntime');
 }
 
 export let A2QCTQRuntimeAction = (data, ctx) => {
     AwcPanelUtil.openCommandPanel('A2QCTQRuntime');
 }
 
 export let A2QSevertyLevelRuntimePreProcess = async (data, ctx) => {
     if(data.a2Target == null){
         setTimeout( () => {
             A2QSevertyLevelRuntimePreProcess(data, ctx);
         }, 10 );
     }else{
         await AwcObjectUtil.getProperties(ctx.xrtSummaryContextObject, ["a2SeverityLevel", "a2NextCount", "a2PrevCount_1"], true);
         let uid = ctx.xrtSummaryContextObject.uid;
         let item_id = ctx.xrtSummaryContextObject.props.item_id.dbValue;
         let object_name = ctx.xrtSummaryContextObject.props.object_name.dbValue;
         let a2SeverityLevel = ctx.xrtSummaryContextObject.props.a2SeverityLevel.dbValue;
         let a2SeverityLevelDisplay = ctx.xrtSummaryContextObject.props.a2SeverityLevel.displayValues;
         let a2NextCount = ctx.xrtSummaryContextObject.props.a2NextCount.dbValue;
         let a2PrevCount = ctx.xrtSummaryContextObject.props.a2PrevCount_1.dbValue;
 
         uwPropertyService.setValue(data.a2Target, uid);
         uwPropertyService.setDisplayValue(data.a2Target, [item_id + "-" + object_name]);
         uwPropertyService.setValue(data.a2SeverityLevel, a2SeverityLevel);
         uwPropertyService.setDisplayValue(data.a2SeverityLevel, a2SeverityLevelDisplay);
         uwPropertyService.setValue(data.a2NextCount, a2NextCount);
         uwPropertyService.setValue(data.a2PrevCount, a2PrevCount);
     }
 }
 
 export let setSevertyLevel = (data, ctx) => {
     let a2Target = ctx.xrtSummaryContextObject.uid;
     let a2SeverityLevel = data.a2SeverityLevel.dbValue;
     let a2NextCount = data.a2NextCount.dbValue;
     let a2PrevCount = data.a2PrevCount.dbValue;
 
     AwcObjectUtil.createRuntimeObject(
         [
             {a2Target: a2Target},
             {a2SeverityLevel: a2SeverityLevel},
             {a2NextCount: String(a2NextCount)},
             {a2PrevCount: String(a2PrevCount)}
         ],
         data.objCreateInfo.createType
     ).then( async (res) => {
         eventBus.publish( 'cdm.relatedModified', {
             refreshLocationFlag: false,
             relatedModified: [ ctx.selected ]
         });
         AwcPanelUtil.closeCommandPanel();
         return;
     });
 }
 
 export let A2QCTQRuntimePreProcess = async (data, ctx) => {
     if(data.a2Target == null){
         setTimeout( () => {
             A2QCTQRuntimePreProcess(data, ctx);
         }, 10 );
     }else{
         await AwcObjectUtil.getProperties(ctx.selected, ["a2IsCTQ", "a2CTQMgmtMethod", "a2CTQMgmtSpec", "a2CTQLotCount"], true);
         let uid = ctx.selected.uid;
         let a2Id = ctx.selected.props.a2Id.dbValue;
         let object_name = ctx.selected.props.object_name.dbValue;
         let a2IsCTQ = ctx.selected.props.a2IsCTQ.dbValue;
         let a2CTQMgmtMethod = ctx.selected.props.a2CTQMgmtMethod.dbValue;
         let a2CTQMgmtMethodDisplay = ctx.selected.props.a2CTQMgmtMethod.displayValues;
         let a2CTQMgmtSpec = ctx.selected.props.a2CTQMgmtSpec.dbValue;
         let a2CTQLotCount = ctx.selected.props.a2CTQLotCount.dbValue;
 
         uwPropertyService.setValue(data.a2Target, uid);
         uwPropertyService.setDisplayValue(data.a2Target, [a2Id + "-" + object_name]);
         uwPropertyService.setValue(data.a2IsCTQ, a2IsCTQ);
         uwPropertyService.setValue(data.a2CTQMgmtMethod, a2CTQMgmtMethod);
         uwPropertyService.setDisplayValue(data.a2CTQMgmtMethod, a2CTQMgmtMethodDisplay);
         uwPropertyService.setValue(data.a2CTQMgmtSpec, a2CTQMgmtSpec);
         uwPropertyService.setValue(data.a2CTQLotCount, a2CTQLotCount);
     }
 }
 
 export let setCTQ = (data, ctx) => {
     let a2Target = ctx.selected.uid;
     let a2IsCTQ = data.a2IsCTQ.dbValue;
     let a2CTQMgmtMethod = data.a2CTQMgmtMethod.dbValue;
     let a2CTQMgmtSpec = data.a2CTQMgmtSpec.dbValue;
     let a2CTQLotCount = data.a2CTQLotCount.dbValue;
 
     AwcObjectUtil.createRuntimeObject(
         [
             {a2Target: a2Target},
             {a2IsCTQ: String(a2IsCTQ)},
             {a2CTQMgmtMethod: a2CTQMgmtMethod},
             {a2CTQMgmtSpec: String(a2CTQMgmtSpec)},
             {a2CTQLotCount: String(a2CTQLotCount)}
         ],
         data.objCreateInfo.createType
     ).then( async (res) => {
         eventBus.publish( 'cdm.relatedModified', {
             refreshLocationFlag: false,
             relatedModified: [ ctx.selected ]
         });
         AwcPanelUtil.closeCommandPanel();
         return;
     });
 }
 
 export let A2QPartSimCPCreateRuntime = async ( data, ctx, type) => {
     if(type == "A2QPartIPCreateRuntime") { 
         if(!ctx.pselected) {
             AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "createInspectionPlanFailed"));
             return; 
         }
 
         if(!( ctx.selected.type == "A2QPartInsItemRevision" || AwcObjectUtil.instanceOf(ctx.selected, "A2QInsTreeObject") ) ) {
             AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "createInspectionPlanFailed"));
             return;
         }
         if( AwcObjectUtil.instanceOf(ctx.selected, "A2QInsTreeObject" ) ) {
             await AwcObjectUtil.getProperty(ctx.selected, "a2InspectionObject");
             let topObject = await AwcObjectUtil.loadObjects(ctx.selected.props.a2InspectionObject.dbValues[0]);
             await AwcObjectUtil.getProperties(topObject, ["a2OrgCode", "a2PartGroupCode"], true);
             ctx.a2OrgCode = topObject.props.a2OrgCode.dbValues[0];
             ctx.a2PartGroupCode = topObject.props.a2PartGroupCode.dbValues[0];
             ctx.a2InspectionTemplateId = topObject.uid;
             ctx.a2InspectionTemplate = topObject.props.item_id.dbValues[0] + "/" + topObject.props.item_revision_id.dbValues[0] + "-" + topObject.props.object_name.dbValues[0];
         } else {
             await AwcObjectUtil.getProperties(ctx.selected, ["a2OrgCode", "a2PartGroupCode"], true);
             ctx.a2OrgCode = ctx.selected.props.a2OrgCode.dbValues[0];
             ctx.a2PartGroupCode = ctx.selected.props.a2PartGroupCode.dbValues[0];
             ctx.a2InspectionTemplateId = ctx.selected.uid;
             ctx.a2InspectionTemplate = ctx.selected.props.item_id.dbValues[0] + "/" + ctx.selected.props.item_revision_id.dbValues[0] + "-" + ctx.selected.props.object_name.dbValue;
         }
     }
     let panel = AwcPanelUtil.openCommandPanel(type);
     // AwcPanelUtil.openCommandPanel('A2QPartSimCPCreateRuntime');
 }

 export default exports = {
     A2QPartCreateRuntime,
     A2QPartCreateRuntimePreAction,
     A2QPartCreateRuntimeAction,
     A2QPartTreeFolderDeleteAction,
     A2QPartSimCPCreateRuntimePreAction,
     A2QSevertyLevelRuntimeAction,
     A2QSevertyLevelRuntimePreProcess,
     setSevertyLevel,
     A2QCTQRuntimeAction,
     A2QCTQRuntimePreProcess,
     setCTQ,
     A2QPartSimCPCreateRuntime,
     A2QPartSimCPCreateRuntimeAction,
     PartLOVChanged,
     SupplierLOVChanged
 };
 app.factory('A2InspectionTemplateService', () => exports);