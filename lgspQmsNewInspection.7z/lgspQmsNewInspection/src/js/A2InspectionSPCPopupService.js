import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcQueryUtil from 'js/AwcQueryUtil';
import highcharts from 'highcharts';
import AwcNotificationUtil from 'js/AwcNotificiationUtil'
import locale from 'js/AwcLocalizationUtil';

let localeText = "lgspQmsInspectionMessages";

let exports = {};
// let UID = undefined;

let CURRENT_MODE = undefined;
const TYPE_NAMES = {
    prod: {
        spcSearchQuery: "_Inspection_getInspectionResultFromA2BasedOnId",
    },
    part: {
        spcSearchQuery: "_Inspection_getPartInspectionResultFromA2BasedOnId",
    },
}
const SPCModule = {
    formatDate(v) {
        let date = new Date(v);
        if (v === undefined) date = new Date();
        else date = new Date(v);
        date.setHours(date.getHours() + 9);
        return date.toISOString().replace('T', ' ').substring(0, 23);
    },
    async getInputData({basedOnId, CTQLotCount}) {
        const inputData = [];
        if (!basedOnId) {
            // AwcNotificationUtil.show("ERROR", "검사 항목 정보가 없습니다.");
            AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "NoInspInfo"));
            return inputData;
        }
        let results = [];
        try {
            await AwcQueryUtil.executeSavedQuery(TYPE_NAMES[CURRENT_MODE].spcSearchQuery, ['A2BasedOnId'], [basedOnId]).then( ( res ) => {
                res.sort( ( a, b ) => {
                    a = new Date( a.props.date_released.dbValues[0] );
                    b = new Date( b.props.date_released.dbValues[0] );
                    return b - a;
                });
                results = res;
            });
        } catch(e) {
            // 
        }

        if (!results || (results && results.length<1)) {
            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "NoPastData"));
            return inputData;
        }
        if( results.length > 1 ) {
            results.splice(CTQLotCount);
        }
        const tmpResult = results[0];

        const planUid = tmpResult.props.a2InspectionPlan.dbValues[0];

        if (!planUid) {
            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "NoInspStdInfo"));
            return inputData; 
        }

        const planItem = await AwcObjectUtil.loadObjects(planUid);
        await AwcObjectUtil.getProperties(planItem, ["item_id", "date_released"]);
        const planItemId = planItem.props.item_id.dbValues[0];
        const planReleasedDate = this.formatDate(planItem.props.date_released.dbValues[0]);
        const inspectDataList = [];
        let exLotNo = "";
        for (const result of results) {
            let resultLOTNo = result.props.a2QLotNo.dbValues.toString();
            if( exLotNo == resultLOTNo ) {
                resultLOTNo = resultLOTNo + "_";
            }
            exLotNo = resultLOTNo;
            const resultDateReleased = result.props.date_released.dbValues[0];
            const resultSampleSize = result.props.a2SampleSize.dbValues[0];
            for (let i=1; i <= parseInt(resultSampleSize); i++) {
                inspectDataList.push({
                    inspect_data: parseFloat(result.props[`a2D${String(i).padStart(2,0)}`].dbValues[0]),
                    inspect_dt: this.formatDate(resultDateReleased),
                    insp_id: planItemId,
                    lot_id: resultLOTNo
                });
            }
        }
        let Lower = tmpResult.props.a2Lsl.uiValues[0] === "/" ? "" : parseFloat(tmpResult.props.a2Lsl.uiValues[0]);
        let Upper = tmpResult.props.a2Usl.uiValues[0] === "/" ? "" : parseFloat(tmpResult.props.a2Usl.uiValues[0]);
        const specInfo = {
            SPECDATE: planReleasedDate,
            // insp_id: planUid,
            insp_id: planItemId,
            managechart_yn: "N",
            specLower: Lower,
            specUpper: Upper,
            specMid: parseFloat( Lower + Upper) / 2,
            sample_size: parseInt(tmpResult.props.a2SampleSize.dbValues[0]),
        };
        inputData.push({
            InspectDataList: inspectDataList,
            specInfo: {
                chart_code: 'xbarr',
                ...specInfo
            },
        })
        inputData.push({
            InspectDataList: inspectDataList,
            specInfo: {
                chart_code: 'xrs',
                ...specInfo
            },
        })
        return inputData;
    },
    async getSPCData({inputData}) {
        if (inputData.length) {
            let outputData = [];
            try {
                const spcRes = await fetch('https://qps-detest-idx.singlex.com/web-statistics/spc-stat', {
                    method: 'POST',
                    body: JSON.stringify(inputData),
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8',
                    }
                });
                const text = await spcRes.text();
                const tmp = text.replaceAll(/[^\"a-zA-Z]{1}([a-zA-Z]+)[^\"a-zA-Z]{1}/g, '"$1"')
                outputData = JSON.parse(tmp);
            } catch(e) {
                alert('SPC 서버가 응답하지 않습니다.')
            }
            return outputData;
        } else {
            return [];
        }
    },
}

const chartModule = {
    formatDate(v) {
        const date = new Date(v);
        date.setHours(date.getHours() + 9);
        return date.toISOString().replace('T', ' ').substring(0, 23);
    },
    renderChart: function (payload) {
        const {title, targetElementId, chartXAxis, chartYAxis, chartSeries} = payload;

        const chart = highcharts.chart({
            chart: {
                renderTo: document.getElementById(targetElementId),
                animation: false,
                // width: '100',
                height: '300',
            },
            legend: false,
            title: {
                text: title,
                color: '#000',
            },
            plotOptions: {
                series: {
                    animation: false,
                },
            },
            xAxis: chartXAxis,
            yAxis: chartYAxis,
            series: chartSeries,
            credits: {
                enabled: false
            },
            tooltip: {
                useHTML: true,
                formatter: function() {
                    if (this.point.abNormalNumbers && this.point.abNormalNumbers.length) {
                        // return this.y + '<br/>' + this.point.abNormalNumbers.toString();
                        return `<table><tr><th colspan="2">${this.y}</th></tr><tr><td style="padding-right: 0.4rem">Western Rules</td><td style="color: #ff0000;">${this.point.abNormalNumbers.toString()}</td></tr></table>`;
                    } else {
                        // return this.y+'<b>bold test</b>myname<br/>'+this.point.test;
                        return `<table><tr><th colspan="2">${this.y}</th></tr></table>`;
                    }
                },
            }
        });
        chart.reflow();
    },
    renderSPCSubChart: function(payload) {
        const {title, targetElementId, chartData} = payload;

        const manageMax = chartData.MANAGE_MAX[0];
        const manageSTD = chartData.MANAGE_STD[0];
        const manageMIN = chartData.MANAGE_MIN[0];

        const tmpValue = [
            ...chartData.inspect_data,
            manageMax,
            manageSTD,
            manageMIN
        ];
        const valueMax = Math.max(...tmpValue) + 3;
        const valueMin = Math.min(...tmpValue) - 3;

        const chartXAxis = {};
        const chartYAxis = {
            max: valueMax,
            min: valueMin,
            plotLines: [{
                value: manageMax,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,0,255,0.5)',
            }, {
                value: manageSTD,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,0,255,0.5)',
            }, {
                value: manageMIN,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,0,255,0.5)',
            }],
            plotBands: [{
                from: manageMIN,
                to: manageMax,
                color: 'rgba(0,0,255,0.05)',
            }],
        };
        const chartSeries= [];
        const series = {
            type: 'line',
            // name: lot.lotNo,
            data: [],
            dataLabels: {
                enabled: true,
            },
            // color: '#c0c0c0',
            marker: {
                symbol: 'circle', //'square','diamond', 'triangle' 'triangle-down'.
                enabled: true,
            },
            events: {
                legendItemClick: function (e) {
                    e.preventDefault();
                }
            }
        }
        for (const index in chartData.inspect_data) {
            const inspect_data = chartData.inspect_data[index];
            const abNormalNumbers = [];
           
            for (const num of Array.from({length: 8}, (_, i) => i+1)) {
                const key = 'abnormal' + num;
                const value = chartData[key][index];

                if (value) {
                    abNormalNumbers.push(num);
                }
            }

            series.data.push({
                y: inspect_data,
                // color: bad ? "#f00": undefined,
                abNormalNumbers
            })
        }
        chartSeries.push(series);

        this.renderChart({title, targetElementId, chartXAxis, chartYAxis, chartSeries});

    },
    renderSPCMainChart: function(payload) {
        const {title, targetElementId, chartData} = payload;

        const specLower = chartData.specLower[0];
        const specMid = chartData.specMid[0];
        const specUpper = chartData.specUpper[0];

        const manageMax = chartData.MANAGE_MAX[0];
        const manageSTD = chartData.MANAGE_STD[0];
        const manageMIN = chartData.MANAGE_MIN[0];

        const tmpValue = [
            ...chartData.inspect_data,
            specLower,
            specMid,
            specUpper,
            manageMax,
            manageSTD,
            manageMIN
        ];
        const valueMax = Math.max(...tmpValue) + 3;
        const valueMin = Math.min(...tmpValue) - 3;

        const chartXAxis = {};
        const chartYAxis = {
            max: valueMax,
            min: valueMin,
            marker: {
                fillColor: '#FFFFFF',
                lineWidth: 2,
                lineColor: '#00FF00',
            },
            plotLines: [{
                value: specLower,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,255,0,0.5)',
            }, {
                value: specMid,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,255,0,0.5)',
            }, {
                value: specUpper,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,255,0,0.5)',
            }, {
                value: manageMax,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,0,255,0.5)',
            }, {
                value: manageSTD,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,0,255,0.5)',
            }, {
                value: manageMIN,
                dashStyle: "solid",
                width: 1,
                color: 'rgba(0,0,255,0.5)',
            }],
            plotBands: [{
                from: specLower,
                to: specUpper,
                color: 'rgba(0,255,0,0.05)',
            }, {
                from: manageMIN,
                to: manageMax,
                color: 'rgba(0,0,255,0.05)',
            }],
        };
        const chartSeries= [];
        const series = {
            type: 'line',
            // name: lot.lotNo,
            data: [],
            dataLabels: {
                enabled: true,
            },
            // color: '#c0c0c0',
            marker: {
                symbol: 'circle', //'square','diamond', 'triangle' 'triangle-down'.
                enabled: true,
                fillColor: "#00f",
                lineWidth: 2,
            },
            events: {
                legendItemClick: function (e) {
                    e.preventDefault();
                }
            }
        }
        for (const index in chartData.inspect_data) {
            const inspect_data = chartData.inspect_data[index];
            const bad = chartData.bad[index];
            const abNormalNumbers = [];
           
            for (const num of Array.from({length: 8}, (_, i) => i+1)) {
                const key = 'abnormal' + num;
                const value = chartData[key][index];
                if (value) {
                    abNormalNumbers.push(num);
                }
            }

            series.data.push({
                y: inspect_data,
                marker: {
                    fillColor: bad ? "#f00": undefined,
                    lineColor: abNormalNumbers.length ? "#f00" : undefined,
                },
                abNormalNumbers
            })
        }
        chartSeries.push(series);

        this.renderChart({title, targetElementId, chartXAxis, chartYAxis, chartSeries});
    },
}
export async function loaded(data, ctx) {
    data.inspectionItemName.uiValue = ctx.selected.props.a2InsSpec.displayValues[0];
    data.checkSheetName.uiValue = ctx.selected.props.a2CheckSheetObject.displayValues[0];
    data.inspectionTemplateName.uiValue = ctx.selected.props.a2InspectionPlan.displayValues[0];

    if (/Prod/.test(ctx.selected.type)) {
        CURRENT_MODE = 'prod'; 
    } else if (/Part/.test(ctx.selected.type)) {
        CURRENT_MODE = 'part'; 
    } else{
        // AwcNotificationUtil.show("ERROR", "type을 알 수 없습니다");
        AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "unknownType"));
        
    }

    const isCTQ =  ctx.selected.props.a2IsCTQ.dbValues[0];
    const a2BasedOnId = ctx.selected.props.a2BasedOnId.dbValues[0];
    // const a2LOTNo = parseInt(ctx.selected.props.a2LOTNo.dbValues[0]? ctx.selected.props.a2LOTNo.dbValues[0] : "30");
    const a2CTQLotCount = ctx.selected.props.a2CTQLotCount.dbValues[0]? parseInt(ctx.selected.props.a2CTQLotCount.dbValues[0]) : 30;

    if (!parseInt(isCTQ)) {
        // AwcNotificationUtil.show("WARNING", "CTQ 대상이 아닙니다.");
        AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "NoCtqTarget"));
        AwcPanelUtil.closePopup();
    } else {
        const inputData = await SPCModule.getInputData({basedOnId: a2BasedOnId, CTQLotCount: a2CTQLotCount});
        if (inputData.length) {
            const outputData = await SPCModule.getSPCData({inputData});
            if (outputData.length) {
                chartModule.renderSPCMainChart({title: 'X-Bar Chart', targetElementId: "xbarChart", chartData: outputData[0].mainChartData});
                chartModule.renderSPCSubChart({title: 'Range Chart', targetElementId: "rChart", chartData: outputData[0].subChartData});
                chartModule.renderSPCMainChart({title: 'Individuals Chart', targetElementId: "iChart", chartData: outputData[1].mainChartData});
                chartModule.renderSPCSubChart({title: 'Moving Range Chart', targetElementId: "mrChart", chartData: outputData[1].subChartData});

                const statisticsData = outputData[0].statisticsData;
                const parseString = (i) => {
                    if( String( i ).includes( "." ) ) {
                        return String( parseFloat( i ).toFixed( String( i ).split( "." )[1].length ) );
                    } else {
                        return String( parseFloat( i ).toFixed( 3 ) );
                    }
                }
                data.statisticsPp.uiValue = parseString(statisticsData.Pp);
                data.statisticsLSL.uiValue = parseString(statisticsData.LSL);
                data.statisticsPValue.uiValue = parseString(statisticsData['p-value']);
                data.statisticsPT.uiValue = parseString(statisticsData.PT);
                data.statisticsPU.uiValue = parseString(statisticsData.PU);
                data.statisticsCL.uiValue = parseString(statisticsData.CL);
                data.statisticsPpk.uiValue = parseString(statisticsData.Ppk);
                data.statisticsM.uiValue = parseString(statisticsData.M);
                data.statisticsCp.uiValue = parseString(statisticsData.Cp);
                data.statisticsUSL.uiValue = parseString(statisticsData.USL);
                data.statisticsLCL.uiValue = parseString(statisticsData.LCL);
                data.statisticsPL.uiValue = parseString(statisticsData.PL);
                data.statisticsUCL.uiValue = parseString(statisticsData.UCL);
                data.statisticsCpk.uiValue = parseString(statisticsData.Cpk);
                data.statisticsZst.uiValue = parseString(statisticsData.Zst);
                data.statisticsZlt.uiValue = parseString(statisticsData.Zlt);
            }
        }
    }
}
export async function closePopup() {
    AwcPanelUtil.closePopup();
}
export default exports = {
    loaded,
    closePopup,
}
app.factory('A2InspectionSPCPopupService', () => exports);