import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import soaService from 'soa/kernel/soaService';
import locale from 'js/AwcLocalizationUtil';
import viewModelService from 'js/viewModelService';
import _ from 'lodash';
import uwPropertyService from 'js/uwPropertyService';
import viewModelObjectSvc from 'js/viewModelObjectService';
import AwcQueryUtil from 'js/AwcQueryUtil';
import appCtxService from 'js/appCtxService';
import editHandlerService from 'js/editHandlerService';
import AwcPageUtil from 'js/AwcPageUtil';
import navigationSvc from 'js/navigationService';
import popupSvc from 'js/popupService';
import { AstNode } from 'tinymce';
 
var exports = {};
let localeText = "lgspQmsNewInspectionMessages";

let __FromToValdiation = ( data ) => {
    let tableElement = document.getElementById( "SampleRangeEntryTable" );
    let table = viewModelService.getViewModelUsingElement( tableElement );
    let vmCol = table.dataProviders.SampleEntryTableDataProvider.viewModelCollection;
    let FRRange = [ "a2From", "a2To" ];
    let bool = true;
    if( vmCol.loadedVMObjects.length > 0 ) {
        for( const vmo of vmCol.loadedVMObjects ) {
            for( const fr of FRRange ) {
                if( Number( vmo.props.a2From.dbValues[0] ) <= Number( data[fr].dbValues[0] ) && Number( data[fr].dbValues[0] <= Number( vmo.props.a2To.dbValues[0] ) ) ) {
                    bool = false;
                    break;
                }
            }
        }
    }
    return bool;
}

let _RangeValidation = ( data ) => {
    let checkArr = [ 'a2From', 'a2To', 'a2AC', 'a2RE', 'a2SampleSize', 'a2SampleUnit' ];

    let result = checkArr.every( ( check ) => { 
        return data[check].displayValues[0].length > 0 
    } ) ? { result: true, errMsg: '' } : { result: false, errMsg: 'notEnter' };

    if( result.result ) {
        if( Number( data.a2From.dbValues[0] ) >= Number( data.a2To.dbValues[0] ) ) {
            result = { result: false, errMsg: 'fromBig' };
        }
    }

    if( result.result ) {
        if( Number( data.a2AC.dbValues[0] ) > Number( data.a2RE.dbValues[0] ) ) {
            result = { result: false, errMsg: 'ACBig' };
        }
    }

    return result;
}

export async function A2QmsReIndex(ctx){
    let objArr = undefined;
    if(ctx.pselected.type.includes('Folder')) {
        await AwcObjectUtil.getProperty(ctx.pselected, "a2Contents", false);
        objArr = ctx.pselected.props.a2Contents.dbValues;
    } else {
        await AwcObjectUtil.getProperty(ctx.pselected, "contents", false);
        objArr = ctx.pselected.props.contents.dbValues;
    }
    objArr = AwcObjectUtil.getObjects(objArr);
    await AwcObjectUtil.getProperty(objArr, "a2Index");
    objArr.sort( ( a, b ) => {
        return Number( a.props.a2Index.dbValues[0] ) - Number( b.props.a2Index.dbValues[0] );
    });

    let idx = 0;
    let soaInputParam = {
        info: []
    };

    for(const obj of objArr){
        let temp = {
            object: obj,
            vecNameVal: [{name:"a2Index", values: [String(idx += 10)]}]
        }
        soaInputParam.info.push(temp);
    }

    await soaService.post( 'Core-2010-09-DataManagement', 'setProperties', soaInputParam );
}

export let A2QmsDeleteAction = async ( ctx ) => {
    //if objects are multi-selected
    for( const selected of ctx.mselected ) {
        await AwcObjectUtil.getProperty( selected, "a2IsDeleted" );
        if( selected.props.a2IsDeleted && selected.props.a2IsDeleted.dbValues[0] ) {
            let soaInputParam = {
                name: "[QMS] A2IsDeleted to YES",
                description: " ",
                contextData:{
                    attachmentCount : ctx.mselected.length,
                    attachments: [],
                    processTemplate : "[QMS] A2IsDeleted to YES",
                    attachmentTypes : [],
                }
            }
            soaInputParam.contextData.attachments.push( selected.uid );
            soaInputParam.contextData.attachmentTypes.push( 1 );
            soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).catch( ( e ) => {
                AwcNotificiationUtil.show("ERROR", e.message);
            } ).finally( () => {
                eventBus.publish('primaryWorkarea.reset');
            } );
        }
    }
}


let _removeQObj = async ( ctx ) => {
    let delData = {
        objects: []
    }
    if( ctx.selected.type.includes( 'Period' ) || ctx.selected.type.includes( 'Item' ) && !ctx.selected.type.includes( 'Check' ) ) {
        for( const item of ctx.mselected ) {
            delData.objects.push( AwcObjectUtil.getObject( item.props.items_tag.dbValues[0] ) );
        }
    } else {
        for( const obj of ctx.mselected ) {
            delData.objects.push( await AwcObjectUtil.getObject( obj.uid ) );
        }
    }
    __deleteAction( ctx, delData );
}

let __deleteAction = async ( ctx, delData ) => {
    let currentUser = ctx.user.uid;
    for( const obj of delData.objects ) {
        await AwcObjectUtil.getProperty( obj, "owning_user" );
        let createUser = obj.props.owning_user.dbValues[0];
        if( currentUser != createUser ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'DeleteErrorNotOwner' ) );
            return false;
        }
    }
    soaService.post( 'Core-2006-03-DataManagement', 'deleteObjects', delData ).then( async () => {
        /**
         * 삭제 후 Re Index 주석처리
         */
        // let reIndexArr = [];
        // await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2Contents" );
        // if( ctx.xrtSummaryContextObject.props.a2Contents ) {
        //     reIndexArr = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.a2Contents.dbValues );
        // }
        // await AwcObjectUtil.getProperty( reIndexArr, "a2Index" );
        // reIndexArr.sort( ( a, b ) => {
        //     return parseInt( a.props.a2Index.dbValues[0] ) - parseInt( b.props.a2Index.dbValues[0] );
        // } );
        // let Index = 1;
        // for( const obj of reIndexArr ) {
        //     await AwcObjectUtil.setProperties3( obj, [ "a2Index" ], [ String( Index * 10 ) ]);
        //     Index++;
        // }
        eventBus.publish('primaryWorkarea.reset');
        if(ctx.xrtSummaryContextObject.type == "A2QPartInsPeriodRuntime" || ctx.xrtSummaryContextObject.type == "A2QPartIRItemRevision"){
            eventBus.publish( 'ObjectSet_2_Provider.plTable.reload' );
        }
    }).catch( ( e ) => {
        AwcNotificiationUtil.show( "ERROR", e.message );
        // A2QmsDeleteAction( ctx );
    });
}

let _getMaxIndex = async ( ctx ) => {
    await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2Contents", false);
    let stdObjArr =  ctx.xrtSummaryContextObject.props.a2Contents.dbValues;
    let a2Index = 10;
    if( stdObjArr.length > 0 ) {
        stdObjArr = AwcObjectUtil.getObjects( stdObjArr );
        await AwcObjectUtil.getProperty( stdObjArr, "a2Index" );
        let maxNum = 0;
        for ( const obj of stdObjArr ) {
            let index = Number.parseInt( obj.props.a2Index.dbValues[0] );
            if( maxNum < index ) maxNum = index;
        }
        a2Index = maxNum + 10;
    }
    return a2Index;
}


export let createObject = async ( data, ctx ) => {
    // validation
    await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2Contents" );
    if( data.objCreateInfo.createType == "A2QSampleRangeEntry" ) {
        let valResult = _RangeValidation( data );
        if( !valResult.result ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, valResult.errMsg ) );
            return false;
        }

        if( !__FromToValdiation( data ) ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "ExistSampleRange" ) );
            return false;
        }
    }
    if( data.a2Code && !await _PropValidation( data, ctx ) ) {
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'ExistWSO' ) );
        return false;
    }
    if( data.objCreateInfo.createType.includes( "Period" ) ) {
        if( data.revision__a2ConversionRule.dbValue == "I-P-N" ) {
            if( !data.revision__a2PeriodUnit.dbValue || !data.revision__a2PeriodCount.dbValue ) {
                AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'IPNRequired' ) );
                return false;
            }
        }
        let contentsArr = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.a2Contents.dbValues );
        let validationArr = [ "revision__a2OrgCode", "revision__a2PartString", "revision__a2SupplierString", "revision__a2InspectionPlan" ]
        for( const content of contentsArr ) {
            let existCheck = 0;
            for( const validationProp of validationArr ) {
                let validationFilter = validationProp.replace( "revision__", "" );
                await AwcObjectUtil.getProperty( content, validationFilter );
                if( data[ validationProp ].dbValue == content.props[ validationFilter ].dbValues[0] ) {
                    existCheck++;
                }
            }
            if( validationArr.length == existCheck ) {
                AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'ExistPeriod' ) );
                return false;
            }
        }
    }
    if( data.objCreateInfo.createType.includes( "A2QAnnualPlan" ) ) {
        for( const uid of ctx.xrtSummaryContextObject.props.a2Contents.dbValues ) {
            let APObj = await AwcObjectUtil.getObject( uid );
            await AwcObjectUtil.getProperties( APObj, [ "a2Year", "a2OrgCode" ] );
            if( Number( data.a2Year.dbValue ) == Number( APObj.props.a2Year.dbValues[0] ) && data.a2OrgCode.dbValue == APObj.props.a2OrgCode.dbValues[0] ) {
                AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'existAnnualPlan' ) );
                return false;
            }
        }
        let prodSearchCriteriaArr = [
            "a2SearchProdGroupPathRT","a2SearchPlanChangeTypeRT",
            "a2SearchHasPTPlanRT", "a2SearchIsUsedRT","a2SearchConfirmYNRT"
        ];
        let partSearchCriteriaArr = [
            "a2SearchPartGroupPathRT","a2SearchPartGroup3RT", "a2SearchPlanChangeTypeRT", 
            "a2SearchHasPTPlanRT","a2SearchIsUsedRT","a2SearchConfirmYNRT"
        ];
        let searchCriteria = data.objCreateInfo.createType.includes( "Prod" ) ? prodSearchCriteriaArr : partSearchCriteriaArr;
        data.a2SearchCriteria = {
            dbValue : searchCriteria.toString()
        }
    }
    _refactoredCreateObject( data, ctx );
}

export let _refactoredCreateObject = async ( data, ctx ) => {
    // property mapping
    let createProperties = [
        { object_name : data.object_name.dbValue }
    ]
    let objType = data.objCreateInfo.createType;
    let a2Index = 10;
    if( !objType.includes( "Period" ) ) {
        a2Index = await _getMaxIndex( ctx );
        createProperties.push(
            { a2Index : a2Index.toString() }
        )
    }

    for( const prop in data ) {
        if( prop.includes( "a2" ) ) {
            let filterProp = prop;
            let value = data[ prop ].dbValue ? data[ prop ].dbValue : data[ prop ].dbValues[0] ? data[ prop ].dbValues[0] : "";
            if( _.isNumber( value ) ) {
                value = String( value );
            }
            createProperties.push(
                { [ filterProp ] : value }
            )
        }
    }
    _refactoredCreateAction( objType, createProperties );
}

let _refactoredCreateAction = ( objType, createProperties ) => {
    // 실제 생성
    AwcObjectUtil.createRuntimeObject(
        createProperties,
        objType
    ).then( () => {
        AwcPanelUtil.closeCommandPanel();
    } ).catch( ( e ) => {
        AwcNotificiationUtil.show("ERROR", e.message);
    } ).finally( () => {
        eventBus.publish( 'primaryWorkarea.reset' );
    } );
}

let _PropValidation = async ( data, ctx ) => {
    await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, 'a2Contents' );
    let WSOArr = await AwcObjectUtil.getObjects( ctx.xrtSummaryContextObject.props.a2Contents.dbValues );

    let bool = true;
    await AwcObjectUtil.getProperty( WSOArr, 'a2Code' );
    if( WSOArr.length > 0 ) {
        bool = WSOArr.every( ( WSO ) => { return WSO.props.a2Code.dbValues[0] != data.a2Code.dbValues[0] } );
        if( bool ) {
            bool = WSOArr.every( ( WSO ) => { return WSO.props.object_name.dbValues[0] != data.object_name.dbValues[0] } );
        }
    }
    return bool;
}
 
export let load = ( data, ctx ) => {
    const interval = setInterval( () => {
        if( ctx.xrtSummaryContextObject ) {
            if( data.objCreateInfo ) {
                clearInterval( interval );
                if( ctx.selected.type.includes( 'SampleRange' ) ) {
                    let SampleCode = null;
                    if( data.object_name ) {
                        if( ctx.selected.type == "A2QSampleRangeWSO" ) {
                            SampleCode = ctx.selected.props.a2SampleRangeCode.dbValues[0];
                        } else if( ctx.selected.type == "A2QSampleRangeEntry" ) {
                            SampleCode = ctx.selected.props.object_name.dbValues[0]
                        }
                        uwPropertyService.setValue( data.object_name, [ SampleCode ] );
                    }
                }
        
                if( ctx.xrtSummaryContextObject.type == "A2QAPProdMgmtFolder" || ctx.xrtSummaryContextObject.type == "A2QAPPartMgmtFolder" ) {
                    if( data.a2Year && data.object_name ) {
                        let nowDate = new Date();
                        let year = parseInt( nowDate.getFullYear() + 1 );
                        let msg = ctx.xrtSummaryContextObject.type.includes( "Prod" ) ? "APForProd" : "APForPart"
                        uwPropertyService.setValue( data.a2Year, [ year.toString() ] );
                        uwPropertyService.setValue( data.object_name, [ `${locale.getLocalizedText( localeText, msg ) } [${ year.toString() }]${ locale.getLocalizedText( localeText, "year" ) } ${ locale.getLocalizedText( localeText, "AnnualPlan" ) } (월간)` ] );
                    }
                }
            }
        }
    } );
}

export let QObjCreateAction = () => {
    AwcPanelUtil.openCommandPanel( "A2QObjCreate" );
}

export let createSREntryAction = () => {
    AwcPanelUtil.openCommandPanel( "A2QSREntryCreate" );
}

export let A2CreateRuntimeObjectAction = ( commandId, commandCxt ) => {
    appCtxService.registerCtx( "A2QFilterType", commandCxt.parameterMap[ commandId ].CreateLocation );
    AwcPanelUtil.openCommandPanel( commandCxt.parameterMap[ commandId ].type );
}

export let QObjDeleteAction = ( ctx ) => {
    AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "checkDeleteSelected" ), 
                             [ "Yes", "No" ], 
                             [
                                async () => {
                                    // 기준 정보의 각 코드들을 삭제할 때, 사용중인 검사 템플릿이 있다면 return
                                    if( ctx.selected.type.includes( "WSO" ) && !ctx.selected.type.includes( "Sample" ) ) {
                                        let a2Code    = ctx.selected.props.a2Code.dbValues[0];
                                        let queryData = "";
                                        let queryName = [];
                                        if( ctx.selected.type.includes( "Org" ) ) {
                                            queryName = [ "_Inspection_getProdItemRevision", "_Inspection_getPartItemRevision" ];
                                            queryData = "A2OrgCode" ;
                                        }
                                        if( ctx.selected.type.includes( "Prod" ) ) {
                                            queryName = [ "_Inspection_getProdItemRevision" ]
                                            queryData = "A2ProdGroupCode";
                                        }
                                        if( ctx.selected.type.includes( "Part" ) ) {
                                            queryName = [ "_Inspection_getPartItemRevision" ];
                                            queryData = "A2PartGroupCode";
                                        }
                                        for( const query of queryName ) {
                                            let res = await AwcQueryUtil.executeSavedQuery( query, [ queryData ], [ a2Code ] );
                                            if( res ) {
                                                for( const item of res ) {
                                                    if( item.type.includes( "InsItem" ) ) {
                                                        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'ExistTemplate' ) );
                                                        return false;
                                                    } 
                                                }
                                            }
                                        }
                                    }
                                    _removeQObj( ctx );
                                },
                                () => {}
                             ]);
}

export let viewAll = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsViewAllUsed", "YES" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    } );
}

export let viewUsed = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsViewAllUsed", "NO" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
        
        if(ctx.xrtSummaryContextObject.type == 'A2QSampleRangeMgmtFolder' && ctx.selected.props.a2IsUsed_1.value == 'NO'){
            let tableElement = document.getElementById( "SampleRangeEntryTable" );
            let table = viewModelService.getViewModelUsingElement( tableElement );
            let vmCol = table.dataProviders.SampleEntryTableDataProvider.viewModelCollection;
            vmCol.clear();
        }
    } );
}

export let viewAllRevision = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsViewAllRevision", "YES" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    } );
}

export let viewLatestRevision = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsViewAllRevision", "NO" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    } );
}

export let setUse = ( data, ctx ) => {
    AwcObjectUtil.setProperties2(ctx.mselected, ["a2IsUsed_1"], ["YES"]);
    eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
}

export let setUnUse = ( data, ctx ) => {
    AwcObjectUtil.setProperties2(ctx.mselected, ["a2IsUsed_1"], ["NO"]);
    eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
}

var dates = {
    convert:function(d) {
        // Converts the date in d to a date-object. The input can be:
        //   a date object: returned without modification
        //  an array      : Interpreted as [year,month,day]. NOTE: month is 0-11.
        //   a number     : Interpreted as number of milliseconds
        //                  since 1 Jan 1970 (a timestamp) 
        //   a string     : Any format supported by the javascript engine, like
        //                  "YYYY/MM/DD", "MM/DD/YYYY", "Jan 31 2009" etc.
        //  an object     : Interpreted as an object with year, month and date
        //                  attributes.  **NOTE** month is 0-11.
        return (
            d.constructor === Date ? d :
            d.constructor === Array ? new Date(d[0],d[1],d[2]) :
            d.constructor === Number ? new Date(d) :
            d.constructor === String ? new Date(d) :
            typeof d === "object" ? new Date(d.year,d.month,d.date) :
            NaN
        );
    },
    compare:function(a,b) {
        // Compare two dates (could be of any type supported by the convert
        // function above) and returns:
        //  -1 : if a < b
        //   0 : if a = b
        //   1 : if a > b
        // NaN : if a or b is an illegal date
        // NOTE: The code inside isFinite does an assignment (=).
        return (
            isFinite(a=this.convert(a).valueOf()) &&
            isFinite(b=this.convert(b).valueOf()) ?
            (a>b)-(a<b) :
            NaN
        );
    },
    inRange:function(d,start,end) {
        // Checks if date in d is between dates in start and end.
        // Returns a boolean or NaN:
        //    true  : if d is between start and end (inclusive)
        //    false : if d is before start or after end
        //    NaN   : if one or more of the dates is illegal.
        // NOTE: The code inside isFinite does an assignment (=).
       return (
            isFinite(d=this.convert(d).valueOf()) &&
            isFinite(start=this.convert(start).valueOf()) &&
            isFinite(end=this.convert(end).valueOf()) ?
            start <= d && d <= end :
            NaN
        );
    }
}

let editHandleAction = ( data, ctx ) => {
    if(ctx.selected.type == "A2QCTQImportEntryRuntime")
    {
        let ootbSaveFunction = editHandlerService.getActiveEditHandler().saveEdits;
        ootbSaveFunction(); 
        return;
    }

    const ctxtObj = ctx.xrtSummaryContextObject;
    let type = ctx.xrtSummaryContextObject.type;
    let typeHierarchyArray = ctx.xrtSummaryContextObject.modelType.typeHierarchyArray;
    if(ctx.xrtSummaryContextObject.type.includes("IRItemRevision") || ctx.xrtSummaryContextObject.type.includes("PTRItemRevision")) {
        let ootbSaveFunction = editHandlerService.getActiveEditHandler().saveEdits;
        let text = locale.getLocalizedText(localeText, "dateInvalid");
        editHandlerService.getActiveEditHandler().saveEdits = function() {
            if(ctx.xrtSummaryContextObject.type.includes("IRItemRevision") || ctx.xrtSummaryContextObject.type.includes("PTRItemRevision")) {
                let today = new Date();
                today.setHours(0, 0, 0, 0);
                let inputDate = dates.convert( ctx.xrtSummaryContextObject.props.a2DueDate.uiValue );
                let a2LotSize = ctx.xrtSummaryContextObject.props.a2LOTQty_1.uiValue
                if( a2LotSize > 100000 ) {
                    AwcNotificiationUtil.show("ERROR", locale.getLocalizedText( localeText, "LOTOverMaxSize" ));
                    return;
                } else if( dates.compare(today, inputDate) == 1 ) {
                    AwcNotificiationUtil.show("WARNING", text);
                    return;
                } else if( a2LotSize < 1 ) {
                    AwcNotificiationUtil.show("ERROR", locale.getLocalizedText( localeText, "LotQtyZeroEntered" ));
                    return;
                } else {
                    ootbSaveFunction();
                }
            } else {
                ootbSaveFunction();
            }
        }
    } else if ( [ "A2CustomerClaimsRevision", "A2CustomerVoCRevision",
                    "A2IntNCQIRevision", "A2OutNCQIRevision" ].includes( ctx.xrtSummaryContextObject.type ) ) {
        
        const ootbSaveFunction = editHandlerService.getActiveEditHandler().saveEdits;
        const invalidDuaDateMsg = locale.getLocalizedText( "A2QualityClaimLocalizationMessages", "invalidDueDate2" );

        editHandlerService.getActiveEditHandler().saveEdits = async function() {
            let today = new Date();

            today.setHours(0, 0, 0, 0);

            let inputDate = dates.convert( ctx.xrtSummaryContextObject.props[ "a2_DueDate" ].uiValue );

            inputDate.setHours( 0, 0, 0, 0 );


            let isEmptySupplierO = false;

            let targetElem = document.getElementsByName( "A2EditHandler" )[ 0 ];
            let data = viewModelService.getViewModelUsingElement(targetElem); 
            
            let presupplierO;
            if (data.a2_SupplierO) {
                presupplierO = data.a2_SupplierO.prevDisplayValues[0];
                if ( data.a2_SupplierO.uiValue == "" || data.a2_SupplierO.uiValue == null) {
                    isEmptySupplierO = true;
                }
            }

            //20220629 Kim,Won-Gu Add VOC, Claim의 경우 ALM Interface를 위해 a2ClaimType(Claim), a2VOCDetailType(VoC) 유형이 
            //software에서 다른 유형으로 변경되는 경우 a2_SoftwareIssueCanceled = "Y" 로 Set
            //다른 유형에서 Software로 변경되는 경우 a2_SoftwareIssueCanceled = "" 로 Set 하기 위해 추가
            let softwareTypeOldVal = "";
            if (ctx.xrtSummaryContextObject.type === "A2CustomerClaimsRevision" || ctx.xrtSummaryContextObject.type === "A2CustomerVoCRevision") {
                if (ctx.xrtSummaryContextObject.type === "A2CustomerClaimsRevision") {
                    if (!ctx.xrtSummaryContextObject.props.a2ClaimType) {
                        await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2ClaimType", false); // 편집중일때 수정 사항 날아가는 문제 해결
                    }
                    if (ctx.xrtSummaryContextObject.props.a2ClaimType.value) {
                        softwareTypeOldVal = ctx.xrtSummaryContextObject.props.a2ClaimType.value;
                    }
                } else if (ctx.xrtSummaryContextObject.type === "A2CustomerVoCRevision") {
                    if (!ctx.xrtSummaryContextObject.props.a2VOCDetailType) {
                        await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2VOCDetailType", false);
                    }
                    if (ctx.xrtSummaryContextObject.props.a2VOCDetailType.value) {
                        softwareTypeOldVal = ctx.xrtSummaryContextObject.props.a2VOCDetailType.value;
                    }
                }
            }

            if( dates.compare( inputDate.getTime(), today.getTime() ) === -1 ) {
                AwcNotificiationUtil.show( "WARNING", invalidDuaDateMsg );

                return;
            }

            if ( ctxtObj.type === "A2IntNCQIRevision" ) {
                const defectObj = await AwcObjectUtil.getObject( ctxtObj.props[ "CPA0ProblemDescription" ].dbValues[ 0 ] );

                await AwcObjectUtil.getProperties( defectObj, [ "a2DefectPhenomenonCodeO", "a2DefectPhenomenon" ] );

                if ( defectObj.props[ "a2DefectPhenomenonCodeO" ].dbValues[ 0 ] === null ) {
                    if ( ctxtObj.props[ "a2_DefectO" ].dbValues[ 0 ] !== null ) {
                        await AwcObjectUtil.setProperty( defectObj, "a2DefectPhenomenonCodeO", ctxtObj.props[ "a2_DefectO" ].dbValues[ 0 ] );
                    }
                }

                if ( defectObj.props[ "a2DefectPhenomenon" ].dbValues[ 0 ] === null ) {
                    if ( ctxtObj.props[ "a2_DefectPhenomenon" ].dbValues[ 0 ] !== null ) {
                        await AwcObjectUtil.setProperty( defectObj, "a2DefectPhenomenon", ctxtObj.props[ "a2_DefectPhenomenon" ].dbValues[ 0 ] );
                    }
                }
            }

           // 20220701 추후 리팩토링 임해철 
            if (ctx.xrtSummaryContextObject.type === 'A2CustomerClaimsRevision') {
                let costLevel = "";
                let level = "";
                let proeprtyName = "";
                let proeprtyName2 = "";
                let propertyName3 ="";
                let proeprtyLevelName = "";
                let cost;
                let flag = false;

                if (ctx.xrtPageContext.secondaryXrtPageID) {
                    if (ctx.xrtPageContext.secondaryXrtPageID === "tc_xrt_Overview") {
                        if (data.a2_FinalLevel) {
                            proeprtyName = "a2SettlementCostUnitAmount";
                            proeprtyName2 = "a2SettlementCostUnit";
                            propertyName3 = "a2SettlementCost";
                            proeprtyLevelName = "a2_FinalLevel";
                        } else {
                            flag = true;
                        }
                    }
                }
                
                if (ctx.xrtPageContext.primaryXrtPageID === "a2_xrt_Registration") {    
                    proeprtyName = "a2InitEstmtedCostUnitAmount";
                    proeprtyName2 = "a2InitEstmtedCostUnit";
                    propertyName3 = "a2InitialEstimatedCost";
                    proeprtyLevelName = "a2_EscalationLevel";
                }
                if (ctx.xrtPageContext.primaryXrtPageID === "a2_xrt_CustomerQualityClaimAgreement") {
                    proeprtyName = "a2SettlementCostUnitAmount";
                    proeprtyName2 = "a2SettlementCostUnit";
                    propertyName3 = "a2SettlementCost";
                    proeprtyLevelName = "a2_FinalLevel";
                }
                if (!flag) {
                    let temp = data[proeprtyName].dbValue;
                    if (temp === null || temp === undefined || temp === "") {
                        temp = null;
                    } 
                    let temp2 = data[proeprtyName2].dbValue;
                    if (temp2 === null || temp2 === undefined || temp2 === "") {
                        temp2 = null;
                    } 
                    let desc1 = "";
                    let decs2 = "";
                    if (temp && temp2) { 
                        cost = Number(temp) * Number(temp2);
                        if (cost > 1000000000) {
                            costLevel = "S";
                            desc1 = "S. 10억 초과";
                        } else if (cost > 300000000) {
                            costLevel = "A";
                            desc1 = "A. 3억 초과";
                        } else if (cost > 200000000) {
                            costLevel = "B";
                            desc1 = "B. 2억 초과";
                        } else if (cost > 100000000) {
                            costLevel = "C";
                            desc1 = "C. 1억 초과";
                        } else {
                            costLevel = "Etc";
                            desc1 = "Etc. 1억 이하";
                        }
                        if (data[propertyName3]) {
                            cost = cost.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                            data[propertyName3].uiValue = cost;
                        }
                        
                        level = data[proeprtyLevelName].dbValue;
                        if (level == "S") {
                            decs2 = "S. 10억 초과";
                        } else if (level == "A") {
                            decs2 = "A. 3억 초과";
                        } else if (level == "B") {
                            decs2 = "B. 2억 초과";
                        } else if (level == "C") {
                            decs2 = "C. 1억 초과";
                        } else if (level == "Etc") {
                            decs2 = "Etc. 1억 이하";
                        }
                        if (costLevel !== level && ctx.xrtPageContext.primaryXrtPageID === "a2_xrt_Registration") {
                            AwcNotificiationUtil.showParam( "WARNING", locale.getLocalizedText( "lgspQMSIssueMessages", "CostEscalationError" ), [ desc1, decs2] );
                            return;
                        } else if (costLevel !== level && (ctx.xrtPageContext.primaryXrtPageID === "a2_xrt_CustomerQualityClaimAgreement" || ctx.xrtPageContext.secondaryXrtPageID === "tc_xrt_Overview")) {
                            AwcNotificiationUtil.showParam( "WARNING", locale.getLocalizedText( "lgspQMSIssueMessages", "CostFinalError" ), [ desc1, decs2 ] );
                            return;
                        }

                    }
                } 
                
            }


            if ( isEmptySupplierO && ctx.xrtSummaryContextObject.type === "A2OutNCQIRevision" && ctx.xrtPageContext.primaryXrtPageID === "a2_xrt_Registeration") {
                AwcNotificiationUtil.show( "WARNING", locale.getLocalizedText( "A2QualityClaimLocalizationMessages", "NotInputSupplierO" ) );
                return;
            } else if (ctx.changedSupplierUserUid == '' && data.a2_SupplierO.uiValue !== '' && ctx.xrtSummaryContextObject.type === 'A2OutNCQIRevision' && ctx.xrtSummaryContextObject.props.a2_SupplierO.uiValue !== data.a2_SupplierO.uiValue) {
                AwcNotificiationUtil.show( "WARNING", locale.getLocalizedText( "A2QualityClaimLocalizationMessages", "NotInputSupplierOwner" ) );
                return;
            } else {
                await ootbSaveFunction();
                if (ctx.xrtSummaryContextObject.type === "A2OutNCQIRevision") {
                    if (ctx.changedSupplierUserUid && ctx.changedSupplierUserUid !== null && ctx.changedSupplierUserUid !== undefined) {
                        if (presupplierO !== data.a2_SupplierO.uiValue) {
                            await AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, 'a2_SupplierOwner', ctx.changedSupplierUserUid);
                            await AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, 'a2_PartArrayO', '');
                            ctx.changedSupplierUserUid = null;
                        } else {
                            ctx.changedSupplierUserUid = null;
                        } 
                    }
                }

                if ( ctxtObj.type === "A2CustomerClaimsRevision" ) {
                    const defaultCostUnit = 1000;
                    const notLoadedProps = [ ];
        
                    if ( ! ctxtObj.props.hasOwnProperty( "a2BillingCostUnit" ) ) {
                      notLoadedProps.push( "a2BillingCostUnit" );
                    }
        
                    if ( ! ctxtObj.props.hasOwnProperty( "a2SettlementCostUnit" ) ) {
                      notLoadedProps.push( "a2SettlementCostUnit" );
                    }
        
                    if ( notLoadedProps.length > 0 ) {
                      await AwcObjectUtil.getProperties( ctxtObj, notLoadedProps );
                    }
        
                    if ( ctxtObj.props[ "a2BillingCostUnit" ].dbValue === defaultCostUnit ) {
                      await AwcObjectUtil.setProperty( ctxtObj, "a2BillingCostUnit", ctxtObj.props[ "a2InitEstmtedCostUnit" ].dbValues[ 0 ] );
                    }
        
                    if ( ctxtObj.props[ "a2SettlementCostUnit" ].dbValue === defaultCostUnit ) {
                      await AwcObjectUtil.setProperty( ctxtObj, "a2SettlementCostUnit", ctxtObj.props[ "a2InitEstmtedCostUnit" ].dbValues[ 0 ] );
                    }
                }
                
                //사내/사외 부적합의 경우 이슈유형상세를 변경하였을 경우 속성의 visible이 변경되므로 Refresh 추가
                if((ctx.xrtSummaryContextObject.type === "A2OutNCQIRevision" || ctx.xrtSummaryContextObject.type === "A2IntNCQIRevision") &&
                    ctx.xrtPageContext.primaryXrtPageID === "a2_xrt_Registeration" && ctx.isIssueTypeSubChanged) {
                    eventBus.publish('cdm.relatedModified', {
                        // true : 화면 전체 refresh
                        // false : 변경 된 정보만 refresh
                        refreshLocationFlag: true,
                        relatedModified: [ctx.xrtSummaryContextObject]
                    });
                    ctx.isIssueTypeSubChanged = null;
                }
            
                //20220629 Kim,Won-Gu Add VOC, Claim의 경우 ALM Interface를 위해 a2ClaimType(Claim), a2VOCDetailType(VoC) 유형이 
                //software에서 다른 유형으로 변경되는 경우 a2_SoftwareIssueCanceled = "Y" 로 Set
                //다른 유형에서 Software로 변경되는 경우 a2_SoftwareIssueCanceled = "" 로 Set 하기 위해 추가
                if (ctx.xrtSummaryContextObject.type === "A2CustomerClaimsRevision" || ctx.xrtSummaryContextObject.type === "A2CustomerVoCRevision") {
                    let softwareTypeNewVal = "";
                    if (ctx.xrtSummaryContextObject.type === "A2CustomerClaimsRevision") {
                        await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2ClaimType", false);
                        softwareTypeNewVal = ctx.xrtSummaryContextObject.props.a2ClaimType.value;
                    } else if (ctx.xrtSummaryContextObject.type === "A2CustomerVoCRevision") {
                        await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2VOCDetailType", true);
                        softwareTypeNewVal = ctx.xrtSummaryContextObject.props.a2VOCDetailType.value;
                    }

                    if(softwareTypeOldVal === "Software") {
                        //이전값이 Software이고 새로운 값이 Software가 아니면 a2_SoftwareIssueCanceled = "Y" 로 Setting
                        if(softwareTypeNewVal != "Software") {
                            await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2_SoftwareIssueCanceled", false);
                            await AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, "a2_SoftwareIssueCanceled", "Y");
                        }
                    } else {
                        //이전값이 Software가 아니고 newValue가 software일 경우 clear함 a2_SoftwareIssueCanceled를 초기화 함
                        if(softwareTypeNewVal === "Software") {
                            await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2_SoftwareIssueCanceled", false);
                            await AwcObjectUtil.setProperty(ctx.xrtSummaryContextObject, "a2_SoftwareIssueCanceled", "");
                        }
                    }
                }
            }
        }
    } else if ( ctx.xrtSummaryContextObject.type === "A2SupplierClaimRevision" ) {

        const ootbSaveFunction = editHandlerService.getActiveEditHandler( ).saveEdits;
        const invalidDueDateMsg = locale.getLocalizedText( "A2QualityClaimLocalizationMessages", "invalidDueDate" );
        const invalidReturnCompletionDate = locale.getLocalizedText( "A2QualityClaimLocalizationMessages", "invalidReturnCompletionDate" );

        editHandlerService.getActiveEditHandler( ).saveEdits = async function() {
            let today = new Date();

            today.setHours( 0, 0, 0, 0 );

            let inputDueDate = dates.convert( ctx.xrtSummaryContextObject.props[ "a2_DueDate" ].uiValue );

            inputDueDate.setHours( 0, 0, 0, 0 );

            let inputReturnCompletionDate = dates.convert( ctx.xrtSummaryContextObject.props[ "a2ReturnCompletionDate" ].uiValue );

            inputReturnCompletionDate.setHours( 0, 0, 0, 0 );

            if( dates.compare( inputDueDate.getTime(), today.getTime() ) === -1  && ctx.xrtSummaryContextObject.props.a2_StepInProgress.dbValues[0] == "Registration") {
                AwcNotificiationUtil.show( "WARNING", invalidDueDateMsg );

                return;
            }

            if( dates.compare( inputReturnCompletionDate.getTime(), today.getTime() ) === -1 ) {
                AwcNotificiationUtil.show( "WARNING", invalidReturnCompletionDate );

                return;
            }

            await ootbSaveFunction();
        }

    } else if ( ["A2QCheckSet", "A2QProdIPItemRevision", "A2QPartCheckSheet", "A2QPartIPItemRevision", "A2QProdPTCheckSheet", "A2QPartPTCheckSheet", "A2QProdPTPItemRevision", "A2QPartPTPItemRevision"].includes(type) || typeHierarchyArray.includes("A2QCheckItem") || typeHierarchyArray.includes("A2QPartCheckItem") ) {
        if( type === "A2QPartIPItemRevision" ) {
            const interval = setInterval( () => {
                let classes = [ ...document.getElementsByClassName( "aw-layout-panelSectionContent" ) ];
                if( classes.length > 0 ) {
                    clearInterval( interval );
                    classes[ classes.length - 1 ].setAttribute( "style", "margin-bottom : 10%;" );
                }
            } )
        }
        let ootbSaveFunction = editHandlerService.getActiveEditHandler().saveEdits;
        editHandlerService.getActiveEditHandler().saveEdits = function() {

            if(ctx.selected.type == "A2QCTQImportEntryRuntime" || ctx.selected.type == "A2QPQEntryRuntime")
            {
                ootbSaveFunction(); 
                return;
            }
            let errMsg;
            let modList = this.getDataSource().getAllModifiedPropertiesWithVMO();
            AwcObjectUtil.getProperty( ctx.selected, "a2TargetRange" );
            if( ctx.selected.props.a2TargetRange ) {
                let targetRange = ctx.selected.props.a2TargetRange.dbValue;
                
                let msg;
                let lsl;
                let usl;
                let targetValue;
                for( const mod of modList ) {
                    let obj = mod.viewModelObject;
                    let props = mod.viewModelProps;
                    let inputType = obj.props.a2InsInputType;
                    
                    if( inputType.dbValue == "Continuous" ) {
                        for( const prop of props ) {
                            if( prop && prop.propertyName == "a2Lsl" ) {
                                lsl = prop.newValue;
                                continue;
                            }
                            if( prop && prop.propertyName == "a2Usl" ) {
                                usl = prop.newValue;
                                continue;
                            }
                            if( prop && prop.propertyName == "a2TargetValue" ) {
                                targetValue = prop.newValue;
                                continue;
                            }
                        }
    
                        lsl = lsl ? lsl : obj.props.a2Lsl.dbValue;
                        usl = usl ? usl : obj.props.a2Usl.dbValue;
                        if( !targetValue ) {
                            targetValue = mod.viewModelObject.props.a2TargetValue.dbValue;
                        }
    
                        switch( targetRange ) {
                            case "LSL<X"    :
                                if( lsl >= targetValue ) msg = "invalidLslTargetValue";
                                if( mod.viewModelProps[0].propertyName == "a2Usl" ) msg = "invalidEditProp";
                                break;
                            case "LSL<X<USL"    :
                                if( lsl >= targetValue ) msg = "invalidLslTargetValue";
                                if( usl <= targetValue ) msg = "invalidUslTargetValue";
                                if( lsl >= usl ) msg = "invalidLslUsl";
                                break;
                            case "LSL<X≤USL"    :
                                if( lsl >= targetValue ) msg = "invalidLslTargetValue";
                                if( usl < targetValue ) msg = "invalidUslTargetValue";
                                if( lsl >= usl ) msg = "invalidLslUsl";
                                break;
                            case "X<USL"    :
                                if( usl <= targetValue ) msg = "invalidLslTargetValue";
                                if( mod.viewModelProps[0].propertyName == "a2Lsl" ) msg = "invalidEditProp";
                                break;
                            case "LSL≤X"    :
                                if( lsl > targetValue ) msg = "invalidLslTargetValue";
                                if( mod.viewModelProps[0].propertyName == "a2Usl" ) msg = "invalidEditProp";
                                break;
                            case "X=Target"    :
                                if( lsl || usl ) msg = "invalidValueInTarget";
                                break;
                            case "LSL≤X<USL"    :
                                if( lsl > targetValue ) msg = "invalidLslTargetValue";
                                if( targetValue >= usl ) msg = "invalidUslTargetValue";
                                if( lsl >= usl ) msg = "invalidLslUsl";
                                break;
                            case "LSL≤X≤USL"    :
                                if( lsl > targetValue ) msg = "invalidLslTargetValue";
                                if( targetValue > usl ) msg = "invalidUslTargetValue";
                                if( lsl >= usl ) msg = "invalidLslUsl";
                                msg = "invalidLslTargetValue";
                                break;
                            case "X≤USL"    :
                                if( targetValue > usl ) msg = "invalidLslTargetValue";
                                if( mod.viewModelProps[0].propertyName == "a2Lsl" ) msg = "invalidEditProp";
                                break;
                        }
                        
                        if( !msg ) {
                            for( const prop of [ lsl, usl, targetValue ] ) {
                                if( String( prop ).includes( "." ) ) {
                                    if( String( prop ).split( "." )[1].length > 7 ) {
                                        msg = "decimalOver";
                                        break;
                                    }
                                }
                            }
                        }
                    } else {
                        for( const prop of props ) {
                            if(prop.propertyName == "a2Lsl" || prop.propertyName == "a2Usl" || prop.propertyName == "a2TargetValue" || 
                               prop.propertyName == "a2ContinousDigit" || prop.propertyName == "a2QContinuousUnit" || prop.propertyName == "a2ConInitValue") {
                                msg = "notContinuous";
                                break;
                            }
                        }
                    }
                }
                if( msg ) {
                    AwcNotificiationUtil.show( "WARNING", locale.getLocalizedText( "lgspQmsNewInspectionMessages", msg ) );
                    eventBus.publish( 'primaryWorkarea.reset' );
                    eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
                }else{
                    ootbSaveFunction();
                }
            } else {
                ootbSaveFunction();
            }
            
        }
    } else {
        editHandlerService.getActiveEditHandler().getDataSource().getAllEditableProperties = function() {
            var allEditableProperties = [];
            var loadedVMObjects = editHandlerService.getActiveEditHandler().getDataSource().getLoadedViewModelObjects();
            let bool = true;
            _.forEach( loadedVMObjects, function( vmo ) {
                if( !vmo.type.includes("Mgmt")) {
                    if( vmo.props.awp0Secondary.dbValues[0] == ctx.selected.uid ) {
                    _.forEach( vmo.props, function( prop ) {
                            if( prop.propertyName == "a2Code" ) {
                                if( !prop.dbValues[0] ) {
                                    prop.error = "Property is Required";
                                    bool = false;
                                }
                            }
                            if( prop.propertyName == "a2PartGroupCode"  ) {
                                if( !prop.dbValues[0] ) {
                                    prop.error = "Property is Required";
                                    bool = false;
                                }
                            }
            
                            if( prop.propertyName == "a2OrgCode") {
                                if( !prop.dbValues[0] ) {
                                    prop.error = "Property is Required";
                                    bool = false;
                                }
                            }
                            allEditableProperties.push( prop );
                        } );
                    }
                }
            } );
            if( !bool ) {
                eventBus.publish( 'primaryWorkarea.reset' );
            }
            return allEditableProperties;
        }
    }
}


export default exports = {
   QObjCreateAction,
   QObjDeleteAction,
   viewAll,
   viewUsed,
   viewAllRevision,
   viewLatestRevision,
   setUse,
   setUnUse,
   createObject,
   createSREntryAction,
   load,
   A2QmsDeleteAction,
   editHandleAction,
   A2CreateRuntimeObjectAction
};
app.factory('A2QmsnewCommandService', () => exports);