
import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import viewModelObjectSvc from 'js/viewModelObjectService';
import viewModelService from "js/viewModelService";
import AwcQueryUtil from 'js/AwcQueryUtil';
import AwPromiseService from "js/awPromiseService";
import locale from "js/AwcLocalizationUtil";
import _ from "lodash";
import appCtxService from 'js/appCtxService';
import soaService from 'soa/kernel/soaService';

var exports = {};
let localeText = "lgspQmsNewInspectionMessages";

let contentsTableSelected = ( data, ctx ) => {
    // multi-selected 방지
    if( ctx.selected.type.includes( "CheckItem" ) ) {
        return;
    }
    let tableElement = document.getElementById( "A2QHistorySelectedInspTable" );
    let table = viewModelService.getViewModelUsingElement( tableElement );
    let vmCol = table.dataProviders.HistorySelectedInspTableDataProvider.viewModelCollection;
    vmCol.clear();
    let queryName = ctx.selected.type.includes( "PTP" ) ? "_Inspection_getProdTestDefinitions" : "_Inspection_getInspectionDefinitions";
    AwcQueryUtil.executeSavedQuery( queryName, [ "A2Id", "A2RevId" ], [ ctx.selected.props.item_id.dbValues[0], ctx.selected.props.item_revision_id.dbValues[0] ] ).then( async ( res ) => {
        if( res ) {
            await AwcObjectUtil.getProperties( res, [ 
                "a2Index", "a2InspectionObject", "a2CheckSheetObject", "a2Group1", "a2Group2",
                "a2Group3", "object_name", "a2InsInputType", "a2QSampleString", "a2TargetRange",
                "a2InsSpec", "a2JudgeInitValue", "a2ConInitValue", "a2ContinousDigit", "a2QContinuousUnit",
                'a2TargetValue', "a2Lsl", "a2Usl", "a2SampleMethod", "a2IsCTQ", "date_released",
                "a2IsUsed", "IMAN_reference", "IMAN_specification", "a2IsDeleted", "a2MachineClass1", 
                "a2MachineClass2", "a2MachineClass3", "a2MachineClass4",
            ] );
            let itemVMOArr = [];
            // a2IsDeleted가 YES가 아닌 obj들만 push
            res.forEach( ( item ) => {
                if( item.props.a2IsDeleted.dbValues[0] != "YES" ) {
                    itemVMOArr.push( viewModelObjectSvc.createViewModelObject( item ) );
                }
            });
            // Index별로 정렬
            itemVMOArr.sort( ( a, b ) => {
                return Number( a.props.a2Index.dbValues[0] ) - Number( b.props.a2Index.dbValues[0] );
            });
            vmCol.loadedVMObjects = itemVMOArr;   
        }
    });
}

export let tableLoad = ( data, ctx ) => {
    const interval = setInterval( async () => {
        let vmCol = data.dataProviders.HistoryContentsTableDataProvider.viewModelCollection;
        if( vmCol ) {
            clearInterval( interval );
            let selectedRev = AwcObjectUtil.getObject( ctx.selected.uid );
            await AwcObjectUtil.getProperty( selectedRev, "items_tag" );
            let item = AwcObjectUtil.getObject( selectedRev.props.items_tag.dbValues[0] );
            await AwcObjectUtil.getProperty( item, "revision_list" );
            let revArr = [];
            for( const rev of item.props.revision_list.dbValues ) {
                revArr.push( await viewModelObjectSvc.createViewModelObject( AwcObjectUtil.getObject( rev ) ));
            }
            if( revArr.length > 1 ) {
                revArr.sort( async ( a, b ) => {
                    await AwcObjectUtil.getProperties( a, [ "a2ModelSuffix", "a2InspTypeName", "item_revision_id", "a2SeverityLevel" ] );
                    await AwcObjectUtil.getProperties( b, [ "a2ModelSuffix", "a2InspTypeName", "item_revision_id", "a2SeverityLevel" ] );
                    return Number( a.props.item_revision_id.dbValues[0] ) - Number( b.props.item_revision_id.dbValues[0] );
                });
            } else {
                await AwcObjectUtil.getProperties( revArr[0], [ "a2ModelSuffix", "a2InspTypeName", "item_revision_id", "a2SeverityLevel" ]);
            }
            vmCol.loadedVMObjects = revArr;
            // for( const obj of revArr ) {
            //     await AwcObjectUtil.getProperties( obj, [ "a2ModelSuffix", "a2InspTypeName" ] );
            //     vmCol.loadedVMObjects.push( obj );
            // }
        }
    } );
}

let _getHeaderData = async ( columnArr ) => {
    let columnData = [];
    _.forEach( columnArr, ( column ) => {
        columnData.push(
            {
                name: column,
                propertyName: column,
                displayName: locale.getLocalizedText( localeText, column ),
                typeName: "String",
                width: 150,
                modifiable: true,
                enableColumnResizing: true,
                enableColumnMoving: false
            }
        )
    });
    columnData = [
        ...columnData
    ];
    return columnData;
}

export let loadColumns = async ( providedData ) => {
    let ctx = appCtxService.ctx;
    let headerArr = ctx.selected.type.includes( "PTP" ) ? 
                    [ "item_revision_id", "a2ModelSuffix", "a2InspTypeName", "release_status_list", "date_released" ] : 
                    [ "item_revision_id", "a2ModelSuffix", "a2InspTypeName", "a2SeverityLevel", "release_status_list", "date_released" ];
    let columnHeader = await _getHeaderData( headerArr );
    var deferred = AwPromiseService.instance.defer();

    providedData.columnConfig = {
        columns: columnHeader
    };

    deferred.resolve( {
        columnInfos: columnHeader
    } );
    return deferred.promise;
}

export let secondTableLoad = async ( providedData ) => {
    let ctx = appCtxService.ctx;
    let PTPArr = [
        "a2Index", "a2InspectionObject", "a2CheckSheetObject", "object_name", "a2InsInputType",
        "a2InsSpec", "a2JudgeInitValue", "a2ConInitValue", "a2ContinousDigit", "a2QContinuousUnit", "a2TargetRange",
        'a2TargetValue', "a2Lsl", "a2Usl", "a2SampleMethod", "a2QSampleString", "a2IsCTQ", "a2MachineClass1", "a2MachineClass2", "a2MachineClass3", 
        "a2MachineClass4", "a2IsUsed", "IMAN_reference", "IMAN_specification"
    ]
    let IPArr = [
        "a2Index", "a2InspectionObject", "a2CheckSheetObject", "a2Group1", "a2Group2",
        "a2Group3", "object_name", "a2InsInputType",
        "a2InsSpec", "a2JudgeInitValue", "a2ConInitValue", "a2ContinousDigit", "a2QContinuousUnit", "a2TargetRange",
        'a2TargetValue', "a2Lsl", "a2Usl", "a2SampleMethod", "a2QSampleString", "a2IsCTQ", "a2MachineClass1", "a2MachineClass2", "a2MachineClass3", 
        "a2MachineClass4", "a2IsUsed", "IMAN_reference", "IMAN_specification"
    ]
    let headerArr = ctx.selected.type.includes( "PTP" ) ? PTPArr : IPArr;
    let columnHeader = await _getHeaderData( headerArr );
    var deferred = AwPromiseService.instance.defer();

    providedData.columnConfig = {
        columns: columnHeader
    };

    deferred.resolve( {
        columnInfos: columnHeader
    } );
    return deferred.promise;
}

export default exports = {
    tableLoad,
    loadColumns,
    secondTableLoad,
    contentsTableSelected
};
app.factory('A2HistoryTableService', () => exports);