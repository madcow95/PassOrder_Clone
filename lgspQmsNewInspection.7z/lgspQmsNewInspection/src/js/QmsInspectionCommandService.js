/**
 * QMSCommonService
 *
 * @module js/QMSCommonService
 */

import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import soaService from 'soa/kernel/soaService';
import locale from 'js/AwcLocalizationUtil';
import viewModelService from 'js/viewModelService';
import _ from 'lodash';
import AwcQueryUtil from 'js/AwcQueryUtil';

var exports = {};
let localeText = "lgspQmsNewInspectionMessages";


export function selectChanges (data, ctx) {

}

let A2QSampleFixAction = async (data, ctx) => {
    AwcPanelUtil.openCommandPanel("A2QSampleFix");
}

let A2QSampleAQLAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel("A2QSampleAQL");
}

let A2QSampleRangeAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel("A2QSampleRange");
}

let A2QAllSampleAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel("A2QAllSample");
}

let A2QSampleVariableAction = (data, ctx) => {
    AwcPanelUtil.openCommandPanel("A2QVariableSample");
}

let A2QSampleWSOCreateAction = () => {
    AwcPanelUtil.openCommandPanel("A2QSampleWSOCreate");
}

export function A2QProdIPItemRevisionRevise(data, ctx) {
    AwcObjectUtil.revise(ctx.selected).then( (revList) => {
        AwcNotificiationUtil.show("INFO", locale.getLocalizedText("A2InspectionLocalizationMessages", "inspectionPlanReviseSuccess"))
    })
}

export async function A2QProdIPItemRevisionRelease(data, ctx) {
    if(AwcObjectUtil.isReleased(ctx.xrtSummaryContextObject)) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "ApprovalAlreadyCompleted"));
        return true;
    }
    if(AwcObjectUtil.isInProcess(ctx.xrtSummaryContextObject)) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText("A2ChangeLocalizationMessages", "ActionInprogressError"));
        return;
    }
    await AwcObjectUtil.getProperties(ctx.xrtSummaryContextObject, ["HasParticipant", "a2SeverityLevel", "a2WorkingView"]);
    if(ctx.xrtSummaryContextObject.props.a2WorkingView.dbValues.length == 0 ) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "noCheckItemError"));
        return;
    }
    let a2WorkingView = AwcObjectUtil.getObjects(ctx.xrtSummaryContextObject.props.a2WorkingView.dbValue);
    let sampleMethodList = a2WorkingView.map(obj => obj.props.a2SampleMethod.dbValues[0]);

    // let targetRangeListCheck = a2WorkingView.some( ( obj ) => { 
    //     return obj.props.a2InsInputType.dbValues[0] === "Continuous" && !obj.props.a2TargetRange.dbValues[0];
    // } );
    let targetRangeList = a2WorkingView.map( ( obj ) => {
        if( obj.props.a2InsInputType.dbValues[0] === "Continuous" && !obj.props.a2TargetRange.dbValues[0] ) {
            return obj;
        }
    } );
    targetRangeList = targetRangeList.filter( obj => obj !== undefined );
    let targetCTQArr = await Promise.all( a2WorkingView.map( async ( obj ) => {
        await AwcObjectUtil.getProperties( obj, [ "a2IsCTQ", "a2CTQMgmtMethod", "a2CTQMgmtSpec", "a2CTQLotCount" ] );
        if( obj.props.a2IsCTQ.dbValues[0] === "1" ) {
            if( obj.props.a2CTQLotCount.dbValues[0] === "0" || !obj.props.a2CTQMgmtMethod.dbValues[0] || obj.props.a2CTQMgmtSpec.uiValues[0] === "0" ) {
                return obj;
            }
        }
    } ) );
    targetCTQArr = targetCTQArr.filter( obj => obj !== undefined );

    if(sampleMethodList.includes(null)){
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "EnterSampleMethod"));
        return;
    }

    if( targetRangeList.length > 0 ) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText( localeText, "NoEnterTargetRange" ) );
        return;
    }

    if( targetCTQArr.length > 0 ) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText( localeText, "NoEnterCTQ" ) );
        return;
    }
    
    if(sampleMethodList.includes(null)){
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "EnterSampleMethod"));
        return;
    }

    if(sampleMethodList.includes("AQL") && !ctx.xrtSummaryContextObject.props.a2SeverityLevel.dbValue){
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "EnterSeverity"));
        return;
    }
    
    if(ctx.xrtSummaryContextObject.props.HasParticipant.dbValues.length > 0) {
        let soaInputParam = {
            name: "[QMS] Approve Inspection Plan",
            description: " ",
            contextData:{
                attachmentCount : 1,
                attachments: [ctx.xrtSummaryContextObject.uid],
                processTemplate : "[QMS] Approve Inspection Plan",
                attachmentTypes : [1],
            }
        }
        //// cosole.log(soaInputParam);
        //지역화 필요
        await AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2Requester", ctx.user.uid );
        soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( ()=>{
            AwcNotificiationUtil.show("INFO", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateSuccess"))
            // cosole.log(e);
        }).catch( (e) => {
            AwcNotificiationUtil.show("ERROR", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed")+"\n"+e.message);
            // cosole.log(e.message);
        }).finally( async () => {
            eventBus.publish('cdm.relatedModified', {
                refreshLocationFlag: true,
                relatedModified: [ctx.xrtSummaryContextObject]
            });
            return;
        }); 
    } else {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed") + "\n" + locale.getLocalizedText("lgspQmsNewInspectionMessages", "NoParticipants"));
        return;
    }
}

export function A2QProdIRItemRevisionRelease(data, ctx) {
    if(AwcObjectUtil.isReleased(ctx.xrtSummaryContextObject)) {
        AwcNotificiationUtil.show("ERROR", "이미 결재가 완료되었습니다.");
        return true;
    }
    if(AwcObjectUtil.isInProcess(ctx.xrtSummaryContextObject)) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText("A2ChangeLocalizationMessages", "ActionInprogressError"));
        return;
    }
    let validationProperties = [];
    // validationProperties.push("a2Plant", "a2LOTQty_1", "a2QLotNo", "a2DueDate");
    validationProperties.push("a2Plant", "a2LOTQty_1", "a2QLotNo", "a2DueDate");
    let properties = "";
    for (const propName of validationProperties) {
        if ( !ctx.xrtSummaryContextObject.props[propName].dbValues || !ctx.xrtSummaryContextObject.props[propName].dbValues.length > 0 || !ctx.xrtSummaryContextObject.props[propName].dbValues[0] ) {
            properties += ctx.xrtSummaryContextObject.props[propName].propertyDisplayName;
            properties += " ";
        }
    }
    if(ctx.editInProgress) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed") + "\n" + locale.getLocalizedText("lgspQmsNewInspectionMessages", "RequestFailedEditInProgress"));
        return;
    }
    if(properties.length > 0) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed") + "\n" + locale.getLocalizedText("lgspQmsNewInspectionMessages", "NecessaryPropertyMissing") + "\n" + properties);
        return;
    }
    AwcObjectUtil.getProperty(ctx.selected, "HasParticipant").then( async () => {
        if(ctx.selected.props.HasParticipant.dbValues.length > 0) {
            let soaInputParam = {
                name: "[QMS] Approve Inspection Request",
                description: " ",
                contextData:{
                    attachmentCount : 1,
                    attachments: [ctx.selected.uid],
                    processTemplate : "[QMS] Approve Inspection Request",
                    attachmentTypes : [1],
                }
            }
            await AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2Requester", ctx.user.uid );
            soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( async ()=>{
                AwcNotificiationUtil.show("INFO", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateSuccess"));
            }).catch( (e) => {
                AwcNotificiationUtil.show("ERROR", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed")+"\n"+e.message);
            }).finally( () => {
                eventBus.publish('cdm.relatedModified', {
                    refreshLocationFlag: true,
                    relatedModified: [ctx.selected]
                });
                return;
            }); 
        } else {
            AwcNotificiationUtil.show("ERROR", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed")+ "\n"+ locale.getLocalizedText("lgspQmsNewInspectionMessages", "NoParticipants"));
            return;
        }
    })
}

export const InspectionPasteAction = ( data, ctx ) => {
    const parentObj = AwcObjectUtil.getObject( ctx.xrtSummaryContextObject.uid );
    const copiedInspItems = ctx.awClipBoardProvider;
    const typeCheckStr = parentObj.type == "A2QPartIPItemRevision" ? "A2QPartIPCheckItem" : "A2QPartCheckItem";

    const wrongTypeCheck = copiedInspItems.every( ( item ) => {
        let type = item.type;
        return type === typeCheckStr;
    } );

    if( !wrongTypeCheck ) {
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "wrongTypeInspItem" ) );
        return;
    }

    let itemUidArr = copiedInspItems.map( ( item ) => {
        return item.uid;
    } );

    AwcObjectUtil.setProperty( parentObj, "a2CopiedItems", itemUidArr ).then( () => {
        eventBus.publish( 'primaryWorkarea.reset' );
    } );
}

export async function ArrvalRetryAction( data, ctx ){

    var mselected = ctx.mselected;
    if(mselected){

        for (let i = 0; i < mselected.length; i++) {
            if(mselected[i].type != "A2QPartInsArrivalOrder"){
                // 도착처리 Insterface 항목 선택 안됨
                AwcNotificiationUtil.show("INFO",  locale.getLocalizedText(localeText, "ArrivalObjNotSelected"));
                return;
            }
            
            await AwcObjectUtil.getProperty( mselected[i], "a2Status");
            // 정상 처리 완료된 항목은 선택 할 수 없음
            if(mselected[i].props.a2Status.dbValues[0] != "ERROR"){
                AwcNotificiationUtil.show("INFO",  locale.getLocalizedText(localeText, "ArrivalObjNotError"));
                return;
            }


        }


        for (let i = 0; i < mselected.length; i++) {
            await AwcObjectUtil.setProperty( mselected[i], "a2EventProperty", "RETRY" );
        }
        
    
        AwcNotificiationUtil.show("INFO",  locale.getLocalizedText(localeText, "ArrivalObjRetryCompleted"));
        eventBus.publish( 'cdm.relatedModified', {
            efreshLocationFlag: true,
            relatedModified: [
                ctx.xrtSummaryContextObject
            ]
        });
    }
    else{
        // 도착처리 Insterface 항목 선택 안됨
        AwcNotificiationUtil.show("INFO",  locale.getLocalizedText(localeText, "ArrivalObjNotSelected"));
    }
    
}

export default exports = {
    selectChanges,
    A2QSampleFixAction,
    A2QSampleAQLAction,
    A2QSampleRangeAction,
    A2QAllSampleAction,
    A2QSampleVariableAction,
    A2QSampleWSOCreateAction,
    A2QProdIPItemRevisionRevise,
    A2QProdIPItemRevisionRelease,
    A2QProdIRItemRevisionRelease,
    InspectionPasteAction,
    ArrvalRetryAction
};
app.factory('QmsInspectionCommandService', () => exports);