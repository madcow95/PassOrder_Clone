/**
 * QMS Search Panel Service
 *
 * @module js/A2QTagetSheetRTService
 */

import awcObjectUtil from 'js/AwcObjectUtil';
import uwPropertyService from 'js/uwPropertyService';
import eventBus from 'js/eventBus';
import appCtxService from 'js/appCtxService';
import AwcLocalizationUtil from 'js/AwcLocalizationUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';


/**
 * @param {String} ctx - context
 */
export let loadProperties = async function( data, ctx ) {
    const interval = setInterval( async () => {
        if( ctx.xrtSummaryContextObject ) {
            clearInterval( interval );
            // await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2SearchCriteria" );
            // await awcObjectUtil.getProperties( ctx.xrtSummaryContextObject, searchCriteriaList );
            await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2TargetSheetRT" );
            let sheetProp = ctx.xrtSummaryContextObject.props[ "a2TargetSheetRT" ];
            data[ "a2TargetSheetRT" ] = sheetProp;
            uwPropertyService.setIsEditable( sheetProp, true );

            await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2TargetGroupRT" );
            let groupProp = ctx.xrtSummaryContextObject.props[ "a2TargetGroupRT" ];
            data[ "a2TargetGroupRT" ] = groupProp;
            uwPropertyService.setIsEditable( groupProp, true );

            await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2TargetSetRT" );
            let setProp = ctx.xrtSummaryContextObject.props[ "a2TargetSetRT" ];
            data[ "a2TargetSetRT" ] = setProp;
            uwPropertyService.setIsEditable( setProp, true );

            await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2FMEACTQListCountRT" );
            let cntCTQProp = ctx.xrtSummaryContextObject.props[ "a2FMEACTQListCountRT" ];
            data[ "a2FMEACTQListCountRT" ] = cntCTQProp;
            //uwPropertyService.setIsEditable( cntCTQProp, true );

            await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2ProdQualifyListCountRT" );
            let cntPQProp = ctx.xrtSummaryContextObject.props[ "a2ProdQualifyListCountRT" ];
            data[ "a2ProdQualifyListCountRT" ] = cntPQProp;
            //uwPropertyService.setIsEditable( cntPQProp, true );
        }
    } );
}

export let createByPQAction = async function( data, ctx ) {
 

    if(data.a2TargetSheetRT.dbValue)
    {
        let seletedSheet = awcObjectUtil.getObject(data.a2TargetSheetRT.dbValue);
        let seletedGroup = awcObjectUtil.getObject(data.a2TargetGroupRT.dbValue);
        let seletedSet = awcObjectUtil.getObject(data.a2TargetSetRT.dbValue);

        // 체크세트는 Mandatory이며 체크시트/체크그룹 하위에 존재함(체크그룹이 존재하지 않는 경우 고려)
        if( !data.a2TargetSetRT.dbValue )
        {
            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NoSelectedTargetSet"));
            return;
        }

        var mselected = ctx.mselected;
        if(mselected){

            for (let i = 0; i < mselected.length; i++) {
                if(mselected[i].type != "A2ProdQEntryRuntime"){
                    // 제품인정 시험정보 선택 안됨
                    AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedProdQ"));
                    return;
                }
            }


            for (let i = 0; i < mselected.length; i++) {

                await awcObjectUtil.getProperty( mselected[i], "a2IsCreated");

                if(mselected[i].props.a2IsCreated.dbValues[0] == 1){
                    AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "CreatedProdQSelected"));
                    return;
                }
            }

            await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetSheetRT", seletedSheet );
            if(seletedGroup){
                await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetGroupRT", seletedGroup );
            }

            await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetSetRT", seletedSet );

            for (let i = 0; i < mselected.length; i++) {
                await awcObjectUtil.setProperty( mselected[i], "a2IsSelected", "true" );

            }
            await awcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2EventProperty", "CREATEBYPRODQ" ).then( () => {
                AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "PartIPCheckItemCreated"));
                eventBus.publish( 'cdm.relatedModified', {
                    efreshLocationFlag: true,
                    relatedModified: [
                        appCtxService.ctx.locationContext.modelObject
                    ]
                });
            }).catch( (error) => {
                AwcNotificiationUtil.show("ERROR", "failed. \n" + error.message);
                return;
            }).finally( () => {
                return;
            });

        }
        else{
            // 항목 선택 안됨
            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedProdQ"));
        }
    }
    else{
        // Sheet 선택 안됨
        AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NoSelectedTargetSheet"));
    }
}


export let createByCTQAction = async function( data, ctx ) {
 

    if(data.a2TargetSheetRT.dbValue)
    {
        let seletedSheet = awcObjectUtil.getObject(data.a2TargetSheetRT.dbValue);
        let seletedGroup = awcObjectUtil.getObject(data.a2TargetGroupRT.dbValue);
        let seletedSet = awcObjectUtil.getObject(data.a2TargetSetRT.dbValue);

        // 체크세트는 Mandatory이며 체크시트/체크그룹 하위에 존재함(체크그룹이 존재하지 않는 경우 고려)
        if( !data.a2TargetSetRT.dbValue )
        {
            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NoSelectedTargetSet"));
            return;
        }

        var mselected = ctx.mselected;
        if(mselected){

            for (let i = 0; i < mselected.length; i++) {
                if(mselected[i].type != "A2QCTQImportEntryRuntime"){
                    // 제품인정 시험정보 선택 안됨
                    AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedCTQ"));
                    return;
                }
            }


            for (let i = 0; i < mselected.length; i++) {

                await awcObjectUtil.getProperty( mselected[i], "a2IsCreated");

                if(mselected[i].props.a2IsCreated.dbValues[0] == 1){
                    AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "CreatedCTQSelected"));
                    return;
                }
            }

            await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetSheetRT", seletedSheet );
            if(seletedGroup){
                await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetGroupRT", seletedGroup );
            }

            await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetSetRT", seletedSet );

            for (let i = 0; i < mselected.length; i++) {
                await awcObjectUtil.setProperty( mselected[i], "a2IsSelected", "true" );

            }
            await awcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2EventProperty", "CREATEBYCTQ" ).then( () => {
                AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "PartIPCheckItemCreated"));
                eventBus.publish( 'cdm.relatedModified', {
                    efreshLocationFlag: true,
                    relatedModified: [
                        appCtxService.ctx.locationContext.modelObject
                    ]
                });
            }).catch( (error) => {
                AwcNotificiationUtil.show("ERROR", "failed. \n" + error.message);
                return;
            }).finally( () => {
                return;
            });

        }
        else{
            // CTQ 선택 안됨
            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedCTQ"));
        }
    }
    else{
        // Sheet 선택 안됨
        AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NoSelectedTargetSheet"));
    }
}


export let editHandlerStateChangeAction = function( data, ctx, eventData ) {

}

export default {
    loadProperties,
    createByPQAction,
    createByCTQAction,
    editHandlerStateChangeAction
};
