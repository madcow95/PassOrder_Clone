import app from "app";
import AwPromiseService from "js/awPromiseService";
import AwcObjectUtil from "js/AwcObjectUtil";
import eventBus from "js/eventBus";
import AwcPanelUtil from "js/AwcPanelUtil";
import AwcNotificiationUtil from "js/AwcNotificiationUtil";
import soaService from "soa/kernel/soaService";
import locale from "js/AwcLocalizationUtil";
import viewModelService from "js/viewModelService";
import _ from "lodash";
import uwPropertyService from "js/uwPropertyService";
import viewModelObjectSvc from "js/viewModelObjectService";
import AwcQueryUtil from "js/AwcQueryUtil";
import appCtxService from "js/appCtxService";
import editHandlerService from "js/editHandlerService";
import AwcPageUtil from "js/AwcPageUtil";
import navigationSvc from "js/navigationService";
import popupSvc from "js/popupService";
import uwPropertySvc from "js/uwPropertyService";
 
var exports = {};
let localeText = "lgspQmsNewInspectionMessages";

let _getHeaderData = async () => {
    let columnArr = [ "object_name", "a2Index", "a2From", "a2To", "a2SampleSize", "a2SampleUnit", "a2AC", "a2RE", "creation_date" ];
    let columnData = [];
    _.forEach( columnArr, ( column ) => {
        columnData.push(
            {
                name: column,
                propertyName: column,
                displayName: locale.getLocalizedText( localeText, column ),
                typeName: "String",
                width: column == "a2Index" || column == "a2SampleUnit" ? 95 : 150,
                modifiable: column == "object_name" || column == "a2Index" ? false : true,
                enableColumnResizing: true,
                enableColumnMoving: false,
                isEditable: "true"
            }
        )
    });
    columnData = [
        ...columnData
    ];
    return columnData;
}

// 수정할 때 LOV 값 표시
function getA2SampleUnit() {
    let values = [{"propDisplayValue":"EA","propInternalValue":""}, {"propDisplayValue":"%","propInternalValue":""}];
    return {
        a2SampleUnitValues: values,
        moreValuesExist: false
    };
}

// select된 obj와 relation관계 객체 load
export let addColumn = ( data, ctx ) => {
    if( ctx.selected.type == "A2QSampleRangeWSO" ) {
        let tableElement = document.getElementById( "SampleRangeEntryTable" );
        let table = viewModelService.getViewModelUsingElement( tableElement );
        let vmCol = table.dataProviders.SampleEntryTableDataProvider.viewModelCollection;
        
        vmCol.clear();

        AwcQueryUtil.executeSavedQuery( "_Inspection_getSampleRangeEntry", [ "A2ObjectName" ], [ ctx.selected.props.a2SampleRangeCode.dbValues[0] ] ).then( async ( res ) => {
            if( res ) {
                let vmoArray = [];
                await AwcObjectUtil.getProperties( res, [ "a2Index", "a2From", "a2To", "a2SampleSize", "a2SampleUnit", "a2AC", "a2RE", "creation_date" ] );
                let LOVList = await AwcObjectUtil.getInitialLOVValues( 'a2SampleUnit', "A2QSampleRangeEntry" );
                let index = 0;
                for( const mo of res ) {
                    if(mo.props.a2IsDeleted.dbValues[0] == "YES") {
                        continue;
                    }
                    let vmo = await viewModelObjectSvc.createViewModelObject( mo );
                    // Sample Unit 수정할 때, LOV 표시 위해 dataProvider에 추가
                    _.forEach( vmo.props, function ( prop ) {
                        if ( prop.propertyName === "a2SampleUnit" ) {
                            prop.hasLov = true;
                            prop.dataProvider = 'a2SampleUnitProvider';
                            prop.propertyDescriptor = {
                                displayName: prop.propertyDisplayName
                            };
                            prop.displayValues = _.isArray( prop.value ) ? prop.value : [ prop.value ];
                            prop.getViewModel = function () {
                                return data;
                            };
                        }
                    });
                    vmoArray.push( vmo );
                    vmoArray[ index ].props.a2SampleUnit.lovApi.result = LOVList;
                    index++;
                }
                vmoArray.sort( ( a, b ) => {
                    return Number( a.props.a2Index.dbValues[0] ) - Number( b.props.a2Index.dbValues[0] );
                });
                vmCol.loadedVMObjects = vmoArray;
            }
        });
    }
}

export let loadColumns = async ( providedData ) => {
    let columnHeader = await _getHeaderData();
    var deferred = AwPromiseService.instance.defer();

    providedData.columnConfig = {
        columns: columnHeader
    };

    deferred.resolve( {
        columnInfos: columnHeader
    } );
    return deferred.promise;
}

export let splmTableStartEdit = () => {

}

export let splmTableSaveEdit = async ( data ) => {
    let selected = appCtxService.ctx.selected;
    let msg = "";
    // 수정 데이터가 null
    if( !data[0].props[0].dbValues[0] ) {
        if( data[0].props[0].propertyName == "a2SampleUnit" ) {
            await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, selected.props[ data[0].props[0].propertyName ].prevDisplayValues[0] );
        } else {
            await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, selected.props[ data[0].props[0].propertyName ].uiValues[0] );
        }
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText(localeText, "emptyExist") );
        return false;
    }

    // From ~ To Validation
    if( data[0].props[0].propertyName == "a2From" || data[0].props[0].propertyName == "a2To" ) {
        AwcQueryUtil.executeSavedQuery( "_Inspection_getSampleRangeEntry", [ "A2ObjectName" ], [ selected.props.object_name.dbValues[0] ] ).then( async ( res ) => {
            if( res ) {
                res.sort( ( a, b ) => {
                    return Number( a.props.a2Index.dbValues[0] ) - Number( b.props.a2Index.dbValues[0] );
                })
                await AwcObjectUtil.getProperties( res, [ "a2From", "a2To" ] );
                // let fromArr = [];
                let bool = true;
                for( const vmo of res ) {
                    if( vmo.uid != selected.uid ) {
                        // fromArr.push( vmo.props.a2From.dbValues[0] );
                        if( Number( vmo.props.a2From.dbValues[0] ) <= Number( data[0].props[0].dbValues[0] ) && Number( data[0].props[0].dbValues[0] <= Number( vmo.props.a2To.dbValues[0] ) ) ) {
                            msg = "ExistSampleRange"
                            bool = false;
                            break;
                        }
                    } else {
                        if( data[0].props[0].propertyName == "a2From" ) {
                            if( Number( data[0].props[0].dbValues[0] ) >= Number( vmo.props.a2To.dbValues[0] ) ) {
                                msg = "fromBig"
                                bool = false;
                                break;
                            }
                        } else if( data[0].props[0].propertyName == "a2To" ) {
                            if( Number( data[0].props[0].dbValues[0] ) <= Number( vmo.props.a2From.dbValues[0] ) ) {
                                msg = "fromBig"
                                bool = false;
                                break;
                            }
                        }
                    }
                }
                // Sample Entry Range 순서가 오락가락 할때 Validation 필요
                // let minFrom = Math.min.apply( null, fromArr );
                if( data[0].props[0].propertyName == "a2From" ) {
                    if( res[0].uid != data[0].identifier ) {
                        if( Number( res[0].props.a2From.dbValues[0] ) >= Number( data[0].props[0].dbValues[0] ) ) {
                            msg = "ExistSampleRange"
                            bool = false;
                        }
                    }
                }
                if( !bool ) {  
                    AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, msg ) );
                    await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, String( data[0].props[0].uiValues[0] ) );
                    return false;
                } else {
                    await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, String( data[0].props[0].dbValues[0] ) );
                }
            }
        } );
    // AC, RE Validation
    } else if ( data[0].props[0].propertyName == "a2AC" ) {
        if( Number( data[0].props[0].dbValues[0] ) > Number( selected.props.a2RE.dbValues[0] ) ) {
            await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, selected.props[ data[0].props[0].propertyName ].uiValues[0] );
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "ACBig" ) );
            return false;
        }
        await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, String( data[0].props[0].dbValues[0] ) );
    } else if ( data[0].props[0].propertyName == "a2RE" ) {
        if( Number( data[0].props[0].dbValues[0] ) < Number( selected.props.a2AC.dbValues[0] ) ) {
            await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, selected.props[ data[0].props[0].propertyName ].uiValues[0] );
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "ACBig" ) );
            return false;
        }
        await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, String( data[0].props[0].dbValues[0] ) );
    }
    // Sample Unit LOV에 잘못된 값 입력 Error
    await AwcObjectUtil.setProperty( AwcObjectUtil.getObject(data[0].identifier), data[0].props[0].propertyName, String( data[0].props[0].dbValues[0] ) ).catch( ( e ) => {
        AwcNotificiationUtil.show("ERROR", e.message);
        eventBus.publish( 'primaryWorkarea.reset' );
    });
    return Promise.resolve();
}

// 변경 없이 edit 종료
export let bluredAction = async ( ctx ) => {
    let setArr = [ "a2Index", "a2From", "a2To", "a2SampleSize", "a2SampleUnit", "a2AC", "a2RE" ];
    let tableElement = document.getElementById( "SampleRangeEntryTable" );
    let table = viewModelService.getViewModelUsingElement( tableElement );
    let vmCol = table.dataProviders.SampleEntryTableDataProvider.viewModelCollection.loadedVMObjects;
    await AwcObjectUtil.getProperties( ctx.selected, setArr );
    for( const vmo of vmCol ) {
        if( ctx.selected.uid == vmo.uid ) {
            setArr.forEach( ( prop ) => {
                if( Number.isInteger( vmo.props[ prop ].uiValue) ) {
                    AwcObjectUtil.setProperty( vmo, prop, String( ctx.selected.props[ prop ].dbValues[0] ) );
                }
            } );
        }
    }
}

export default exports = {
    addColumn,
    loadColumns,
    splmTableStartEdit,
    splmTableSaveEdit,
    bluredAction,
    getA2SampleUnit
};
app.factory("A2QSampleRangeService", () => exports);
