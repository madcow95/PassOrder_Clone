/**
 * QMS Search Panel Service
 *
 * @module js/A2QTagetSheetRTService
 */

import awcObjectUtil from 'js/AwcObjectUtil';
import uwPropertyService from 'js/uwPropertyService';
import eventBus from 'js/eventBus';
import appCtxService from 'js/appCtxService';
import AwcLocalizationUtil from 'js/AwcLocalizationUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import A2QCheckService from 'js/A2QCheckService';
import dmSvc from 'soa/dataManagementService';
import QMSCommonService from 'js/QMSCommonService';


/**
 * @param {String} ctx - context
 */
export let loadProperties = async function( data, ctx ) {
    const interval = setInterval( async () => {
        if( ctx.xrtSummaryContextObject ) {
            clearInterval( interval );
            // await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2SearchCriteria" );
            // await awcObjectUtil.getProperties( ctx.xrtSummaryContextObject, searchCriteriaList );
            await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2TargetSheetRT");
            let prop = ctx.xrtSummaryContextObject.props[ "a2TargetSheetRT" ];
            data[ "a2TargetSheetRT" ] = prop;
            uwPropertyService.setIsEditable( prop, true );

            //let partPQCnt = data.a2PartQualifyListCountRT.dbValue;
            if(ctx.xrtSummaryContextObject.type == "A2QPartIPItemRevision" || ctx.xrtSummaryContextObject.type == "A2QPartPTPItemRevision")
            {
                await awcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2PrincipalRT" );
                let principalProp = ctx.xrtSummaryContextObject.props[ "a2PrincipalRT" ];
                data[ "a2PrincipalRT" ] = principalProp;
                uwPropertyService.setIsEditable( principalProp, true );
            }

            let pqList = await awcObjectUtil.getReferencedProperties(ctx.xrtSummaryContextObject, "a2PartQualifyListRT");
            awcObjectUtil.refreshObjects2(pqList, false);
        }
    } );
}

export let createPartIPCheckByQPAction = async function( data, ctx ) {


    if(!data.a2TargetSheetRT.dbValue){
        // Sheet 선택 안됨
        AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NoSelectedTargetSheet"));
        return;
    }else if(!data.a2PrincipalRT.dbValue){
        // Principal 선택 안됨
        AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NoSelectedPrincipal"));
        return;
    }

    let principal = data.a2PrincipalRT.dbValues[0];

    let seletedSheet = awcObjectUtil.getObject(data.a2TargetSheetRT.dbValue);
    var mselected = ctx.mselected;

    if(mselected){

        for (let i = 0; i < mselected.length; i++) {
            if(mselected[i].type != "A2QPQEntryRuntime" && mselected[i].type != "A2ProdQEntryRuntime"){
                // 인정 시험정보 선택 안됨
                AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedPQ"));
                return;
            }
        }

        let cls1Uids = [];
        let cls2Uids = [];
        for (let i = 0; i < mselected.length; i++) {

            await awcObjectUtil.getProperties( mselected[i], ["a2IsInsideCreated", "a2IsOutsideCreated"]);

            if(principal == "InSide" && mselected[i].props.a2IsInsideCreated.dbValues[0] == 1){
                AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "CreatedInsidePQSelected"));
                return;
            }else if(principal == "OutSide" && mselected[i].props.a2IsOutsideCreated.dbValues[0] == 1){
                AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "CreatedOutsidePQSelected"));
                return;
            }



            // 부품 검사항목인 경우 검사분류/검사명 Validation Check
            if( ctx.xrtSummaryContextObject.type == "A2QPartIPItemRevision" ){

                let mappingObj = await awcObjectUtil.loadObjects(mselected[i].props.a2MappingObject.dbValues[0]);
                await awcObjectUtil.refreshObjects2([mappingObj],false);

                await awcObjectUtil.getProperties( mappingObj, ["a2Class1Obj", "a2Class2Obj"]);

                cls1Uids.push(mappingObj.props.a2Class1Obj.dbValues[0]);
                cls2Uids.push(mappingObj.props.a2Class2Obj.dbValues[0]);
            }
            
        }

        // 부품 검사항목인 경우 검사분류/검사명 Validation Check
        if( ctx.xrtSummaryContextObject.type == "A2QPartIPItemRevision" ){
            // CTQ/인정시험 연계시 검사주체는 사내(Inside)로 고정 향후 필요시 입력받아야 함
            let valid = await A2QCheckService.iPCheckItemValidation(cls1Uids, cls2Uids, principal, ctx);
            if( !valid ){
                return;
            }
        }

        for (let i = 0; i < mselected.length; i++) {
            await awcObjectUtil.setProperty( mselected[i], "a2IsSelected", "true" );

        }

        await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetSheetRT", seletedSheet );
        await awcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2PrincipalRT", principal );

        await awcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2EventProperty", "CREATEBYPQ" ).then( () => {
            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "PartIPCheckItemCreated"));
            eventBus.publish( 'cdm.relatedModified', {
                efreshLocationFlag: true,
                relatedModified: [
                    appCtxService.ctx.locationContext.modelObject
                ]
            });
        });

    }
    else{
        // 인정 시험정보 선택 안됨
        AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedPQ"));
    }

}

export let createProdIPCheckByQPAction = async function( data, ctx ) {
    if(data.a2TargetSheetRT.dbValue)
    {
        let seletedSheet = awcObjectUtil.getObject(data.a2TargetSheetRT.dbValue);
        var mselected = ctx.mselected;

        if(mselected){

            for (let i = 0; i < mselected.length; i++) {
                if(mselected[i].type != "A2QPQEntryRuntime" && mselected[i].type != "A2ProdQEntryRuntime"){
                    // 인정 시험정보 선택 안됨
                    AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedPQ"));
                    return;
                }
            }


            for (let i = 0; i < mselected.length; i++) {

                await awcObjectUtil.getProperty( mselected[i], "a2IsCreated");

                if(mselected[i].props.a2IsCreated.dbValues[0] == 1){
                    AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "CreatedPQSelected"));
                    return;
                }
            }
            for (let i = 0; i < mselected.length; i++) {
                await awcObjectUtil.setReferencedProperty( ctx.xrtSummaryContextObject, "a2TargetSheetRT", seletedSheet );
                await awcObjectUtil.setProperty( mselected[i], "a2IsSelected", "true" );

            }
            await awcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2EventProperty", "CREATEBYPQ" ).then( () => {
                AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "PartIPCheckItemCreated"));
                eventBus.publish( 'cdm.relatedModified', {
                    efreshLocationFlag: true,
                    relatedModified: [
                        appCtxService.ctx.locationContext.modelObject
                    ]
                });
            });

        }
        else{
            // 인정 시험정보 선택 안됨
            AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NOSelectedPQ"));
        }
    }
    else{
        // Sheet 선택 안됨
        AwcNotificiationUtil.show("INFO",  AwcLocalizationUtil.getLocalizedText("A2InspectionLocalizationMessages", "NoSelectedTargetSheet"));
    }
}

export let editHandlerStateChangeAction = function( data, ctx, eventData ) {

    // Target Sheet는 강제 Edit Mode로 변경 한 속성임, 같은 화면에 존재하는 Object Set Table Data 편집이 된경우
    // Target Sheet의 Edit Mode가 해제 되므로 강제 편집모드로 설정 함.
    let prop = ctx.xrtSummaryContextObject.props[ "a2TargetSheetRT" ];
    uwPropertyService.setIsEditable( prop, true );

    let principalProp = ctx.xrtSummaryContextObject.props[ "a2PrincipalRT" ];
    uwPropertyService.setIsEditable( principalProp, true );
}


export  let targetSheetChanged = async function( data, ctx, eventData) {

    // Target Sheet 변경 후 CTQ/인정시험 항목 수정시 ctx.locationContext.modelObject Refresh 필요 메시지가 출력됨
    // Taget Sheet 변경 시 ctx.locationContext.modelObject의 Last Save Date를 최신으로 수정하여 해결
    let input = {
        obj : { 
            uid : ctx.locationContext.modelObject.uid,
            type : ctx.locationContext.modelObject.type
        },
        viewModelProperties : [],
        workflowData : {}
    };

    let dateCurrent = QMSCommonService.getCurrentDate(new Date());
    let prop = ctx.xrtSummaryContextObject.props[ "a2TargetSheetRT" ];
    prop.sourceObjectLastSavedDate = dateCurrent;
    dmSvc.pushViewModelProperty(input, prop);

}
export  let principalChanged = async function( data, ctx, eventData) {

    // 검사주체 변경 후 CTQ/인정시험 항목 수정시 ctx.locationContext.modelObject Refresh 필요 메시지가 출력됨
    // 검사주체 변경 시 ctx.locationContext.modelObject의 Last Save Date를 최신으로 수정하여 해결
    let input = {
        obj : { 
            uid : ctx.locationContext.modelObject.uid,
            type : ctx.locationContext.modelObject.type
        },
        viewModelProperties : [],
        workflowData : {}
    };

    let dateCurrent = QMSCommonService.getCurrentDate(new Date());
    let prop = ctx.xrtSummaryContextObject.props[ "a2PrincipalRT" ];
    prop.sourceObjectLastSavedDate = dateCurrent;
    dmSvc.pushViewModelProperty(input, prop);

}



export default {
    loadProperties,
    createPartIPCheckByQPAction,
    createProdIPCheckByQPAction,
    editHandlerStateChangeAction,
    targetSheetChanged,
    principalChanged
};
