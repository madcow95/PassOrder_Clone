import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import soaService from 'soa/kernel/soaService';
import locale from 'js/AwcLocalizationUtil';
import viewModelService from 'js/viewModelService';
import uwPropertyService from 'js/uwPropertyService';
import viewModelObjectSvc from 'js/viewModelObjectService';
import AwcQueryUtil from 'js/AwcQueryUtil';
import appCtxService from 'js/appCtxService';
import editHandlerService from 'js/editHandlerService';
import AwcPageUtil from 'js/AwcPageUtil';
import navigationSvc from 'js/navigationService';
import popupSvc from 'js/popupService';
import uwPropertySvc from 'js/uwPropertyService';
import _ from 'lodash';
import QmsNewCommandService from 'js/A2QmsnewCommandService';
 
var exports = {};
let localeText = "lgspQmsNewInspectionMessages";

export let APCreateLoad = ( data, ctx ) => {
    const load = setInterval( () => {
        if( ctx.xrtSummaryContextObject ){
            if( ctx.xrtSummaryContextObject.type.includes( "A2QAnnualPlan" ) ) {
                if( ctx.xrtSummaryContextObject.type.includes( "Prod" ) ) {
                    if( data.a2AnnaulPlanRT && data.a2QModelSuffixRT ) {
                        clearInterval( load );
                        uwPropertyService.setValue( data.a2AnnaulPlanRT, [ ctx.xrtSummaryContextObject.uid ] );
                    }
                } else if( ctx.xrtSummaryContextObject.type.includes( "Part" ) ) {
                    if( data.a2AnnaulPlanRT && data.a2QSupplierRT ) {
                        clearInterval( load );
                        uwPropertyService.setValue( data.a2AnnaulPlanRT, [ ctx.xrtSummaryContextObject.uid ] );
                    }
                }
            }
        }
    } );
}

export let createAction = async ( data, ctx ) => {
    let createType = data.objCreateInfo.createType;
    let createProperties = new Array();
    await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2OrgCode" );
    let a2OrgCode = ctx.xrtSummaryContextObject.props.a2OrgCode.dbValues[0];
    let searchCriteriaArr = [];
    // 연간 보증시험 계획에서 보증시험 항목을 검색하기 위한 속성
    if( createType.includes( "Prod" ) ) {
        searchCriteriaArr = [
            "a2SearchProdGroup1RT","a2SearchProdGroup2RT","a2SearchProdGroup3RT","a2SearchPlanChangeTypeRT","a2SearchHasPTPlanRT",
            "a2SearchIsUsedRT","a2SearchConfirmYNRT"
        ];
    } else {
        searchCriteriaArr = [
            "a2SearchProdGroup1RT","a2SearchPartGroup1RT","a2SearchPartGroup2RT","a2SearchPartGroup3RT","a2SearchPlanChangeTypeRT",
            "a2SearchHasPTPlanRT","a2SearchIsUsedRT","a2SearchConfirmYNRT"
        ];
    }
    createProperties.push(
        { a2ObjectName : data.a2ObjectName.dbValue },
        { a2OrgCodeRT   : a2OrgCode ? a2OrgCode : "" },
        { a2SearchCriteria : searchCriteriaArr.toString() }
    )
    for( const prop in data ) {
        if( prop.includes( "a2" ) ) {
            createProperties.push(
                { [ prop ] : data[ prop ].dbValue ? data[ prop ].dbValue : data[ prop ].dbValues[0] ? data[ prop ].dbValues[0] : "" }
            )
        }
    }
    AwcObjectUtil.createRuntimeObject(
        createProperties,
        createType
    ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
        AwcPanelUtil.closeCommandPanel();
    } ).catch( ( e ) => {
        AwcNotificiationUtil.show("ERROR", e.message);
    } );
}

export let A2QAnnObjDeleteAction = ( data, ctx ) => {
    AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "checkDeleteSelected" ), 
                             [ "Yes", "No" ], 
                             [
                                async () => {
                                    for( const selected of ctx.mselected ) {
                                        await AwcObjectUtil.getProperty( selected, "release_status_list" );
                                        if( selected.props.release_status_list.dbValue[0] ) {
                                            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText(localeText, "AssignPlanDelFail" ) );
                                            return false;
                                        }
                                    }
                                    _removeQObj( ctx );
                                },
                                () => {}
                             ]);
}

let _removeQObj = async ( ctx ) => {
    let delData = {
        objects: []
    }
    let selectedTargets = ctx.mselected;
    // Relation관계인 a2PlanObject와 a2ResultObject를 먼저 삭제
    if( ctx.selected.type.includes( 'Revision' ) ) {
        for( const target of selectedTargets ) {
            await AwcObjectUtil.getProperties( target, [ "items_tag", "a2PlanObject", "a2ResultObject" ] );
            if( target.props.a2PlanObject.dbValue && target.props.a2ResultObject.dbValue ) {
                delData.objects.push( AwcObjectUtil.getObject( target.props.a2PlanObject.dbValue ) );
                delData.objects.push( AwcObjectUtil.getObject( target.props.a2ResultObject.dbValue ) );
            }
            delData.objects.push( AwcObjectUtil.getObject( target.props.items_tag.dbValues[0] ) );
        }
    }

    // 소유자만 삭제 가능
    let currentUser = ctx.user.uid;
    for( const obj of delData.objects ) {
        await AwcObjectUtil.getProperty( obj, "owning_user" );
        let createUser = obj.props.owning_user.dbValues[0];
        if( currentUser != createUser ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'DeleteErrorNotOwner' ) );
            return;
        }
    }
    soaService.post( 'Core-2006-03-DataManagement', 'deleteObjects', delData ).then( () => {
        AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( "lgspFMEAMessages", 'a2DeleteComplete' ) );
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    }).catch( ( e ) => {
        AwcNotificiationUtil.show("ERROR", e.message);
        // QmsNewCommandService.A2QmsDeleteAction( ctx );
    })
}

export let A2CreateGeneralWorkflowAction = async ( ctx, data, commandId, commandCxt ) => {
    let selected = ctx.mselected;
    let workflowName = commandCxt.parameterMap[commandId].workflowName;
    let paramList = commandCxt.parameterMap[commandId].assignList;
    if( !workflowName ) {
        AwcNotificiationUtil.showParam( "ERROR", 
                                    locale.getLocalizedText( "lgspQmsCommonMessages", "A2StyleSheetSettingError" ),
                                    [ 'workflowName' ] );
        return;
    }    
    if( !paramList || paramList.length == 0 ) {
        AwcNotificiationUtil.showParam( "ERROR",
                                    locale.getLocalizedText( "lgspQmsCommonMessages", "A2StyleSheetSettingError" ),
                                    [ 'assignList' ] );
        return;
    }
    let assignList = paramList.split( "," );
    let uidList = [];
    let typeList = [];
    let planArr = [ "a2P01", "a2P02", "a2P03", "a2P04", "a2P05", "a2P06", "a2P07", "a2P08", "a2P09", "a2P10", "a2P11", "a2P12" ];
    // 각각의 객체에 결재정보가 있는지 확인한다.- 없으면 에러
    // 각각의 객체에 결재진행중(process_stage_list) 정보 또는 결재완료(release_status_list) 정보가 있는지 체크한다. - 있으면 에러
    for( let vmo of selected ){
        for( let assignee of assignList ){
            await AwcObjectUtil.getProperties( vmo, [ "process_stage_list", "release_status_list" ] );
            if(!vmo.props[ assignee ] || vmo.props[ assignee ].dbValue.length == 0 ) {
                AwcNotificiationUtil.showParam( "ERROR", 
                                            locale.getLocalizedText( "lgspQmsCommonMessages", "A2EmptyAssigneeError" ),
                                            [ vmo.props.object_string.dbValue, assignee ] );
                return;
            }

            if(vmo.props[ 'process_stage_list' ] && vmo.props[ 'process_stage_list' ].dbValue.length != 0 ) {
                AwcNotificiationUtil.showParam( "ERROR", 
                                            locale.getLocalizedText( "lgspQmsCommonMessages", "A2AleadyInProcessError" ),
                                            [ vmo.props.object_string.dbValue ] );
                return;
            }

            if(vmo.props[ 'release_status_list' ] && vmo.props[ 'release_status_list' ].dbValue.length != 0 ) {
                AwcNotificiationUtil.showParam( "ERROR", 
                                            locale.getLocalizedText( "lgspQmsCommonMessages", "A2AleadyReleaseError" ),
                                            [ vmo.props.object_string.dbValue ] );
                return;
            }
        }
        await AwcObjectUtil.getProperties( vmo, planArr );
        let planCheck = planArr.some( ( plan ) => {
            return vmo.props[ plan ].dbValue
        } );
        if( !planCheck ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "workflowAssignErr" ) );
            return;
        }
        uidList.push( vmo.uid );
        typeList.push( 1 );
    }    // 한꺼번에 W/F 실행할때...
    // 단, 첫번째 대상의 Assignee정보를 통하여 W/F가 진행이 된다.
    let soaInputParam = {};
    let attachCount = selected.length;
    
    soaInputParam = {
        name: attachCount == 1 ? `[${selected[0].modelType.displayName} ${locale.getLocalizedText( localeText, "rufwo")}]: ${selected[0].props.object_string.dbValue}` : `[${selected[0].modelType.displayName} - ${attachCount} ${locale.getLocalizedText( localeText, "gunrufwo")}]: ${selected[0].props.object_string.dbValue}`,
        description: attachCount == 1 ? `[${selected[0].modelType.displayName} ${locale.getLocalizedText( localeText, "rufwo")}]: ${selected[0].props.object_string.dbValue}` : `[${selected[0].modelType.displayName} - ${attachCount} ${locale.getLocalizedText( localeText, "gunrufwo")}]: ${selected[0].props.object_string.dbValue}`,
        contextData:{
            attachmentCount : 1,
            attachments: uidList,
            processTemplate : workflowName,
            attachmentTypes : [ 1 ]
        }
    }

    soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( () => {
        AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( "lgspQmsCommonMessages", "A2CreateWorkflowSuccess" ) );
    }).catch( ( e ) => {
        AwcNotificiationUtil.show( "ERROR", "failed. \n" + e.message );
    }).finally( () => {
        eventBus.publish( 'primaryWorkarea.reset' );
    });
}

export let A2QEmailToSupplierWorkflow = async ( ctx, data, commandId, commandCxt ) => {
    let selected = ctx.mselected;
    let workflowName = commandCxt.parameterMap[ commandId ].workflowName;
    let paramList = commandCxt.parameterMap[ commandId ].assignList;
    let uidList = [];
    let planArr = [ "a2P01", "a2P02", "a2P03", "a2P04", "a2P05", "a2P06", "a2P07", "a2P08", "a2P09", "a2P10", "a2P11", "a2P12" ];
    for(let vmo of selected){
        
        await AwcObjectUtil.getProperties( vmo, planArr );
        let planCheck = planArr.some( ( plan ) => {
            return vmo.props[ plan ].dbValue
        } );
        if( !planCheck ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "emailErr" ) );
            return;
        }
        await AwcObjectUtil.getProperties( vmo, [ paramList, "owning_user", "a2WRequester", "a2SupplierUser", "a2PlanObject" ] );
        if( !vmo.props.a2SupplierUser.dbValue ) {
            AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "EmptySupplierUser" ) );
            return;
        }

        if( !vmo.props[ paramList ] || vmo.props[ paramList ].dbValue.length == 0 ) {
            AwcNotificiationUtil.showParam( "ERROR", 
                                        locale.getLocalizedText( "lgspQmsCommonMessages", "A2EmptyAssigneeError" ),
                                        [ vmo.props.object_string.dbValue, paramList ] );
            return;
        }

        if( vmo.props[ 'process_stage_list' ] && vmo.props[ 'process_stage_list' ].dbValue.length != 0 || vmo.props[ 'fnd0MyWorkflowTasks' ] && vmo.props[ 'fnd0MyWorkflowTasks' ].dbValue.length != 0 ) {
            AwcNotificiationUtil.showParam( "ERROR", 
                                        locale.getLocalizedText( "lgspQmsCommonMessages", "A2AleadyInProcessError" ),
                                        [ vmo.props.object_string.dbValue ] );
            return;
        }

        if(vmo.props[ 'release_status_list' ] && vmo.props[ 'release_status_list' ].dbValue.length != 0 ) {
            AwcNotificiationUtil.showParam( "ERROR", 
                                        locale.getLocalizedText( "lgspQmsCommonMessages", "A2AleadyReleaseError" ),
                                        [ vmo.props.object_string.dbValue ] );
            return;
        }
        uidList.push( vmo.uid );
    }
    
    let soaInputParam = {};
    let attachCount = selected.length;
    

    for( let i = 0; i < attachCount; i++ ) {
        let PartUid = selected[i].props.a2PartRT.dbValue;
        soaInputParam = {
            name: `[${selected[i].modelType.displayName} ${locale.getLocalizedText( localeText, "rufwo")}]: ${selected[i].props.object_string.dbValue}}`,
            contextData:{
                attachmentCount : 2,
                attachments: [ selected[i].uid, PartUid ],
                processTemplate : workflowName,
                attachmentTypes : [ 1, 3 ]
            }
       }

       await soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).catch( ( e ) => {
            AwcNotificiationUtil.show("ERROR", "failed. \n" + e.message);
        });
    }

    AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( localeText, "EmailSendedCompletely" ) );
    eventBus.publish( 'primaryWorkarea.reset' );
}

export let viewAllAPEntriesAction = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsView", "true" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    } );
}

export let viewLatestAPEntriesAction = ( data, ctx ) => {
    AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2IsView", "false" ).then( () => {
        eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
    } );
}

export let selfReleaseAction = async ( data, ctx ) => {
    AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( localeText, "releaseCheck" ), 
                             [ "Yes", "No" ], 
                             [
                                async () => {
                                    await AwcObjectUtil.getProperty( ctx.selected, "release_status_list" );
                                    if( ctx.selected.props.release_status_list.dbValues[0] ) {
                                        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'ApprovalAlreadyCompleted' ) );
                                        return;
                                    }
                                    AwcObjectUtil.createInstance( ctx.selected, "QMS_A2QuickReleased" ).then( () => {
                                        AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( localeText, "releaseComplete" ) );
                                        // eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
                                        eventBus.publish( 'primaryWorkarea.reset' );
                                    });
                                },
                                () => {}
                             ]);
}

export let A2QPeriodRevise = ( data, ctx ) => {
    AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( localeText, "reviseCheck" ), 
                             [ "Yes", "No" ], 
                             [
                                async () => {
                                    await AwcObjectUtil.getProperty( ctx.selected, "release_status_list" );
                                    if( !ctx.selected.props.release_status_list.dbValues[0] ) {
                                        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, 'notReleased' ) );
                                        return;
                                    }
                                    AwcObjectUtil.revise( ctx.selected ).then( ( rev ) => {
                                        let changeUser = ctx.user.props.object_string.dbValues[0]
                                        AwcObjectUtil.setProperty( rev, "a2ChangeUser", changeUser );
                                        AwcNotificiationUtil.show( "INFO", locale.getLocalizedText( localeText, "inspectionPlanReviseSuccess") );
                                        // eventBus.publish( 'ObjectSet_1_Provider.plTable.reload' );
                                        eventBus.publish( 'primaryWorkarea.reset' );
                                    })
                                },
                                () => {}
                             ]);
    
}


export default exports = {
    createAction,
    APCreateLoad,
    A2QAnnObjDeleteAction,
    viewAllAPEntriesAction,
    viewLatestAPEntriesAction,
    // nameReload,
    A2QEmailToSupplierWorkflow,
    selfReleaseAction,
    A2QPeriodRevise,
    A2CreateGeneralWorkflowAction
};
app.factory('A2QCheckService', () => exports);