
import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import _ from 'lodash';
import soaService from 'soa/kernel/soaService';
import cdm from 'soa/kernel/clientDataModel';
import {ProgressStatusPopup} from 'js/ProgressStatusPopupService';

var exports = {};

var inspectionRequestRevision = null;
var inspectionPlanRevision = null;
var inspectionCheckSheet = null;
var inspectionCheckSet = null;
var definitionCount = 0;
var similarFlag = false;
var requestFlag = false;

export async function cloneInspectionTemplateToPlan(template, parameters) {
    var progressBar = new ProgressStatusPopup(600, 200, false);
     progressBar.setBodyText("검사 기준을 생성하는 중");
     progressBar.setFooterText("잠시만 기다려 주세요.");
     return progressBar.open().then ( async function() {
         inspectionPlanRevision = null;
         inspectionCheckSheet = null;
         inspectionCheckSet = null;
         definitionCount = 0;
     
         //템플릿 -> 검사 기준 생성
         inspectionPlanRevision = await _createInspectionPlan(template, parameters);
         
         //하위 재귀함수를 통한 생성
         await _createObjectsRecursive(template, inspectionPlanRevision, inspectionPlanRevision.props.object_name.dbValues[0]);
         progressBar.close();
         return;
     }).then( () => {
         return;
     })
}
export async function cloneInspectionPlanToPlan(originalPlan, parameters) {
    var progressBar = new ProgressStatusPopup(600, 200, false);
     progressBar.setBodyText("검사 기준을 생성하는 중");
     progressBar.setFooterText("잠시만 기다려 주세요.");
     return progressBar.open().then ( async function() {
         similarFlag = true;
         inspectionPlanRevision = null;
         inspectionCheckSheet = null;
         inspectionCheckSet = null;
         definitionCount = 0;
     
         //템플릿 -> 검사 기준 생성
         inspectionPlanRevision = await _saveAsInspectionPlan(originalPlan, parameters);
         
         //하위 재귀함수를 통한 생성
         await _createObjectsRecursive(originalPlan, inspectionPlanRevision, inspectionPlanRevision.props.object_name.dbValues[0]);
         progressBar.close();
         similarFlag = false;
         return;
     }).then( () => {
         return;
     })
}
export async function cloneInspectionPlanToRequest(originalPlan, parameters) {
    var progressBar = new ProgressStatusPopup(600, 200, false);
     progressBar.setBodyText("검사 의뢰를 생성하는 중");
     progressBar.setFooterText("잠시만 기다려 주세요.");
     return progressBar.open().then ( async function() {
         requestFlag = true;
         inspectionRequestRevision = null;
         inspectionPlanRevision = originalPlan;
         inspectionCheckSheet = null;
         inspectionCheckSet = null;
         definitionCount = 0;
     
         //템플릿 -> 검사 기준 생성
         inspectionRequestRevision = await _createInspectionRequest(originalPlan, parameters);
         // cosole.log("inspectionRequestRevision >>> ", inspectionRequestRevision)
         //하위 재귀함수를 통한 생성
         await _createObjectsRecursive(originalPlan, inspectionRequestRevision, inspectionRequestRevision.props.object_name.dbValues[0]);
         progressBar.close();
         requestFlag = false;
         return;
     }).then( () => {
         return;
     })
}
async function _createObjectsRecursive(original, clonned, path) {
    // cosole.log({original}, "==>", {clonned});
    //Contents 속성값 불러오기
    await AwcObjectUtil.getProperties(original, ["contents", "a2Id", "a2RevId", "item_id", "item_revision_id"], true);
    let contentUids = await _getProperties(original, "contents");
    let contentObjects = cdm.getObjects(contentUids);
    await AwcObjectUtil.getProperties(contentObjects, ["contents", "a2Id", "a2RevId", "item_id", "item_revision_id"], true);
    //// cosole.log({original}, {contentObjects});
    if(contentUids.length > 0) {
        // cosole.log({contentObjects});
        let array = [];
        for (const contentObject of contentObjects) {
            let pattern = "";
            if(AwcObjectUtil.instanceOf(contentObject, "ItemRevision")) {
                pattern = contentObject.props.item_id.dbValues[0] + "/" + contentObject.props.item_revision_id.dbValues[0]; 
            } else {
                pattern = contentObject.props.a2Id.dbValues[0] + "/" + contentObject.props.a2RevId.dbValues[0]; 
            }
            if(array.includes(pattern)) {
                continue;
            }
            array.push(pattern);

            let cloneObject = await createCloneObject(contentObject, clonned, path);
            if(AwcObjectUtil.instanceOf(cloneObject, "A2QPartCheckSheet")) {
                inspectionCheckSheet = cloneObject;
                inspectionCheckSet = null;
            }
            if(AwcObjectUtil.instanceOf(cloneObject, "A2QPartCheckItem")) {
                definitionCount++;
                await AwcObjectUtil.setProperty(cloneObject, "a2Index", (definitionCount*10).toString());
            }
            await _createObjectsRecursive(contentObject, cloneObject, path + "∥" + cloneObject.props.object_name.dbValues[0]);
        }
    }
}
async function createCloneObject(original, clonned, path) {
    await AwcObjectUtil.getProperties(original, ["a2Index",
    "a2InspectionPlan",
    "a2InspectionObject",
    "a2CheckSheetObject",
    "a2BasedOnId",
    "a2Id",
    "a2RevId",
	"a2InspTypeName",
	"a2TemplateType",
	"a2SeverityLevel",
	"a2NextCount",
	"a2PrevCount",
	"object_desc",
	"a2OrgCode",
	"a2PartGroupCode",
	"a2InsInputType",
	"a2InsSpec",
	"a2SampleMethod",
	"a2Principal",
	"a2AQLLevel",
	"a2AcReLevel",
	"a2SeverityLevel",
	"a2SampleRange",
	"a2ConInitValue",
	"a2ContinuousUnit",
	"a2ContinousDigit",
	"a2TargetValue",
	"a2Lsl",
	"a2Usl",
	"a2SampleSize",
	"a2Ac",
	"a2Re",
	"a2IsCTQ",
	"a2CTQMgmtMethod",
	"a2CTQMgmtSpec",
	"a2CTQLotCount",
	"a2MeasureMachine",
	"IMAN_reference",
	"IMAN_specification",
	"a2Contents",
	"a2PartString",
	"a2SupplierString",
	"a2TemplateTypeName",
	"a2OrgCode",
	"a2PartGroupCode",
	"a2PartInspectionPlan",
	"a2IsUsed"]);
    let params = [];
    _pushParamValue(original, "object_name", params);
    _pushParamValue(original, "a2Index", params);
    _pushParamValue(original, "a2InspTypeName", params);
    _pushParamValue(original, "a2TemplateType", params);
    _pushParamValue(original, "a2ModelSuffix", params);
    _pushParamValue(original, "a2SeverityLevel", params);
    _pushParamValue(original, "a2NextCount", params);
    _pushParamValue(original, "a2PrevCount", params);
    _pushParamValue(original, "object_desc", params);
    _pushParamValue(original, "a2OrgCode", params);
    _pushParamValue(original, "a2ProdGroupCode", params);
    _pushParamValue(original, "a2InsInputType", params);
    _pushParamValue(original, "a2InsSpec", params);
    _pushParamValue(original, "a2SampleMethod", params);
    _pushParamValue(original, "a2Principal", params);
    _pushParamValue(original, "a2AQLLevel", params);
    _pushParamValue(original, "a2AcReLevel", params);
    _pushParamValue(original, "a2SeverityLevel", params);
    _pushParamValue(original, "a2SampleRange", params);
    _pushParamValue(original, "a2ConInitValue", params);
    _pushParamValue(original, "a2ContinuousUnit", params);
    _pushParamValue(original, "a2ContinousDigit", params);
    _pushParamValue(original, "a2TargetValue", params);
    _pushParamValue(original, "a2Lsl", params);
    _pushParamValue(original, "a2Usl", params);
    _pushParamValue(original, "a2SampleSize", params);
    _pushParamValue(original, "a2Ac", params);
    _pushParamValue(original, "a2Re", params);
    _pushParamValue(original, "a2IsCTQ", params);
    _pushParamValue(original, "a2CTQMgmtMethod", params);
    _pushParamValue(original, "a2CTQMgmtSpec", params);
    _pushParamValue(original, "a2CTQLotCount", params);
    _pushParamValue(original, "a2PartString", params);
    _pushParamValue(original, "a2SupplierString", params);
    _pushParamValue(original, "a2TemplateTypeName", params);
    _pushParamValue(original, "a2OrgCode", params);
    _pushParamValue(original, "a2PartGroupCode", params);
    _pushParamValue(original, "a2PartInspectionPlan", params);
    _pushParamValue(original, "a2IsUsed", params);
    let cloneType = _getClonnedType(original.type);
    await _setIdAndRevId(cloneType, params);
    await _setParent(clonned, params);
    _setBasedOnId(original, params);
    //// cosole.log({params}, {cloneType});
    let response = await AwcObjectUtil.createAttachAndSubmitObjects(params, cloneType);
    for (const created of response.output[0].objects) {
        if(created.type == cloneType) {
            _createRelation(original, "a2MeasureMachine", created);
            _createRelation(original, "IMAN_reference", created);
            _createRelation(original, "IMAN_specification", created);
            _createRelation(original, "a2Contents", created);

            try {
                if(requestFlag) {
                    if(inspectionRequestRevision) await AwcObjectUtil.setProperty(created, "a2InspectionObject", inspectionRequestRevision.uid);
                    //if(inspectionPlanRevision) await AwcObjectUtil.setProperty(created, "a2InspectionPlan", inspectionPlanRevision.uid);
                } else {
                    if(inspectionPlanRevision) await AwcObjectUtil.setProperty(created, "a2InspectionObject", inspectionPlanRevision.uid);
                }
                if(inspectionCheckSheet) await AwcObjectUtil.setProperty(created, "a2CheckSheetObject", inspectionCheckSheet.uid);
            }catch(e) {
                // cosole.log(e);
            }
            return created;
        }
    }
}
async function _createRelation(original, propName, clonned) {
    if(propName && original.props[propName] && original.props[propName].dbValues && original.props[propName].dbValues.length > 0 && original.props[propName].dbValues[0] != null) {
        let targetObjects = AwcObjectUtil.getObjects(original.props[propName].dbValues);
        for (const targetObject of targetObjects) {
            AwcObjectUtil.createRelation(propName, clonned, targetObject);
        }
    }
}
function _setBasedOnId(original, params) {
    if(original.props.a2BasedOnId && original.props.a2BasedOnId.dbValues && original.props.a2BasedOnId.dbValues.length > 0 && original.props.a2BasedOnId.dbValues[0]) {
        // cosole.log({a2BasedOnId: original.props.a2BasedOnId.dbValues[0]});
        params.push({a2BasedOnId: original.props.a2BasedOnId.dbValues[0]});
    } else {
        let a2BasedOnId = "";
        if(AwcObjectUtil.instanceOf(original, "ItemRevision")) {
            a2BasedOnId = original.props.item_id.dbValues[0] + "/" + original.props.item_revision_id.dbValues[0];
            // cosole.log({a2BasedOnId});
            params.push({a2BasedOnId: a2BasedOnId});
        } else {
            a2BasedOnId = original.props.a2Id.dbValues[0] + "/" + original.props.a2RevId.dbValues[0];
            // cosole.log({a2BasedOnId});
            params.push({a2BasedOnId: a2BasedOnId});
        }
    }
}
async function _setIdAndRevId(cloneType, params) {
    // cosole.log("cloneType >>> ", cloneType);
    // cosole.log("params >>> ", params);
    if(!cloneType.includes("Revision")) {
        //// cosole.log("_setIdAndRevId", {cloneType});
        let id = await _getNextId(cloneType);
        let revId = "00";
        //// cosole.log("_setIdAndRevId", {id}, {revId})
        params.push({a2Id: [id]}, {a2RevId: [revId]});
    }
}
async function _setParent(parent, params) {
    let id;
    let revId;
    if(AwcObjectUtil.instanceOf(parent, "ItemRevision")) {
        id = await _getProperty(parent, "item_id");
        revId = await _getProperty(parent, "item_revision_id");
    } else {
        id = await _getProperty(parent, "a2Id");
        revId = await _getProperty(parent, "a2RevId");
    }
    params.push({a2ParentId: [id]}, {a2ParentRevId: [revId]});
}
function _pushParamValue(target, attrName, params) {
    let object = {};
    if(attrName && target.props[attrName] && target.props[attrName].dbValues && target.props[attrName].dbValues.length > 0 && target.props[attrName].dbValues[0] != null) {
        if(attrName == 'a2InsInputType' && AwcObjectUtil.instanceOf(target, 'A2QPartCheckItem') && target.props[attrName].dbValues[0] == 'Judgement') {
            object[attrName] = ['Judgment'];
        } else {
            object[attrName] = target.props[attrName].dbValues;
        }
    }
    if(!params.includes(object) && Object.keys(object).length > 0) {
        params.push(object);
    }
}
function _getClonnedType(childType) {
    if(similarFlag) return childType;
    let copyChildType = null;
	if ( tc_strcmp(childType, "A2QCheckGroup") == 0 ) 				copyChildType = MEM_string_copy("A2QProdIPCheckGroup");
	else if ( tc_strcmp(childType, "A2QProdIPCheckGroup") == 0 ) 	copyChildType = MEM_string_copy("A2QProdIRCheckGroup");
	else if ( tc_strcmp(childType, "A2QCheckItem") == 0 ) 			copyChildType = MEM_string_copy("A2QProdIPCheckItem");
	else if ( tc_strcmp(childType, "A2QProdIPCheckItem") == 0 ) 	copyChildType = MEM_string_copy("A2QProdInspectionResult");
	else if ( tc_strcmp(childType, "A2QCheckSet") == 0 ) 			copyChildType = MEM_string_copy("A2QProdIPCheckSet");
	else if ( tc_strcmp(childType, "A2QProdIPCheckSet") == 0 )		copyChildType = MEM_string_copy("A2QProdIRCheckSet");
	else if ( tc_strcmp(childType, "A2QCheckSheet") == 0 )			copyChildType = MEM_string_copy("A2QProdIPCheckSheet");
    else if ( tc_strcmp(childType, "A2QPartIPCheckSheet") == 0 )	copyChildType = MEM_string_copy("A2QPartIRCheckSheet");
	else if ( tc_strcmp(childType, "A2QPartCheckItem") == 0 )		copyChildType = MEM_string_copy("A2QPartIPCheckItem");
	else if ( tc_strcmp(childType, "A2QPartIPCheckItem") == 0 )		copyChildType = MEM_string_copy("A2QPartInspectionResult");
	else if ( tc_strcmp(childType, "A2QPartCheckSheet") == 0 )		copyChildType = MEM_string_copy("A2QPartIPCheckSheet");
	else if ( tc_strcmp(childType, "A2QProdIPCheckSheet") == 0 )	copyChildType = MEM_string_copy("A2QProdIRCheckSheet");
    return copyChildType;
}
function tc_strcmp(char1, char2) {
    if(char1 == char2) {
        return 0;
    } else {
        return 1;
    }
}
function MEM_string_copy(string) {
    return string;
}
async function _createInspectionPlan(template, parameters) {
    //템플릿 값 불러오기
    let item_id = await _getProperty(template, "item_id");
    let item_revision_id = await _getProperty(template, "item_revision_id");
    let object_name = await _getProperty(template, "object_name");
    let a2BasedOnId = item_id + "/" + item_revision_id;
    parameters.push({a2BasedOnId: a2BasedOnId});
    // cosole.log({parameters});
    let planName = parameters[4].a2PartString + "(" + parameters[0].a2SupplierString + ") " + parameters[2].a2InspTypeName + " 검사 기준";
    
    
    let boName = "A2QPartIPItem";
    let nextId = await AwcObjectUtil.getNextIds(boName, "item_id", '"PPI"NNNNNNN');
    let response = await AwcObjectUtil.createAttachAndSubmitObjects(nextId, planName, "", boName, "00",
        [{a2BasedOnId: a2BasedOnId}],
        parameters
    );
    let revision = null;
    for (const created of response.output[0].objects) {
        if (created.type == boName + "Revision") {
            revision = created;
            break;
        }
    }
    //// cosole.log({revision});
    return revision;
}
async function _saveAsInspectionPlan(originalPlan, parameters) {
    //기준 값 불러오기
    let a2BasedOnId = await _getProperty(originalPlan, "a2BasedOnId");
    parameters.push({a2BasedOnId: a2BasedOnId});
    // cosole.log({parameters});
    let planName = parameters[4].a2PartString + "(" + parameters[0].a2SupplierString + ") " + parameters[2].a2InspTypeName + " 검사 기준";

    let boName = "A2QPartIRItem";
    let nextId = await AwcObjectUtil.getNextIds(boName, "item_id", '"PPI"NNNNNNN');
    let response = await AwcObjectUtil.createAttachAndSubmitObjects(nextId, planName, "", boName, "00",
        [{a2BasedOnId: a2BasedOnId}],
        parameters
    );
    let revision = null;
    for (const created of response.output[0].objects) {
        if (created.type == boName + "Revision") {
            revision = created;
            break;
        }
    }
    //// cosole.log({revision});
    return revision;
}
async function _createInspectionRequest(originalPlan, parameters) {
    /* {a2ModelSuffix: data.a2ModelSuffix.dbValue ? data.a2ModelSuffix.dbValue : ""}, 
    {a2TemplateType: inspectionPlan.props.a2TemplateType.dbValues[0] ? inspectionPlan.props.a2TemplateType.dbValues[0] : ""},
    {a2InspTypeName: inspTypeName}*/

    //템플릿 값 불러오기
    let item_id = await _getProperty(originalPlan, "item_id");
    let item_revision_id = await _getProperty(originalPlan, "item_revision_id");
    let object_name = await _getProperty(originalPlan, "object_name");
    let a2BasedOnId = item_id + "/" + item_revision_id;
    let a2OrgCode = await _getProperty(originalPlan, "a2OrgCode");
    let a2PartGroupCode = await _getProperty(originalPlan, "a2PartGroupCode");
    parameters.push({a2BasedOnId: a2BasedOnId});
    
    let requestName = parameters[2].a2PartString + "(" + parameters[3].a2SupplierString + ") " + parameters[0].a2InspTypeName + " 검사 의뢰";
    parameters.push({a2OrgCode: a2OrgCode}, {a2PartGroupCode: a2PartGroupCode}, {a2Status: "Create"});
    // cosole.log({parameters});
    
    let boName = "A2QPartIRItem";
    let nextId = await AwcObjectUtil.getNextIds(boName, "item_id", '"PRI"NNNNNNN');
    // cosole.log({nextId}, {requestName}, {boName});
    let response = await AwcObjectUtil.createAttachAndSubmitObjects(nextId, requestName, "", boName, "00",
        [{a2BasedOnId: a2BasedOnId}],   // A2QPartIRItem
        parameters                      // A2QPartIRItemRevision
    );
    let revision = null;
    for (const created of response.output[0].objects) {
        if (created.type == boName + "Revision") {
            revision = created;
            break;
        }
    }
    return revision;
}
async function _getProperty(modelObject, attributeName) {
    if(!modelObject.props[attributeName]) {
        let soaInputParam = {
            objects: [modelObject],
            attributes: [attributeName]
        }
        await soaService.post( 'Core-2006-03-DataManagement', 'getProperties', soaInputParam );
    }
    return modelObject.props[attributeName].dbValues[0];
}
async function _getProperties(modelObject, attributeName) {
    if(!modelObject.props[attributeName]) {
        let soaInputParam = {
            objects: [modelObject],
            attributes: [attributeName]
        }
        await soaService.post( 'Core-2006-03-DataManagement', 'getProperties', soaInputParam );
    }
    return modelObject.props[attributeName].dbValues;
}
async function _getNextId(cloneType) {
    //// cosole.log("_getNextId", {type: cloneType});
    let pattern =  _getNextIdPattern(cloneType);
    //// cosole.log("_getNextIdPattern", {pattern});
    let nextId = await AwcObjectUtil.getNextIds(cloneType, "a2Id", _getNextIdPattern(cloneType));
    //// cosole.log("_getNextId", {nextId});
    return nextId;
}
function _getNextIdPattern(type) {
    if( type == "A2QPartIPCheckSheet" ) return '"PPS"NNNNNNN';
    if( type == "A2QPartIPCheckSet" ) return '"PPT"NNNNNNN';
    if( type == "A2QPartIPCheckItem" ) return '"PPE"NNNNNNN';
    if( type == "A2QPartIPCheckGroup" ) return '"PPG"NNNNNNN';
    if( type == "A2QPartIRCheckSheet" ) return '"PRS"NNNNNNN';
    if( type == "A2QPartIRCheckSet" ) return '"PRT"NNNNNNN';
    if( type == "A2QPartIRCheckItem" ) return '"PRE"NNNNNNN';
    if( type == "A2QPartIRCheckGroup" ) return '"PRG"NNNNNNN';
    if( type == "A2QPartInspectionResult" ) return '"PRE"NNNNNNN';
}
export default exports = {
    cloneInspectionTemplateToPlan,
    cloneInspectionPlanToPlan,
    cloneInspectionPlanToRequest
};
app.factory('A2InspectionCloneService', () => exports);