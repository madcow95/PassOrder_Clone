/**
 * QMSCommonService
 *
 * @module js/A2InspectionTemplateService
 */

import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import AwcQueryUtil from 'js/AwcQueryUtil';
import uwPropertyService from 'js/uwPropertyService';
import locale from 'js/AwcLocalizationUtil';
import _ from 'lodash';
import $ from 'jquery';
import viewModelService from 'js/viewModelService';

var exports = {};
let localeText = "lgspQmsNewInspectionMessages";

export let InsTreeCreateLoad = ( data, ctx, evtData ) => {
    const interval = setInterval( async () => {
        if( ctx.xrtSummaryContextObject ) {
            if( data.objCreateInfo ) {
                clearInterval( interval );
                let targetClass = document.getElementsByClassName( "aw-widgets-propertyContainer" );
                if( data.objCreateInfo.createType.includes( 'CheckItem' ) ) {
                    if( data.objCreateInfo.createType == "A2QPartCheckItemRuntime" ) {
                        data.a2ObjectName.isRequired = false;
                        uwPropertyService.setValue( data.a2ObjectName, "N/A" );
                    }
                    if( data.a2InsInputType.dbValues[0] != "Continuous") {
                        if( evtData ) {
                            for( const prop in data ) {
                                if( [ "a2ConInitValue", "a2ContinousDigit", "a2QContinuousUnit", "a2TargetValue", "a2Lsl", "a2Usl", "a2TargetRange" ].includes( prop ) ) {
                                    let prevData = data[ prop ].prevDisplayValues[0];
                                    if( prop == "a2QContinuousUnit" ) {
                                        data[ prop ].dbValues[0] = "";
                                    }

                                    if( prevData.includes( ".0000000" ) ) {
                                        prevData = parseInt( prevData );
                                    }
                                    
                                    uwPropertyService.resetValues( data[ prop ] );
                                    uwPropertyService.setValue( data[ prop ], prevData );
                                }
                            }
                        }
                        /**
                         * Todo display 공통 함수 만들어서 코드 줄이기
                         */
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "TargetValue" ) ) || target.innerText.includes( "LSL" ) || target.innerText.includes( "USL" ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "InitValue" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "ConDigit") ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "ConUnit" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2TargetRange" ) ) ) {

                                target.setAttribute( 'style', 'display:none;' );
                            }
                        }
                    } else {
                        // let targetEle = $( `input[ aria-label = ${ locale.getLocalizedText( localeText, "TargetValue" ) } ]` );
                        // let lslEle = $( `input[ aria-label = LSL ]` );
                        // let uslgetEle = $( `input[ aria-label = USL ]` );
                        
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "TargetValue" ) ) || target.innerText.includes( "LSL" ) || target.innerText.includes( "USL" ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "InitValue" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "ConDigit" ) ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "ConUnit" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2TargetRange" ) ) ) {
                                    
                                target.setAttribute( 'style', 'display:"";' );
                            }
                        }
                        data.a2TargetRange.hasLov = false;
                        for( const target of targetClass ) {
                            if( data.a2TargetRange.dbValue ) {
                                if( !data.a2TargetRange.dbValue.includes( "USL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) ) {
                                        uwPropertyService.setValue( data.a2Usl, "" );
                                        target.setAttribute( 'style', 'display:none;' );
                                    } else {
                                        target.setAttribute( 'style', 'display:;' );
                                    }
                                } else if( !data.a2TargetRange.dbValue.includes( "LSL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                        uwPropertyService.setValue( data.a2Lsl, "" );
                                        target.setAttribute( 'style', 'display:none;' );
                                    } else {
                                        target.setAttribute( 'style', 'display:;' );
                                    }
                                } else if( data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                        uwPropertyService.setValue( data.a2Usl, "" );
                                        uwPropertyService.setValue( data.a2Lsl, "" );
                                        target.setAttribute( 'style', 'display:none;' );
                                    }
                                } else if( data.a2TargetRange.dbValue.includes( "LSL" ) && data.a2TargetRange.dbValue.includes( "USL" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                        target.setAttribute( 'style', 'display:;' );
                                    }
                                }
                            }
                        }
                        setTimeout( () => {
                            data.a2TargetRange.isRequired = true;
                            data.a2TargetRange.hasLov = true;
                        }, 100 )
                    }

                    if( data.objCreateInfo.createType == "A2QPartCheckItemRuntime" || data.objCreateInfo.createType == "A2QPartIPCheckItemRuntime" ) {
                        //await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2OrgCode" );

                        await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "a2InspectionObject" );
                        const a2InspectionObject = AwcObjectUtil.getObject( ctx.xrtSummaryContextObject.props.a2InspectionObject.dbValue );
                        await AwcObjectUtil.getProperty( a2InspectionObject, "a2OrgCode" );

                        updateDynamicLOV(data.a2OrgCode,a2InspectionObject.props.a2OrgCode,false);
                        //uwPropertyService.setIsEnabled( data.object_string, false );
    
                    }


                } else if( data.objCreateInfo.createType.includes( 'Period' ) ) {

                    if( ctx.xrtSummaryContextObject.type == "A2QPartIPItemRevision" || data.objCreateInfo.createType == "A2QPartInsPeriod" ) {
                        if( data.a2OrgCode && data.a2PartString && data.a2SupplierString  && data.a2InspectionPlan ) {
        
                            await AwcObjectUtil.getProperties(ctx.selected, ["a2OrgCode","a2PartString","a2SupplierString","item_id"], true);
                            let response = await AwcQueryUtil.executeSavedQuery("_Inspection_getSupplierItem", ["A2QItemId"], [ctx.selected.props.a2SupplierString.dbValue]);
                            let supplierObj;
                            if ( !response ) {
                                // 협력사 검색결과 없음
                                return;
                            } 
                            supplierObj = response[0];
        
        
                            await AwcObjectUtil.getProperties(supplierObj, ["a2SupplierType"], true);
        
                            if( supplierObj.props.a2SupplierType.dbValues[0] == "NA" ){
                                updateDynamicLOV(data.a2OrgCode, ctx.selected.props.a2OrgCode, false);
                                updateDynamicLOV(data.a2PartString, ctx.selected.props.a2PartString, false);
                                updateDynamicLOV(data.a2InspectionPlan, ctx.selected.props.item_id, false);
        
                            }
                            else{
                                updateDynamicLOV(data.a2OrgCode, ctx.selected.props.a2OrgCode, false);
                                updateDynamicLOV(data.a2PartString, ctx.selected.props.a2PartString, false);
                                updateDynamicLOV(data.a2SupplierString, ctx.selected.props.a2SupplierString, false);
                                updateDynamicLOV(data.a2InspectionPlan, ctx.selected.props.item_id, false);
                            }
                        }
                    }

                    if( data.a2ConversionRule.dbValues[0] == "I-N" ) {
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "IPRule" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "PNRule" ) ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "InspPeriod" ) ) ) {

                                target.setAttribute( 'style', 'display:none;' );
                            } else if( target.innerText.includes( locale.getLocalizedText( localeText, "INRule" ) ) ) {
                                target.setAttribute( 'style', 'display:;' );
                            }
                        }
                    } else if( data.a2ConversionRule.dbValues[0] == "I-P-N" ) {
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "INRule" ) ) ) {
                                target.setAttribute( 'style', 'display:none;' );
                            } else if( target.innerText.includes( locale.getLocalizedText( localeText, "IPRule" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "PNRule" ) ) ||
                                       target.innerText.includes( locale.getLocalizedText( localeText, "InspPeriod" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "InspCount" ) ) ) {
                                target.setAttribute( 'style', 'display:;' );
                            }
                        }
                    } else if( data.a2ConversionRule.dbValues[0] == "I-P" ) {
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "INRule" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "PNRule" ) ) ) {
                                target.setAttribute( 'style', 'display:none;' );
                            } else if( target.innerText.includes( locale.getLocalizedText( localeText, "IPRule" ) ) ) {
                                target.setAttribute( 'style', 'display:;' );
                            }
                        }
                    }
                } else if( data.objCreateInfo.createType == "A2QSetTargetRangeRuntime" ) {
                    if( evtData ) {
                        for( const target of targetClass ) {
                            if( !data.a2TargetRange.dbValue.includes( "USL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) ) {
                                    uwPropertyService.setValue( data.a2Usl, "" );
                                    target.setAttribute( 'style', 'display:none;' );
                                } else {
                                    target.setAttribute( 'style', 'display:;' );
                                }
                            } else if( !data.a2TargetRange.dbValue.includes( "LSL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                    uwPropertyService.setValue( data.a2Lsl, "" );
                                    target.setAttribute( 'style', 'display:none;' );
                                } else {
                                    target.setAttribute( 'style', 'display:;' );
                                }
                            } else if( data.a2TargetRange.dbValue.includes( "Target" ) && !data.a2TargetRange.dbValue.includes( "LSL" ) && !data.a2TargetRange.dbValue.includes( "USL" )) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                    target.setAttribute( 'style', 'display:none;' );
                                    uwPropertyService.setValue( data.a2Usl, "" );
                                    uwPropertyService.setValue( data.a2Lsl, "" );
                                }
                            } else if( data.a2TargetRange.dbValue.includes( "LSL" ) && data.a2TargetRange.dbValue.includes( "USL" ) ) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                    target.setAttribute( 'style', 'display:;' );
                                }
                            }
                        }
                    } else {
                        let setProps = [ "a2Lsl", "a2Usl", "a2TargetValue", "a2TargetRange" ];
                        await AwcObjectUtil.getProperties( ctx.selected, setProps );
                        for( const prop of setProps ) {
                            uwPropertyService.setValue( data[ prop ], String( ctx.selected.props[ prop ].dbValue ) );
                            uwPropertyService.setDisplayValue( data[ prop ], [ String( ctx.selected.props[ prop ].dbValue ) ] );
                        }
                        for( const target of targetClass ) {
                            if( !ctx.selected.props.a2TargetRange.dbValue.includes( "USL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) ) {
                                    uwPropertyService.setValue( data.a2Usl, "" );
                                    target.setAttribute( 'style', 'display:none;' );
                                } else {
                                    target.setAttribute( 'style', 'display:;' );
                                }
                            } else if( !ctx.selected.props.a2TargetRange.dbValue.includes( "LSL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                    uwPropertyService.setValue( data.a2Lsl, "" );
                                    target.setAttribute( 'style', 'display:none;' );
                                } else {
                                    target.setAttribute( 'style', 'display:;' );
                                }
                            } else if( ctx.selected.props.a2TargetRange.dbValue.includes( "Target" ) ) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                    uwPropertyService.setValue( data.a2Usl, "" );
                                    uwPropertyService.setValue( data.a2Lsl, "" );
                                    target.setAttribute( 'style', 'display:none;' );
                                }
                            } else if( ctx.selected.props.a2TargetRange.dbValue.includes( "LSL" ) && ctx.selected.props.a2TargetRange.dbValue.includes( "USL" ) ) {
                                if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                    target.setAttribute( 'style', 'display:;' );
                                }
                            }
                        }
                    }
                }

                if( data.a2ProdGroupMasterObject || data.a2PartGroupMasterObject ) {
                    $(".aw-layout-flexColumnContainer.aw-sidenav-layoutContainer.aw-sidenav-standard.aw-sidenav-vertical-full.aw-sidenav-float.aw-sidenav-transition.aw-sidenav-leftBackground.aw-sidenav-float-right.aw-sidenav-expand")[0].style.width = "600px";
                }
            }
        }
    })
}

export const InsTreeCreateUnload = () => {
    $(".aw-layout-flexColumnContainer.aw-sidenav-layoutContainer.aw-sidenav-standard.aw-sidenav-vertical-full.aw-sidenav-float.aw-sidenav-transition.aw-sidenav-leftBackground.aw-sidenav-float-right.aw-sidenav-expand")[0].style.width = "";
}

const updateDynamicLOV = function( targetProperty, sourceProperty, isEnabled ) {

    if(sourceProperty.dbValues[0]){
        targetProperty.uiValue = sourceProperty.dbValues[0];
        targetProperty.dbValue = sourceProperty.uiValues[0];
    
    }else{
        targetProperty.uiValue = sourceProperty.uiValue;
        targetProperty.dbValue = sourceProperty.dbValue;
    }

    targetProperty.valueUpdated = true;
    uwPropertyService.updateViewModelProperty( targetProperty );
    uwPropertyService.setIsEnabled( targetProperty, isEnabled );
};

export default exports = {
    InsTreeCreateLoad,
    InsTreeCreateUnload
};
app.factory('A2InspectionTemplateService', () => exports);
