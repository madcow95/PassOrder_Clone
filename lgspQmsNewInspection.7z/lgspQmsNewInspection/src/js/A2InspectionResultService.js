import app from 'app';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcObjectUtil from 'js/AwcObjectUtil';
import AwcQueryUtil from 'js/AwcQueryUtil';
import Grid from 'tui-grid';
import SelectBox from '@toast-ui/select-box'; 
import ngModule from 'angular';
import viewModelSvc from 'js/viewModelService';
import $ from 'jquery';
import _ from 'lodash';

import appCtxService from 'js/appCtxService';
import UploadService from 'js/UploadService';
import soaService from 'soa/kernel/soaService';
import AwcNotificationUtil from 'js/AwcNotificiationUtil'
import viewModelService from 'js/viewModelService';
import uwPropertyService from 'js/uwPropertyService';
import viewModelObjectService from 'js/viewModelObjectService'
import 'tui-grid/dist/tui-grid.css';
import locale from 'js/AwcLocalizationUtil';
let localeText = "lgspQmsNewInspectionMessages";

//import '@toast-ui/select-box/dist/toastui-select-box.css'

let exports = {};
let SERIAL_GRID_INSTANCE = undefined;
let SAMPLE_GRID_INSTANCE = undefined;
let BAD_CODE_LIST_VALUES = undefined;
let CURRENT_MODE = undefined;
let INSP_REQ = undefined;  //클래스 선언을 위한 전역번수
let FLAG_CHANGE = false;
let EDIT_MODE = true;
let MAX_SAMPLE_SIZE = 20;
let VARIABLE_MAX_SAMPLE_SIZE = 100000;

const TYPE_NAMES = {
    prod: {
        inspectionResult: "A2QProdInspectionResult",
        iRItemRevision: "A2QProdIRItemRevision",
        iPCheckItem: "A2QProdIPCheckItem",
        searchQuery: "_Inspection_getInspectionResults",
        spcSearchQuery: "_Inspection_getInspectionResultFromA2BasedOnId",
    },
    part: {
        inspectionResult: "A2QPartInspectionResult",
        iRItemRevision: "A2QPartIRItemRevision",
        iPCheckItem: "A2QPartIPCheckItem",
        searchQuery: "_Inspection_getPartInspectionResults",
        spcSearchQuery: "_Inspection_getPartInspectionResultFromA2BasedOnId",
    },
    prodPTR: {
        inspectionResult: "A2QProdPTResult",
        iRItemRevision: "A2QProdPTRItemRevision",
        iPCheckItem: "A2QProdPTPCheckItem",
        searchQuery: "_Inspection_getProdPTResults",
        spcSearchQuery: "_Inspection_getProdPTResultFromA2BasedOnId",
    },
    partPTR: {
        inspectionResult: "A2QPartPTResult",
        iRItemRevision: "A2QPartPTRItemRevision",
        iPCheckItem: "A2QPartPTPCheckItem",
        searchQuery: "_Inspection_getPartPTResults",
        spcSearchQuery: "_Inspection_getPartPTResultFromA2BasedOnId",
    }
};
const MEASURE_MACHINE_LOV = {};

const IMAN_FILE_LOV = [{
    text: '',
    value: ''
}]

const RESULT = {
    LOV: [],
    S : "OK",
    F : "NG",
    N : "N/A",
    P : "In Progress",
};
const INPUT_TYPES = [];
const JUDG = {
    LOV: [],
    OK: "OK",
    NG: "NG",
    NA: "N/A",
};
let BED_CODES = [{
    text: '',
    value: '',
}];
const STRING = {
    EMPTY: '',
    BLOCK: '/',
};
const PRINCIPAL = [];
const SUPPLIER_STATUS = [];
const EXCEL_COLUMNS = [
    'inspItem',
    'inspName',
    'spec',
    'insInputType',
    'sampleSize',
    // 'image',
    'failureQty',
    'a2TargetRange',
    'a2TargetValue',
    'lsl',
    'usl',
    'principal',
    'sample1',
    'sample2',
    'sample3',
    'sample4',
    'sample5',
    'sample6',
    'sample7',
    'sample8',
    'sample9',
    'sample10',
    'sample11',
    'sample12',
    'sample13',
    'sample14',
    'sample15',
    'sample16',
    'sample17',
    'sample18',
    'sample19',
    'sample20',
    // 'description',
    // 'result',
    // 'SPC',
    // 'NGQty',
    // 'a2DefectClass1Object',
    // 'a2DefectClass2Object',
    // 'a2DefectClass3Object',
    // 'file',
    // 'sampleMethod',
    // 'insInputType',
    // 'ac',
    // 're',
];

class InputTypeRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const found = INPUT_TYPES.find(( i => i.value === props.value))
        if (found) {
            this.el.innerText = found.displayName;
        }
    }
}

class measureMachineRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        let name = '';
        const i = MEASURE_MACHINE_LOV[SAMPLE_GRID_INSTANCE.getRow(props.rowKey).uid].find(i => i.value == props.value);
        if (i) { name = i.text; }
        this.el.innerText = name;
    }
}
class CTQMGMTRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const row = props.grid.getRow(props.rowKey);
        if (parseInt(row.isCTQ)) {
            this.el.innerText = `${row.CTQMgmtMethod}: ${props.value}`;
        }
    }
}
class ResultRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const selected = JUDG.LOV.find(i => i.value === props.value);
        if (selected) {
            this.el.classList.remove('result-color-ok');
            this.el.classList.remove('result-color-no');
            if (selected.value === JUDG.OK) this.el.classList.add('result-color-ok');
            if (selected.value === JUDG.NG) this.el.classList.add('result-color-no');
            this.el.innerText = selected.displayName;
        }
    }
}

class principalRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const found = PRINCIPAL.find(( i => i.value === props.value))
        if (found) {
            this.el.innerText = found.displayName;
        }
    }
}

class supplierStatusRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const found = SUPPLIER_STATUS.find(( i => i.value === props.value))
        if (found) {
            this.el.innerText = found.displayName;
        }
    }
}

class NGCodeRenderer {
    constructor( props ) {
        const row = props.grid.getRow( props.rowKey );
        const el = document.createElement( 'div' );
        el.classList.add('tui-grid-cell-content');
        let defectCheck = CURRENT_MODE.includes( "part" ) ? "a2DefectClass2Object" : "a2DefectClass3Object";
        if( EDIT_MODE && row.principal !== "OutSide" ) {
            let dateVm = {};
            var scope = ngModule.element( document.getElementById( "A2InspectionResult" ).children[0] ).scope();
            if( scope ) {
                dateVm = viewModelSvc.getViewModel( scope, true );
            }

            const elA = document.createElement( 'a' );
            
            if( row[ defectCheck ] ) {
                let defectCodeObj = AwcObjectUtil.getObject( row[ defectCheck ] );
                AwcObjectUtil.getProperty( defectCodeObj, "object_name" );
                const interval = setInterval( () => {
                    if( defectCodeObj.props.object_name ) {
                        clearInterval( interval );
                        if( CURRENT_MODE == "part" || CURRENT_MODE == "partPTR" ) {
                            elA.innerText = row.a2DefectClass2Object ? defectCodeObj.props.object_name.dbValues[0] : locale.getLocalizedText( localeText, "NGCode" );
                        } else if( CURRENT_MODE == "prod" || CURRENT_MODE == "prodPTR" ) {
                            elA.innerText = row.a2DefectClass3Object ? defectCodeObj.props.object_name.dbValues[0] : locale.getLocalizedText( localeText, "NGCode" );
                        }
                    }
                } );
            } else {
                elA.innerText = locale.getLocalizedText( localeText, "NGCode" );
            }
            elA.addEventListener( 'click', ( evt ) => {
                /**
                 * part,partPTR / prod,prodPTR일때 보이는 LOV개수 다르게 변경
                 */
                uwPropertyService.setValue( dateVm.a2ObjectName, [ row.inspName ] );
                appCtxService.registerCtx( "selectedItem", row );
                appCtxService.registerCtx( "selectedEle", elA );
                resultModule.setSelectedItem( row.inspName );
                $("#NGCodePanel").show();
                $("#rightVerticalSeparator").show();
                if( elA.innerText !== locale.getLocalizedText( localeText, "NGCode" ) ) {
                    document.getElementById( "resetBtn" ).setAttribute( "style", "display: ;" );
                }
                SAMPLE_GRID_INSTANCE.refreshLayout();
                SERIAL_GRID_INSTANCE.refreshLayout();
            } );

            el.append( elA );
        } else {
            const elB = document.createElement( 'p' );
            let defectCodeObj = AwcObjectUtil.getObject( row[ defectCheck ] );
            if( row[ defectCheck ] ) {
                AwcObjectUtil.getProperty( defectCodeObj, "object_name" );
                const interval = setInterval( () => {
                    if( defectCodeObj.props.object_name ) {
                        clearInterval( interval );
                        if(CURRENT_MODE == "part" || CURRENT_MODE == "partPTR") {
                            elB.innerText = row.a2DefectClass2Object ? defectCodeObj.props.object_name.dbValues[0] : "";
                        } else {
                            elB.innerText = row.a2DefectClass3Object ? defectCodeObj.props.object_name.dbValues[0] : "";
                        }
                        el.append( elB );
                    }
                } );
            }
        }
        this.el = el;
        this.render(props);
    }
    getElement() {
        if (this.el) return this.el;
    }
    render(props) {
    }
}

class SPCRenderer {
    constructor(props) {
        const row = props.grid.getRow(props.rowKey);

        const CTQLotCount = parseInt(row.CTQLotCount);
        const CTQMgmtMethod = row.CTQMgmtMethod;
        const CTQMgmtSpec = parseFloat(row.CTQMgmtSpec);
        const isCTQ = row.isCTQ;
        const LOTNo = row.LOTNo;

        if (isCTQ === "1") {
            const el = document.createElement('div');
            const elA = document.createElement('a');
            el.classList.add('tui-grid-cell-content');
            elA.innerText = locale.getLocalizedText(localeText, "inspResultSPCJudg");
            elA.addEventListener('click', async (event) => {
                const sampleValues = [];
                const sampleSize = parseInt(row.sampleSize) <= MAX_SAMPLE_SIZE ? parseInt(row.sampleSize) : MAX_SAMPLE_SIZE;
                for (let i=1; i<=sampleSize; i++) {
                    sampleValues.push(SAMPLE_GRID_INSTANCE.getValue(props.rowKey, `sample${i}`));
                } 

                if (sampleValues.find(i => !i) !== undefined) {
                    // return alert('샘플 측정값을 모두 입력해주세요.');
                    AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultSaveSuccess"));
                    return false;
                }

                const inputData = await SPCModule.getInputData({basedOnId: row.basedOnId, CTQLotCount});
                if (inputData.length < 1) {
                    return undefined;
                }
                const joinedData = await SPCModule.joinSamples({inputData, sampleValues, LOTNo});
                const spcData = await SPCModule.getSPCData({inputData: joinedData});

                if (spcData.length) {
                    spcData[0].statisticsData
                    // CL: "3.0"
                    // Cp: "0.194"
                    // Cpk: "0.0"
                    // LCL: "0.6928000000000001"
                    // LSL: "3.0"
                    // M: "4.0"
                    // PL: "500000"
                    // PT: "622414.8"
                    // PU: "122414.8"
                    // Pp: "0.23094010767585024"
                    // Ppk: "0.0"
                    // UCL: "5.3072"
                    // USL: "5.0"
                    // Zlt: "0.693"
                    // Zst: "0.582"
                    // p-value: "0.025"

                    let v = 0;
                    let judg = JUDG.NG;
                    if (['Cp', 'Cpk', 'Zlt', 'Zst'].includes(CTQMgmtMethod)) {

                        if ('Cp' === CTQMgmtMethod) {
                            v = parseFloat(spcData[0].statisticsData.CL);
                        } else if ('Cpk' === CTQMgmtMethod) {
                            v = parseFloat(spcData[0].statisticsData.Cpk);
                        } else if ('Zlt' === CTQMgmtMethod) {
                            v = parseFloat(spcData[0].statisticsData.Zlt);
                        } else if ('Zst' === CTQMgmtMethod) {
                            v = parseFloat(spcData[0].statisticsData.Zst);
                        }

                        if (CTQMgmtSpec <= v) {
                            judg = JUDG.OK;
                        }
                    }
                    // SAMPLE_GRID_INSTANCE.setValue(props.rowKey, 'spcValue', `${CTQMgmtMethod}: ${String(parseFloat(v).toFixed(3))}`, false)


                    AwcNotificationUtil.show("INFO", `[${judg}] ${CTQMgmtMethod}: ${String(parseFloat(v).toFixed(3))} `);
                    SAMPLE_GRID_INSTANCE.setValue(props.rowKey, 'spcResult', `${String(parseFloat(v).toFixed(3))}`, false)
                    SAMPLE_GRID_INSTANCE.setValue(props.rowKey, 'result', judg, false)
                }
            });
            el.append(elA)
            this.el = el;
        } else {
            this.el = document.createElement('div');
        }
        this.render(props);
    }
    getElement() {
        if (this.el) return this.el;
    }
    render(props) {
    }
}
class SelectBoxEditor {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        el.classList.add('judgment');
        el.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                props.grid.blur();
                props.grid.focus(props.rowKey, props.columnInfo.name, false);
            }
        });
        let selectedMM = MEASURE_MACHINE_LOV[SAMPLE_GRID_INSTANCE.getRow(props.rowKey).uid];
        this.selectBox = new SelectBox(el, {
            autofocus: true,
            data: (() => {
                let filter = props.columnInfo.name.includes( 'MeasureMachine' ) ? selectedMM : props.columnInfo.editor.options.listItems;
                return filter.map((i) => {
                    return {
                        label: i.text,
                        value: i.value,
                        selected: i.value === props.value ? true : false,
                    }
                })
            })(),
        });
        this.selectBox.on('close', ev => {
            setTimeout(() => {
                props.grid.blur();
                props.grid.focus(props.rowKey, props.columnInfo.name, false);
            }, 0);
        });
        this.el = el;
    }
    getElement() {
        return this.el;
    }
    getValue() {
        return this.selectBox.getSelectedItem().value;
    }
    mounted() {
        this.selectBox.focus();
        this.selectBox.open();
    }
}
class SampleValueRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const selected = JUDG.LOV.find(i => i.value === props.value);
        if (selected) {
            this.el.innerText = selected.displayName;
        } else {
            this.el.innerText = props.value;
        }
    }
}
class SampleValueEditor {
    constructor(props) {
        const insInputType = props.grid.store.data.rawData[props.rowKey].insInputType;

        if (props.value === STRING.BLOCK) {
            const el = document.createElement('div');
            el.classList.add('tui-grid-cell-content');
            el.style = 'text-align: right;';
            el.innerText = String(props.value);

            this.el = el;

        // 입력 유형이 판정이고 컬럼이 샘플이면 
        } else if (/^sample\d+$/.test(props.columnInfo.name) && insInputType === 'Judgment') {
            const el = document.createElement('div');
            el.classList.add('tui-grid-cell-content');
            el.classList.add('judgment');
            el.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const columnName = 'sample' + (parseInt(props.columnInfo.name.match(/\d+/)[0]) + 1);
                    setTimeout(() => {
                        props.grid.startEditing(props.rowKey, columnName);
                    });
                }
            });
            this.selectBox = new SelectBox(el, {
                autofocus: true,
                data: (() => {
                    return JUDG.LOV.map((i) => {
                        return {
                            label: i.displayName,
                            value: i.value,
                            selected: (i.value === props.value) ? true : false,
                        }
                    })
                })(),
            });
            this.selectBox.on('close', ev => {
                setTimeout(() => {
                    props.grid.blur();
                    props.grid.focus(props.rowKey, props.columnInfo.name, false);
                }, 0);
            });
            this.el = el;
        } else {
            const el = document.createElement('input');
            const row = props.grid.getRow(props.rowKey);
            const digit = parseInt(row.a2ContinousDigit);

            el.type = 'number';
            // el.setAttribute('min', 1);
            // el.setAttribute('max', 20);
            // el.setAttribute('step', "0.1");
            el.value = String(props.value);
            el.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    const columnName = 'sample' + (parseInt(props.columnInfo.name.match(/\d+/)[0]) + 1);
                    setTimeout(() => {
                        props.grid.startEditing(props.rowKey, columnName);
                    }, 10);
                } else if (/\d/g.test(e.key)) {
                    const splitValue = e.target.value.split('.')
                    if (splitValue.length > 1 && splitValue[1].length >= digit) {
                        e.preventDefault();
                    }
                }
            })
            this.el = el;
        }
    }
    getElement() {
        return this.el;
    }
    getValue() {
        if (this.el.tagName === 'INPUT') {
            return this.el.value;
        } else if (this.selectBox) {
            return this.selectBox.getSelectedItem().value;
        } else {
            return STRING.BLOCK;
        }
    }
    mounted() {
        if (this.el.tagName === 'INPUT') {
            this.el.select();
        } else if (this.selectBox) {
            // this.selectBox.select(this.selectBox.getSelectedItem().value);
            this.selectBox.focus();
            this.selectBox.open();
        }
    }
}

class NumberEditor {
    constructor(props) {
        const el = document.createElement('input');
        el.type = 'number';
        el.setAttribute('min', 0);

        let row = SAMPLE_GRID_INSTANCE.getRow(props.rowKey);
        let inputType = row.insInputType;
        let sampleMethod = row.sampleMethod;
        if(props.columnInfo.name == 'failureQty' && inputType == 'Descrete'){
            let sampleSize = parseFloat(row.sampleSize);
            el.setAttribute('max', sampleSize);
        }

        if(props.columnInfo.name == 'sampleSize' && sampleMethod === 'Variable'){
            el.setAttribute('max', VARIABLE_MAX_SAMPLE_SIZE);
        }

        el.value = String(props.value);
        el.addEventListener('keydown', (e) => {
            e = (e) ? e : window.event;

            if (['-', '+'].includes((e.key) ? e.key : '') || [189, 187, 109, 107].includes((e.which) ? e.which : e.keyCode)) {
                return e.preventDefault();
            }
        });
        el.addEventListener('paste', (e) => {
            e = (e) ? e : window.event;
            const clipboardData = e.clipboardData || window.clipboardData;
            const pastedData = clipboardData.getData('Text');

            if (!/^\d+$/.test(pastedData)) {
                e.preventDefault();
            }
        });
        this.el = el;
    }
    getElement() {
        return this.el;
    }
    getValue() {
        if (this.el.value.length < 1) {
            return "0";
        } else {
            return parseInt(this.el.value);
        }
    }
    mounted() {
        this.el.select();
    }
}
class FilesEditor {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        el.classList.add('judgment');
        this.props = props;
        this.el = el;
    }
    getElement() {
        return this.el;
    }
    getValue() {
        return this.props.value;
        // return '';
        // return this.selectBox.getSelectedItem().value;
    }
    async mounted() {
        const props = this.props;
        const el = this.el;

        const uids = [];
        for (const index in props.value.uiValues) {
            uids.push(props.value.dbValues[index]);
        }

        const downloadItems = [];
        if (uids.length) {
            let fileItems = await AwcObjectUtil.loadObjects(uids);

            if (fileItems.hasOwnProperty('uid')) {
                const tmp = {};
                tmp[fileItems.uid] = fileItems;
                fileItems = tmp;
            }

            for (const i of Object.values(fileItems)) {
                if (AwcObjectUtil.instanceOf(i, 'Dataset')) {
                    downloadItems.push({
                        label: `+ ${i.props.object_name.dbValues[0]}`,
                        value: `download:${i.uid}`,
                        date: i.props.creation_date.dbValues[0],
                        type: i.type,
                    });
                }
            }
            downloadItems.sort((a,b) => a.date > b.date ? 1 : -1);
        }
        const removeItems = JSON.parse(JSON.stringify(downloadItems));
        removeItems.map((i) => {
            i.label = i.label.replace('+ ', '- ');
            i.value = i.value.replace('download:', 'remove:')
            return i;
        })
        
        let items = [ {
            label: locale.getLocalizedText("lgspQmsInspectionMessages", "AttachFiles"),
            value: '',
        }, {
            label: locale.getLocalizedText("lgspQmsInspectionMessages", "Add"),
            value: 'add',
        }, {
            label: locale.getLocalizedText("lgspQmsInspectionMessages", "Download"),
            data: downloadItems,
        }, {
            label: locale.getLocalizedText("lgspQmsInspectionMessages", "Delete"),
            data: removeItems,
        }];

        if (!EDIT_MODE || SAMPLE_GRID_INSTANCE.getRow(this.props.rowKey).principal == "OutSide") {
            items = [ {
                label: locale.getLocalizedText("lgspQmsInspectionMessages", "AttachFiles"),
                value: '',
            }, {
                label: locale.getLocalizedText("lgspQmsInspectionMessages", "Download"),
                data: downloadItems,
            }];
        }

        this.selectBox = new SelectBox(el, {
            data: items,
        });


        this.selectBox.on('close', ev => {
            setTimeout(() => {
                props.grid.blur();
                props.grid.focus(props.rowKey, props.columnInfo.name, false);

                const row = props.grid.getRow(props.rowKey);

                if (this.selectBox.getSelectedItem().value === '') {
                    // 
                } else if (this.selectBox.getSelectedItem().value === 'add') {
                    const inspectionResult = AwcObjectUtil.getObject(row.uid);
                    UploadService.uploadFileToDataset().then( (dataset) => {
                        const filename = dataset.props.object_name.dbValues[0];
                        AwcObjectUtil.createRelation("TC_Attaches", inspectionResult, dataset).then( (payload) => {

                            const datasetUid = dataset.uid; 
                            const clone = { ...props.value };
                            clone.uiValues.push(filename);
                            clone.dbValues.push(datasetUid);
                            props.grid.setValue(props.rowKey, props.columnInfo.name, clone);

                            AwcNotificationUtil.show("INFO", locale.getLocalizedText(localeText, "uploadComp"));
                            //refresh table once upload completed
                            // props.grid.resetData(props.grid.getData()); 
                        }).catch( () => {
                            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "uploadFail"));
                        })
                    })
                // } else if (this.selectBox.getSelectedItem().value) {
                } else if (this.selectBox.getSelectedItem().value) {
                    const split_value = this.selectBox.getSelectedItem().value.split(':');
                    const mode = split_value[0];
                    const datasetUid = split_value[1];
                    // const inspectionResult = AwcObjectUtil.getObject(row.uid);

                    if (mode === 'download') {
                        AwcObjectUtil.loadObjects(datasetUid).then((res) => {
                            if (res.hasOwnProperty('uid')) {
                                res = [res];
                            }
                            const dataset = Object.values(res);

                            const file = dataset[0];
                            if (file) {
                                soaService.post( 'Internal-AWS2-2020-05-FileMgmt', 'getFileNamesWithTicketInfo', {
                                    "businessObjectsIn": [
                                        {
                                            "uid": file.uid,
                                            "type": file.type
                                        }
                                    ]
                                }).then( (res) => {
                                    var link = document.createElement("a");
                                    link.download = res.output[0].fileName;
                                    link.href = document.location.origin + "/fms/fmsdownload/" + res.output[0].fileName + "?ticket=" + res.output[0].fileTicket;
                                    document.body.appendChild(link);
                                    link.click();
                                    document.body.removeChild(link);
                                });

                            }
                        });
                    } else if (mode === 'remove') {
                        AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultWantDelete"), ['YES', 'NO'], [
                            async () => {
                                _deleteRelation( datasetUid, row.uid );
                                const clone = { ...props.value };
                                const index = clone.dbValues.indexOf(datasetUid);
                                clone.dbValues.splice(index,1);
                                clone.uiValues.splice(index,1);
                                props.grid.setValue(props.rowKey, props.columnInfo.name, clone);
                            },
                            async (payload) => {
                                // 
                            }
                        ]);
                    }
                }
            }, 0);
        });


        this.selectBox.focus();
        this.selectBox.open();
    }
}

let _deleteRelation = ( fileUid, resultUid ) => {
    let delFile = AwcObjectUtil.getObject( fileUid );
    let inspectionResult = AwcObjectUtil.getObject( resultUid );
    let delRelInput = {
        input:
            [{
                relationType: "TC_Attaches",
                primaryObject: inspectionResult,
                secondaryObject: delFile,
                userData: { uid: 'AAAAAAAAAAAAAA', type: 'unknownType' }
            }]
    }
    soaService.post( 'Core-2006-03-DataManagement', 'deleteRelations', delRelInput ).then( () => {
        soaService.post( 'Core-2006-03-DataManagement', 'deleteObjects', { objects: [ delFile ] } );
    } );
}

class IMANFilesEditor {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        el.classList.add('judgment');
        this.props = props;
        this.el = el;
    }
    getElement() {
        return this.el;
    }
    getValue() {
        return this.props.value;
    }
    async mounted() {
        const props = this.props;
        const el = this.el;
        const uids = [];
        for (const uid of props.value) {
            uids.push(uid);
        }
        const downloadItems = [];
        if (uids.length) {
            let fileItems = await AwcObjectUtil.loadObjects(uids);

            if (fileItems.hasOwnProperty('uid')) {
                const tmp = {};
                tmp[fileItems.uid] = fileItems;
                fileItems = tmp;
            }
            for (const i of Object.values(fileItems)) {
                if (AwcObjectUtil.instanceOf(i, 'Dataset')) {
                    downloadItems.push({
                        label: `+ ${i.props.object_name.dbValues[0]}`,
                        value: `download:${i.uid}`,
                        date: i.props.creation_date.dbValues[0],
                        type: i.type,
                    });
                }
            }
            downloadItems.sort((a,b) => a.date > b.date ? 1 : -1);
        }
        
        const items = [ {
            label: locale.getLocalizedText("lgspQmsInspectionMessages", "AttachFiles"),
            value: '',
        }, {
            label: locale.getLocalizedText("lgspQmsInspectionMessages", "Download"),
            data: downloadItems,
        }];

        this.selectBox = new SelectBox(el, {
            data: items,
        });

        this.selectBox.on('close', ev => {
            setTimeout(() => {
                props.grid.blur();
                props.grid.focus(props.rowKey, props.columnInfo.name, false);

                const row = props.grid.getRow(props.rowKey);

                if (this.selectBox.getSelectedItem().value === '') {
                    //
                } else if (this.selectBox.getSelectedItem().value === 'add') {
                    const inspectionResult = AwcObjectUtil.getObject(row.uid);
                    UploadService.uploadFileToDataset().then( (dataset) => {

                        const filename = dataset.props.object_name.dbValues[0];
                        AwcObjectUtil.createRelation("IMAN_specification", inspectionResult, dataset).then( (payload) => {

                            const datasetUid = dataset.uid; 
                            const clone = { ...props.value };
                            clone.uiValues.push(filename);
                            clone.dbValues.push(datasetUid);
                            props.grid.setValue(props.rowKey, props.columnInfo.name, clone);

                            AwcNotificationUtil.show("INFO", locale.getLocalizedText(localeText, "uploadComp"));
                        }).catch( () => {
                            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "uploadFail"));
                        })
                    })
                } else if (this.selectBox.getSelectedItem().value) {
                    const split_value = this.selectBox.getSelectedItem().value.split(':');
                    const mode = split_value[0];
                    const datasetUid = split_value[1];

                    if (mode === 'download') {
                        AwcObjectUtil.loadObjects(datasetUid).then((res) => {
                            if (res.hasOwnProperty('uid')) {
                                res = [res];
                            }
                            const dataset = Object.values(res);

                            const file = dataset[0];
                            if (file) {
                                soaService.post( 'Internal-AWS2-2020-05-FileMgmt', 'getFileNamesWithTicketInfo', {
                                    "businessObjectsIn": [
                                        {
                                            "uid": file.uid,
                                            "type": file.type
                                        }
                                    ]
                                }).then( (res) => {
                                    var link = document.createElement("a");
                                    link.download = res.output[0].fileName;
                                    link.href = document.location.origin + "/fms/fmsdownload/" + res.output[0].fileName + "?ticket=" + res.output[0].fileTicket;
                                    document.body.appendChild(link);
                                    link.click();
                                    document.body.removeChild(link);
                                });

                            }
                        });
                    }
                }
            }, 0);
        });
        this.selectBox.focus();
        this.selectBox.open();
    }
}

class FilesRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const count = props.value.dbValues.length;
        this.el.innerText = `${count}`;
    }
}
class IMANFilesRenderer {
    constructor(props) {
        const el = document.createElement('div');
        el.classList.add('tui-grid-cell-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        const count = props.value.length;
        this.el.innerText = `${locale.getLocalizedText( localeText, "attachFile" )} : ${count}`;
    }
}
class FileRenderer {
    constructor(props) {
        const row = props.grid.getRow(props.rowKey);
        const el = document.createElement('div');
        // el.classList.add('tui-grid-cell-content');
        el.classList.add('file-content');

        if (EDIT_MODE) {
            const elA = document.createElement('a');
            elA.innerText = locale.getLocalizedText(localeText, "inspResultFileRegistor");
            elA.addEventListener('click', async (event) => {
                setTimeout(() => {
                    props.grid.blur();
                    props.grid.focus(props.rowKey, props.columnInfo.name, false);
                }, 0);

                const inspectionResult = AwcObjectUtil.getObject(row.uid);
                UploadService.uploadFileToDataset().then( (dataset) => {
                    AwcObjectUtil.createRelation("TC_Attaches", inspectionResult, dataset).then( (payload) => {
                        const datasetUid = payload.ServiceData.updated[0];
                        props.grid.setValue(props.rowKey, props.columnInfo.name, datasetUid);

                        AwcNotificationUtil.show("INFO", locale.getLocalizedText(localeText, "uploadComp"));
                        //refresh table once upload completed
                        // props.grid.resetData(props.grid.getData()); 
                    }).catch( () => {
                        AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "uploadFail"));
                    })
                })
            });
            el.append(elA)
        }
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        if (props.value) {
            const btnClassName = 'button-download'
            this.el.querySelectorAll(`.${btnClassName}`).forEach(e => e.remove());

            const elD = document.createElement('a');
            elD.classList.add(btnClassName);
            elD.innerText = locale.getLocalizedText(localeText, "inspResultDownload");
            elD.addEventListener('click', async (event) => {
                setTimeout(() => {
                    props.grid.blur();
                    props.grid.focus(props.rowKey, props.columnInfo.name, false);
                }, 0);

                const row = props.grid.getRow(props.rowKey);
                const inspectionResult = AwcObjectUtil.getObject(row.uid);

                AwcObjectUtil.loadObjects(inspectionResult.props.TC_Attaches.dbValues).then((res) => {
                    if (res.hasOwnProperty('uid')) {
                        res = [res];
                    }

                    const dataset = Object.values(res);
                    const file = dataset.reduce((c, i) => {
                        if (!AwcObjectUtil.instanceOf(i, 'Dataset')) return c;
                        if (c === undefined) return i;
                        if (i.props.creation_date.dbValues[0] > c.props.creation_date.dbValues[0]) return i;
                        return c;
                    }, undefined);

                    if (file) {
                        soaService.post( 'Internal-AWS2-2020-05-FileMgmt', 'getFileNamesWithTicketInfo', {
                            "businessObjectsIn": [
                                {
                                    "uid": file.uid,
                                    "type": file.type
                                }
                            ]
                        }).then( (res) => {
                            var link = document.createElement("a");
                            link.download = res.output[0].fileName;
                            link.href = document.location.origin + "/fms/fmsdownload/" + res.output[0].fileName + "?ticket=" + res.output[0].fileTicket;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                        });

                    }
                });
            });
            this.el.append(elD);
        }
        
    }
}
class DownloadRenderer {
    constructor(props) {
        const row = props.grid.getRow(props.rowKey);
        const el = document.createElement('div');
        // el.classList.add('tui-grid-cell-content');
        el.classList.add('file-content');
        this.el = el;
        this.render(props);
    }
    getElement() {
        return this.el;
    }
    render(props) {
        if (props.value) {
            const btnClassName = 'button-download'
            this.el.querySelectorAll(`.${btnClassName}`).forEach(e => e.remove());
            const elD = document.createElement('a');
            elD.classList.add(btnClassName);
            elD.innerText = locale.getLocalizedText(localeText, "inspResultDownload");
            elD.addEventListener('click', async (event) => {
                setTimeout(() => {
                    props.grid.blur();
                    props.grid.focus(props.rowKey, props.columnInfo.name, false);
                }, 0);

                const row = props.grid.getRow(props.rowKey);
                const inspectionResult = AwcObjectUtil.getObject(row.uid);

                AwcObjectUtil.loadObjects(inspectionResult.props.IMAN_specification.dbValues).then((res) => {
                    if (res.hasOwnProperty('uid')) {
                        res = [res];
                    }

                    const dataset = Object.values(res);
                    const file = dataset.reduce((c, i) => {
                        if (!AwcObjectUtil.instanceOf(i, 'Dataset')) return c;
                        if (c === undefined) return i;
                        if (i.props.creation_date.dbValues[0] > c.props.creation_date.dbValues[0]) return i;
                        return c;
                    }, undefined);

                    if (file) {
                        soaService.post( 'Internal-AWS2-2020-05-FileMgmt', 'getFileNamesWithTicketInfo', {
                            "businessObjectsIn": [
                                {
                                    "uid": file.uid,
                                    "type": file.type
                                }
                            ]
                        }).then( (res) => {
                            var link = document.createElement("a");
                            link.download = res.output[0].fileName;
                            link.href = document.location.origin + "/fms/fmsdownload/" + res.output[0].fileName + "?ticket=" + res.output[0].fileTicket;
                            document.body.appendChild(link);
                            link.click();
                            document.body.removeChild(link);
                        });

                    }
                });
            });
            this.el.append(elD);
        }
    }
}
class ImageRenderer {
    constructor(props) {
        const el = document.createElement("div");
        this.el = el;
        this.render(props);
    }
  
    getElement() {
      return this.el;
    }
  
    render(props) {
        if( props.value && props.value.length > 0 ) {
            const objectUid = props.value.split("∥")[0];
            const windowURL = `${document.location.origin}#/com.siemens.splm.clientfx.tcui.xrt.showObject?uid=${objectUid}`;
            const imgURL = props.value.split("∥")[1];

            this.el.classList.add('thumbnail')
            this.el.addEventListener('click', () => {
                setTimeout(() => {
                    props.grid.blur();
                    props.grid.focus(props.rowKey, props.columnInfo.name, false);
                }, 0);
                window.open(windowURL, 'Thumbnail Viewer', 'toolbar=no, location=no, status=no, menubar=no, scrollbars=yes, resizable=yes, width=1000px, height=550px, top=25px left=120px');
            });
            this.el.style.backgroundImage = `url('${imgURL}')`;
        } 
    }
}
class InspectionRequest {
    //생성자
    constructor(modelObject) {
        this.modelObject = modelObject;
        this.itemId = modelObject.props.item_id.dbValues[0];
        this.revId = modelObject.props.item_revision_id.dbValues[0];
        this.name = modelObject.props.object_name.dbValues[0];
    }
    getName() {
        return this.name;
    }
    async getA2InspTypeName() {
        if( !this.modelObject.props.a2InspTypeName ) {
            await AwcObjectUtil.getProperty( this.modelObject, "a2InspTypeName", false );
        }
        return this.modelObject.props.a2InspTypeName.dbValues[0];
    }
    async getA2Status () {
        if( !this.modelObject.props.a2Status ) {
            await AwcObjectUtil.getProperty( this.modelObject, "a2Status", false );
        }
        return this.modelObject.props.a2Status.dbValues[0];
    }
    getModelObject() {
        return this.modelObject;
    }
    async getCheckSheets() {
        if(this.modelObject && !this.modelObject.props.contents) {
            await AwcObjectUtil.getProperty(this.modelObject, "contents", false);
        }
        let checkSheetObjs = await AwcObjectUtil.getObjects(this.modelObject.props.contents.dbValues);
        let checkSheets = [];
        await AwcObjectUtil.getProperty( checkSheetObjs, "a2IsDeleted" );
        for( const obj of checkSheetObjs ) {
            if( obj.props.a2IsDeleted.dbValues[0] == "YES" ) {
                continue;
            }
            checkSheets.push( obj );
        }
        return checkSheets;
    }

    async getAllInspectionResults() {
        let queryResults = await AwcQueryUtil.executeSavedQuery(TYPE_NAMES[CURRENT_MODE].searchQuery, ["A2Id", "A2RevId"], [this.itemId, this.revId]);
        if(!Array.isArray(queryResults)){
            queryResults = [queryResults];
        }
        return queryResults;
    }

    async getInspectionResultsBySheet(uid) {
        if(!uid) {
            return;
        }
        let resultArray = [];
        if(CURRENT_MODE == "prod") { 
            let queryResults = await AwcQueryUtil.executeSavedQuery(TYPE_NAMES[CURRENT_MODE].searchQuery, ["A2Id", "A2RevId"], [this.itemId, this.revId]);
            queryResults = await AwcObjectUtil.getThumbnailImageURL(queryResults);
            for (const queryResult of queryResults) {
                if( queryResult.props.a2CheckSheetObject.dbValues[0] == uid ) {
                    let vmo = viewModelObjectService.constructViewModelObjectFromModelObject(queryResult);
                    vmo.thumbnail = queryResult.thumbnail;
                    if(queryResult.thumbnail) {
                        vmo.thumbnail = queryResult.props.IMAN_reference.dbValues[0] + "∥" + vmo.thumbnail;
                    }
                    resultArray.push(vmo);
                }
            }
        } else if(CURRENT_MODE == "prodPTR") {
            let queryResults = await AwcQueryUtil.executeSavedQuery(TYPE_NAMES[CURRENT_MODE].searchQuery, ["A2Id", "A2RevId"], [this.itemId, this.revId]);
            queryResults = await AwcObjectUtil.getThumbnailImageURL(queryResults);
            for (const queryResult of queryResults) {
                if( queryResult.props.a2CheckSheetObject.dbValues[0] == uid ) {
                    let vmo = viewModelObjectService.constructViewModelObjectFromModelObject(queryResult);
                    vmo.thumbnail = queryResult.thumbnail;
                    if(queryResult.thumbnail) {
                        vmo.thumbnail = queryResult.props.IMAN_reference.dbValues[0] + "∥" + vmo.thumbnail;
                    }
                    resultArray.push(vmo);
                }
            }
        } else {
            //let queryResults = await AwcQueryUtil.executeSavedQuery(TYPE_NAMES[CURRENT_MODE].searchQuery, ["A2Id", "A2RevId"], [this.itemId, this.revId]);
            let sheet = await AwcObjectUtil.loadObjects(uid);
            let queryResults = [];
            for( const uid of sheet.props.contents.dbValues ) {
                queryResults.push( AwcObjectUtil.getObject( uid ) );
            }
            await AwcObjectUtil.getProperties(queryResults, ["object_name"], true);
            queryResults = await AwcObjectUtil.getThumbnailImageURL(queryResults);
            for (const queryResult of queryResults) {
                let vmo = viewModelObjectService.constructViewModelObjectFromModelObject(queryResult);
                vmo.thumbnail = queryResult.thumbnail;
                if(queryResult.thumbnail) {
                    vmo.thumbnail = queryResult.props.IMAN_reference.dbValues[0] + "∥" + vmo.thumbnail;
                }
                resultArray.push(vmo);
            }
        }
        return resultArray;
    }
}

// 그리드의 beforeCharge, afterChagne등 이벤트 발생시 사용하는 메서드 집합
const gridEvents = {
    //선택된 불량코드 찾아서 대표 불량 코드 리스트 설정
    // setBedCode: function({instance}) {
    //     const selectedBedCodes = [{
    //         propDisplayValue: "",
    //         propInternalValue: "",
    //     }];
    //     const values = instance.getColumnValues('failureCode');
    //     values.forEach(c => {
    //         if (undefined === selectedBedCodes.find(i => i.propInternalValue === c)) {
    //             const foundCode = BED_CODES.find((i) => i.value === c);
    //             if (foundCode) {
    //                 selectedBedCodes.push({
    //                     propDisplayValue: foundCode.text,
    //                     propInternalValue: foundCode.value,
    //                 });
    //             }
    //         }
    //     });
    //     BED_CODE_LIST_VALUES.dbValue = selectedBedCodes;
    // },
    // 샘플의 측정값 입력을 막거나 여는 메서드
    setBlockSampleColumns: function ({instance, value, rowKey}) {
        const v = parseInt(value);
        const row = instance.getRow(rowKey);
        const sampleKeys = Object.keys(row).filter(i => /^sample\d+$/.test(i));
        sampleKeys.forEach((i) => {
            const tmp = parseInt(i.match(/\d+/)[0]);

            if (tmp > v) {
                instance.setValue(rowKey, i, STRING.BLOCK, false);
            } else {
                if (row.insInputType === 'Descrete') {
                    instance.setValue(rowKey, i, STRING.BLOCK, false);
                } else if (row[i] === STRING.BLOCK) {
                    // - Continuous(연속) ==> 기존 측정
                    // - Judgment(판정)
                    // - Descrete(이산형)
                    let tmpValue = undefined;
                    if (row.insInputType === 'Continuous') tmpValue = row.coInitValue;
                    else if (row.insInputType === 'Judgment') tmpValue = row.judgInitValue;
                    instance.setValue(rowKey, i, tmpValue, false);
                }
            }
        });
    },
    setNGQtyColumn({instance, rowKey, value}) {
        let inputType = instance.store.data.rawData[ rowKey ].insInputType;
        let prevNGQty = parseInt( instance.store.data.rawData[ rowKey ].failureQty );
        let sampleSize = instance.store.data.rawData[ rowKey ].sampleSize;
        if( inputType === "Descrete" ) {
            value = value > sampleSize ? prevNGQty : value;
        }
        instance.setValue(rowKey, 'NGQty', value);
    },
    getVisibleMaxSampleColumnNumber({instance}) {
        const maxSampleCount = parseInt(instance.getData().reduce((c, r) => {
            if (r.insInputType === 'Descrete') return c;
            else if (parseInt(r.sampleSize) > parseInt(c)) return r.sampleSize;
            else return c;
        }, 0));
        return maxSampleCount;
    },
    // 샘플의 갯수에 따라 측정값 입력 컬럼을 show, hide 처리하는 메서드
    setVisibleSampleColumns({instance}) {
        const columns = instance.getColumns();
        // const maxSampleCount = parseInt(instance.getColumnValues('sampleSize').reduce( (c, v) => parseInt(v) > parseInt(c) ? v : c , 0));
        const maxSampleCount = this.getVisibleMaxSampleColumnNumber({instance});
        columns.forEach((i) => {
            const matched = i.name.match(/^sample(\d+)$/);
            if (matched) {
                if (maxSampleCount < parseInt(matched[1])) {
                    instance.hideColumn(i.name);
                } else {
                    instance.showColumn(i.name);
                }
            }
        });
    },
    // 샘플 측정값에 따라 불합격수를 입력하는 메서드
    setFalseCountColumnFromSampleColumn({instance, rowKey}) {
        const row = instance.getRow(rowKey);
        const sampleSize = parseInt( row.sampleSize );
        let sampleKeys = Object.keys(row).filter(i => /^sample\d+$/.test(i));
        sampleKeys = sampleKeys.splice( 0, sampleSize );
        const targetValue = parseFloat( row.a2TargetValue );
        const lsl = parseFloat(row.lsl);
        const usl = parseFloat(row.usl);
        let targetRange = row.a2TargetRange;
        if( row.principal === "OutSide" ) {
            return;
        }
        let NGQty = sampleKeys.reduce( ( index, key ) => {
            if (row.insInputType === 'Judgment') {
                var enteredValue = row[ key ];
                if ( enteredValue === JUDG.NG ) return index + 1;
                else  return index; 
            } else if ( row.insInputType === 'Continuous' ) {
                var enteredValue = parseFloat( row[ key ] );
                if( isNaN( enteredValue ) ) {
                    instance.setValue(rowKey, 'result', JUDG.NA, false);
                    return index;
                }
                targetRange = targetRange.replaceAll( " ", "" );
                switch( targetRange ) {
                    case "LSL<X"     : 
                        if( lsl >= enteredValue ) index++;
                        else index;
                        break;
                    case "LSL<X<USL" : 
                        if( lsl >= enteredValue ) index++;
                        else if( enteredValue >= usl ) index++;
                        else index;
                        break;
                    case "LSL<X≤USL" : 
                        if( lsl >= enteredValue ) index++;
                        else if( enteredValue > usl ) index++;
                        else index;
                        break;
                    case "X<USL"     : 
                        if( enteredValue >= usl ) index++;
                        else index;
                        break;
                    case "LSL≤X"     : 
                        if( lsl > enteredValue ) index++;
                        else index;
                        break;
                    case "X=Target"  : 
                        if( enteredValue != targetValue ) index++;
                        else index;
                        break;
                    case "LSL≤X<USL" : 
                        if( lsl > enteredValue ) index++;
                        else if( enteredValue >= usl ) index++;
                        else index;
                        break;
                    case "LSL≤X≤USL" : 
                        if( lsl > enteredValue ) index++;
                        else if( enteredValue > usl ) index++;
                        else index;
                        break;
                    case "X≤USL"     : 
                        if( enteredValue > usl ) index++;
                        else index;
                }
                return index;
            } else if( row.insInputType === 'Descrete' && row.principal !== "OutSide" ) {
                return parseInt( row.NGQty );
            }
        }, 0)
        instance.setValue(rowKey, 'NGQty', NGQty, false);
        // 불합격수일 때 샘플중에 빈값이 있으면 판정을  중단한다.
    },
    // 불합격수에 따라 샘플을 판정하는 메서드
    setResultColumn({instance, rowKey}) {
        const row = instance.getRow(rowKey);
        const ac = parseInt(row.ac);
        const re = parseInt(row.re);
        const sampleKeys = Object.keys(row).filter(i => /^sample\d+$/.test(i));

        if (sampleKeys.find((i) => (parseInt(i.match(/^sample(\d+)$/)[1]) <= parseInt(row.sampleSize)) && (['', JUDG.NA].includes(row[i])))) {
            return undefined;
        }

        const value = row.NGQty;
        if ( ac > -1 && row.isCTQ === "0") {
            const v = parseInt(value);
            let result = JUDG.NA;
            if (v <= ac) {
                result = JUDG.OK;
            } else if (v >= re) {
                result = JUDG.NG;
            }

            instance.setValue(rowKey, 'result', result, false);
        }
    }
}
const gridModule = {
    destroySerialGrid() {
        if (SERIAL_GRID_INSTANCE) {
            try {
                SERIAL_GRID_INSTANCE.destroy();
            } catch(e) {
                // 
            }
        }
    },
    destroySampleGrid() {
        if (SAMPLE_GRID_INSTANCE) {
            try {
                SAMPLE_GRID_INSTANCE.destroy();
            } catch(e) {
                // 
            }
        }
    },
    convertSampleData(data, checkFromExcel) {
        // - Continuous(연속) ==> 기존 측정
        // - Judgment(판정)
        // - Descrete(이산형)

        // 사용안하는 샘플 데이터에 STRING.BLOCK 입력
        if( checkFromExcel ) {
            let errMsg = "";
            let returnCheck = true;
            data.forEach( ( prop, idx ) => {
                let sampleKeys = Object.keys(data[idx]).filter(i => /^sample\d+$/.test(i));
                let sampleSize = prop.sampleSize;
                sampleKeys = sampleKeys.slice( 0, sampleSize );
                if( SAMPLE_GRID_INSTANCE.store.data.filteredRawData[ idx ].insInputType == prop.insInputType ) {
                    sampleKeys.forEach( ( key ) => {
                        if( prop.insInputType === "Descrete" ) {
                            if( prop[ key ] !== "/" ) {
                                errMsg = "DescreteChangeError"
                                return false;
                            }
                        } else if( parseInt( key.match(/\d+/)[0]) > sampleSize ) {
                            prop.key = STRING.BLOCK;
                        } else if( prop.insInputType === "Continuous" ) {
                            let intCheck = /^\-{0,1}\d+(\.{0,1}\d+){0,1}$/.test( prop[ key ] );
                            if( prop[ key ] === "/" ) {
                                intCheck = true;
                            }
                            if( !intCheck ) {
                                errMsg = "ContinuousChangeError";
                                returnCheck= false;
                                return false;
                            }
                        } else if( prop.insInputType === "Judgment" ) {
                            if( ![ "OK", "NG", "N/A", "\/" ].includes( prop[ key ] ) ) {
                                errMsg = "JudgmentChangeError"
                                returnCheck = false;
                                return false;
                            }
                        }
                    } );
                }
            } );
            if( returnCheck ) {
                return data;
            } else {
                return errMsg;
            }
        } else {
            data.forEach((row) => {
                const sampleSize = parseInt(row.sampleSize);
                const sampleKeys = Object.keys(row).filter(i => /^sample\d+$/.test(i));
                sampleKeys.forEach((i) => {
                    if (row.insInputType === 'Descrete') {
                        // a2InsInputType이 이산형(Descreate)일 때, 모든 sample size 값 입력 x, value = '/'
                        row[i] = STRING.BLOCK;
                    } else if (parseInt(i.match(/\d+/)[0]) > sampleSize) {
                        // grid의 a2SampleSize보다 입력할 행이 더 많으면 초과된 부분은 값 입력 x, value = '/'
                        row[i] = STRING.BLOCK;
                    } else {
                        // insInputType에 따라 기본값 입력
                        if (!row[i]) {
                            if  (row.insInputType === 'Judgment') {
                                row[i] = row.judgInitValue;
                            } else if  (row.insInputType === 'Continuous') {
                                row[i] = row.coInitValue;
                            }
                        }
                    }
                });
            });
            return data;
        }
    },
    setCheckedSample(v) {
        const rowKeys = SAMPLE_GRID_INSTANCE.getCheckedRowKeys();
        rowKeys.forEach((rowKey) => {
            const row = SAMPLE_GRID_INSTANCE.getRow(rowKey);
            const sampleSize = parseInt(row.sampleSize) <= MAX_SAMPLE_SIZE ? parseInt(row.sampleSize) : MAX_SAMPLE_SIZE;
            if( CURRENT_MODE.includes( "part" ) && row.principal !== "InSide" ) return;
            if (row.insInputType === "Judgment") {
                for (let i=1; i<=sampleSize; i++) {
                    const columnName = `sample${i}`;
                    SAMPLE_GRID_INSTANCE.setValue(rowKey, columnName, v);
                } 
            }
        });
    },
    getSampleGridColumns() {
        let sampleColumns = [
            {
                header: 'Insp item',
                name: 'inspItem',
                rowSpan: true,
                minWidth: screen.width/25,
                width: 'auto',
            }, {
                header: 'Insp name',
                name: 'inspName',
                minWidth: screen.width/18,
                width: 'auto',
            }, {
                name: 'spec',
                minWidth: screen.width/25,
                width: 'auto',
            }, {
                header: 'type',
                name: 'insInputType',
                minWidth: screen.width/35,
                width: 'auto',
                align: 'center',
                renderer: InputTypeRenderer,
                relations: (() => {
                    const relations = [];
                    const failureQtyRelation = {
                        targetNames: ['failureQty'],
                        // 입력유형이 이산일대 불량수를 입력할 수 있게 한다.
                        editable: ({value}) => value === 'Descrete' ,
                    }
                    relations.push(failureQtyRelation)
                    return relations;
                })(),
            }, {
                header: 'Sample size',
                name: 'sampleSize',
                minWidth: screen.width/25,
                align: 'right',
                width: 'auto',
                editor: NumberEditor,
                validation: {
                    validatorFn: (value, row, columnName) => /^\d+$/.test(value)
                },
                relations: (() => {
                    const relations = [];
                    for (let i=1 ; i<21 ; i++){
                        relations.push({
                            targetNames: [`sample${i}`],
                            disabled: (props) => {
                                // 샘플의 입력유형이 이산이면 측정값 입력을 차단한다.
                                if (props.row.insInputType === 'Descrete') {
                                    return true;
                                // 샘플 수 만큼만 측정값 입력을 허용한다.
                                } else {
                                    return parseInt(props.value) < i;
                                }
                            }
                        });
                    }
                    return relations;
                })(),
                onAfterChange: (e) => {
                    let row = SAMPLE_GRID_INSTANCE.getRow(e.rowKey);
                    let sampleMethod = row.sampleMethod;
                    if(sampleMethod == 'Variable' && e.value > VARIABLE_MAX_SAMPLE_SIZE){
                        AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "SampleSizeNoGreaterThanHundredThousand"));
                        SAMPLE_GRID_INSTANCE.setValue(e.rowKey, e.columnName, String(e.prevValue));
                    }
                }
            }, {
                header: 'Image',
                name: 'image',
                minWidth: screen.width/25,
                maxWidth: screen.width/25,
                valign: 'middle',
                renderer: ImageRenderer
            }, {
                header: 'Reference',
                name: 'reference',
                minWidth: screen.width/20,
                maxWidth: screen.width/20,
                valign: 'middle',
                renderer: IMANFilesRenderer,
                editor: IMANFilesEditor
            }, {
                header: 'Bad cnt',
                name: 'failureQty',
                minWidth: screen.width/25,
                align: 'right',
                width: 'auto',
                editor: NumberEditor,
                validation: {
                    validatorFn: (value, row, columnName) => /^\d+$/.test(value)
                },
                onAfterChange: (e) => {
                    let row = SAMPLE_GRID_INSTANCE.getRow(e.rowKey);
                    let inputType = row.insInputType;
                    let sampleSize = parseFloat(row.sampleSize);
                    if(inputType == 'Descrete' && e.value > sampleSize){
                        AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "NoGreaterThanSampleSize"));
                        SAMPLE_GRID_INSTANCE.setValue(e.rowKey, e.columnName, String(e.prevValue));
                    }
                }
            }, {
                header: 'Range',
                name: 'a2TargetRange',
                minWidth: screen.width/20,
                align: 'left',
                width: 'auto',
            }, {
                header: 'Target',
                name: 'a2TargetValue',
                minWidth: screen.width/40,
                align: 'left',
                width: 'auto',
            }, {
                name: 'lsl',
                align: 'right',
                minWidth: screen.width/30,
                width: 'auto',
            }, {
                name: 'usl',
                align: 'right',
                minWidth: screen.width/30,
                width: 'auto',
            }, {
                header: 'Principal',
                name: 'principal',
                align: 'right',
                minWidth: screen.width/25,
                width: 'auto',
                hidden: !(CURRENT_MODE == 'part' || CURRENT_MODE == 'partPTR'),
                renderer: principalRenderer
            },/* , {
                header: 'Supplier Status',
                name: 'supplierStatus',
                align: 'middle',
                width: 'auto',
                hidden: !(CURRENT_MODE == 'part' || CURRENT_MODE == 'partPTR'),
                renderer: supplierStatusRenderer
            } */
        ];

        for (let i=1; i<21; i++) {
            sampleColumns.push({
                header: `#${i}`,
                name: `sample${i}`,
                align: 'right',
                width: 'auto',
                minWidth: screen.width/25,
                renderer: SampleValueRenderer,
                editor: SampleValueEditor,
                validation: {
                    validatorFn: (value, row, columnName) => {
                        if (value === '/') {
                            return true;
                        } else if (row.insInputType === 'Judgment') {
                            return Boolean(JUDG.LOV.find(i => i.value === value))
                        } else {
                            return /^\-{0,1}\d+(\.{0,1}\d+){0,1}$/.test(value)
                        }
                    }
                }
            });
        }
        sampleColumns = sampleColumns.concat([
            {
                header: 'Measure Machine',
                name: 'a2MachineClass4',
                minWidth: screen.width/15,
                width: 'auto',
            },
            {
                header: 'description',
                name: 'description',
                minWidth: screen.width/15,
                editor: 'text',
                width: 'auto',
                validation: {
                    validatorFn: (value, row, columnName) => /^.*$/.test(value)
                },
            }, {
                header: 'result',
                name: 'result',
                align: 'right',
                minWidth: screen.width/25,
                width: 'auto',
                renderer: ResultRenderer,
                editor: {
                    // type: 'select',
                    type: SelectBoxEditor,
                    options: {
                        listItems: (() => {
                            return JUDG.LOV.map((i) => {
                                return {
                                    text: i.displayName,
                                    value: i.value,
                                };
                            });
                        })()
                    }
                },
                validation: {
                    validatorFn: (value, row, columnName) => {
                        return Boolean(JUDG.LOV.find(i => value === i.value));
                    },
                },
            }, {
                header: 'CTQ mgmt',
                name: 'CTQMgmtSpec',
                minWidth: screen.width/25,
                width: 'auto',
                align: 'right',
                renderer: CTQMGMTRenderer,
            }, {
                header: 'SPC Result',
                name: 'spcResult',
                minWidth: screen.width/25,
                width: 'auto',
                align: 'right',
            }, {
                header: 'SPC',
                name: 'spc',
                minWidth: screen.width/25,
                width: 'auto',
                align: 'center',
                renderer: SPCRenderer,
            // }, {
            //     header: 'SPC value',
            //     name: 'spcValue',
            //     minWidth: 80,
            //     width: 'auto',
            //     align: 'right',
            }, {
                header: 'Bad code',
                name: CURRENT_MODE.includes( "prod" ) ? 'a2DefectClass3Object' : "a2DefectClass2Object",
                minWidth: screen.width/20,
                width: 'auto',
                align: 'right',
                renderer: NGCodeRenderer,
                onAfterChange: async (e) => {
                    if( e.value ) {
                        let defectObj = AwcObjectUtil.getObject( e.value );
                        await AwcObjectUtil.getProperty( defectObj, "object_name" );
                        appCtxService.ctx.selectedEle.innerText = defectObj.props.object_name.dbValues[0];
                    } else {
                        appCtxService.ctx.selectedEle.innerText = locale.getLocalizedText(localeText, "InspectionResultBedCode");
                    }
                    
                    hideNGPanel();
                },
                // editor: {
                //     // type: 'select',
                //     type: SelectBoxEditor,
                //     options: {
                //         listItems: BED_CODES,
                //     },
                // },
                // validation: {
                //     validatorFn: (value, row, columnName) => {
                //         if (value === '') return true;
                //         return Boolean(BED_CODES.find(i => value === i.value));
                //     },
                // },
            // }, {
            //     header: 'Attach File',
            //     name: 'file',
            //     align: 'center',
            //     minWidth: 120,
            //     width: 'auto',
            //     renderer: FileRenderer,
            //     // editor: FileEditor,
            }, {
                header: 'Bad count',
                name: 'NGQty',
                minWidth: screen.width/25,
                width: 'auto',
                // align: 'right',
                // renderer: NGCodeRenderer,
            },{
                header: 'Attach Files',
                name: 'files',
                align: 'right',
                minWidth: screen.width/20,
                width: 'auto',
                renderer: FilesRenderer,
                editor: FilesEditor,
            }, {
                name: 'sampleMethod',
                hidden: true,
                relations: [{
                    targetNames: ['sampleSize'],
                    // 샘플유형이 가변이면 샘플수를 변경할 수 있게 한다.
                    editable: ({value}) => value === 'Variable',
                }],
            }, {
                header: 'AC',
                name: 'ac',
                align: 'right',
                minWidth: screen.width/35,
                width: 'auto',
            }, {
                header: 'RE',
                name: 're',
                align: 'right',
                minWidth: screen.width/35,
                width: 'auto',
            }
        ]);

        return sampleColumns.map((i) => {
            if (!EDIT_MODE && i.name != 'reference' && i.name != 'files') {
                delete i.editor; 

                if (i.name === 'spc') i.hidden = true;
            }
            return i;
        });
    },
    renderSerialGrid({data}) {
        // serialgrid
        const serialColumns = [
            {
                name: 'seq',
                width: 80,
            },
            {
                name: 'serial',
                editor: 'text',
            }
        ];

        SERIAL_GRID_INSTANCE = new Grid({
            el: document.getElementById('serialGrid'),
            columns: serialColumns.map((i) => {
                if (!EDIT_MODE) delete i.editor; 
                return i;
            }),
            data,
            header: {
                height: screen.height/30,
            },
            // editingEvent: 'click',
            bodyHeight: screen.height/2,
            rowHeight: screen.height/30,
            minRowHeight: screen.height/30,
            contextMenu: null,
        });
        return SERIAL_GRID_INSTANCE;
    },
    renderSampleGrid({ data }) {
        // samplegrid
        // renderSampleGrid의 data => 각 grid에 들어갈 A2QProdInspectionResult Array
        let frozenCount = CURRENT_MODE == "part" || CURRENT_MODE == "partPTR" ? 14 : 13;

        SAMPLE_GRID_INSTANCE = new Grid({
            el: document.getElementById('sampleGrid'),
            rowHeaders: ['checkbox'],
            columns: this.getSampleGridColumns(),
            data: gridModule.convertSampleData(data, false),
            header: {
                height: screen.height/30,
            },
            columnOptions: {
                resizable: true,
                // frozenCount: frozenCount,
            },
            // editingEvent: 'click',
            bodyHeight: screen.height/2,
            rowHeight: screen.height/30,
            minRowHeight: screen.height/30,
            contextMenu: null,
        });

        //principal이 협력사인 경우 수정 불가능하도록
        let colNameList = this.getSampleGridColumns().map(obj=>obj.name);
        for(let i = 0; i < data.length; i++){
            if(data[i].principal == "OutSide"){
                for(let colName of colNameList){
                    if(colName != "reference" && colName != "files"){
                        SAMPLE_GRID_INSTANCE.disableCell(i, colName);
                    }
                }
            }
        }

        //그리드에 값이 변경시 적용할 이벤트 등록
        SAMPLE_GRID_INSTANCE.on('beforeChange', (payload) => {
            const {origin, changes, instance, stop} = payload;

            if (origin === "paste" ) {
                changes.forEach(({columnName, nextValue, rowKey}) => {
                    const column = instance.getColumn(columnName);

                    if (["file", "files"].includes(columnName)) {
                        payload.stop();
                    } else if (["sampleSize", "failureQty", "result", 'a2DefectClass3Object'].includes(columnName)) {
                        if (!column.validation.validatorFn(nextValue)) {
                            payload.stop();
                        }
                    } if (/^sample\d+$/.test(columnName)) {
                        const row = instance.getRow(rowKey);
                        if (nextValue === STRING.BLOCK || !column.validation.validatorFn(nextValue, row)) {
                            payload.stop();
                        }
                    }

                });
            }
        });
        SAMPLE_GRID_INSTANCE.on('afterChange', ({changes, instance}) => {
            changes.forEach(({columnName, rowKey, value}) => {
                if (!["files"].includes(columnName)) {
                    FLAG_CHANGE = true;
                }
                //로우별 검사 결과 입력
                if (["failureQty"].includes(columnName)) {
                    gridEvents.setNGQtyColumn({instance, rowKey, value});
                } else if (["NGQty"].includes(columnName)) {
                    gridEvents.setResultColumn({columnName, instance, rowKey, value})
                // 로우별 불합격수 입력
                } else if (/^sample\d+$/.test(columnName)) {
                    gridEvents.setFalseCountColumnFromSampleColumn({instance, rowKey});
                    gridEvents.setResultColumn({instance, rowKey})
                // 샘플 수량 변경에 따른 처리
                } else if (columnName === 'sampleSize') {
                    gridEvents.setVisibleSampleColumns({instance});
                    gridEvents.setFalseCountColumnFromSampleColumn({instance, rowKey});
                    gridEvents.setBlockSampleColumns({instance, value, rowKey});
                } /* else if (columnName.includes( 'a2DefectClass' ) ) {
                    // gridEvents.setBedCode({instance});
                } */
            });
        });

        //샘플의 입력값의 visible 상태를 설정
        gridEvents.setVisibleSampleColumns({instance: SAMPLE_GRID_INSTANCE});
        //선택된 불량코드 찾아서 대표 불량 코드 리스트 설정
        // gridEvents.setBedCode({instance: SAMPLE_GRID_INSTANCE});

        return SAMPLE_GRID_INSTANCE;
    },
    getExcelColumns({instance}) {
        const maxSampleCount = gridEvents.getVisibleMaxSampleColumnNumber({instance});
        const tmpColumns = EXCEL_COLUMNS.filter((v) => {
            const matched = v.match(/^sample(\d+)$/);
            if (matched) {
                if (maxSampleCount < parseInt(matched[1])) {
                    return false;
                } else {
                    return true;
                }
            } else {
                return true;
            }
        })
        return tmpColumns;
    }
}

const SPCModule = {
    formatDate(v) {
        let date = undefined
        if (v === undefined) date = new Date();
        else date = new Date(v);
        date.setHours(date.getHours() + 9);
        return date.toISOString().replace('T', ' ').substring(0, 23);
    },
    async getInputData({basedOnId, CTQLotCount}) {

        const inputData = [];
        if (!basedOnId) {
            AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "inspResultNoItemInfo"));
            return inputData;
        }
        let results = [];
        try {
            let searchEntries = ['A2BasedOnId'];
            let values = [basedOnId];
            if(CURRENT_MODE == 'part'){
                searchEntries.push("A2Principal2");
                values.push(INSP_REQ.modelObject.props.a2InsRequestType.dbValue);
            }

            await AwcQueryUtil.executeSavedQuery(TYPE_NAMES[CURRENT_MODE].spcSearchQuery, searchEntries, values).then( ( res ) => {
                res.sort( ( a, b ) => {
                    a = new Date( a.props.date_released.dbValues[0] );
                    b = new Date( b.props.date_released.dbValues[0] );
                    return b - a;
                });
                results = res;
            });
        } catch(e) {
            // 
        }
        if (!results || (results && results.length<1)) {
            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultNoHistoryData"));
            return inputData; 
        }
        if( results.length > 1 ) {
            results.splice(CTQLotCount);
        }
        const tmpResult = results[0];
        const planUid = tmpResult.props.a2InspectionPlan.dbValues[0];

        if (!planUid) {
            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultNoPlan"));
            return inputData; 
        }

        const planItem = await AwcObjectUtil.loadObjects(planUid);
        await AwcObjectUtil.getProperties(planItem, ["item_id", "date_released"]);
        const planItemId = planItem.props.item_id.dbValues[0];
        const planReleasedDate = this.formatDate(planItem.props.date_released.dbValues[0]);
        const inspectDataList = [];
        // let exLotNo = "";
        for (const result of results) {
            let resultLOTNo = result.props.a2QLotNo.dbValues;
            // if( exLotNo == resultLOTNo ) {
            //     resultLOTNo = resultLOTNo + "_";
            // }
            // exLotNo = resultLOTNo;
            // const resultLOTNo = result.props.a2LOTNo.dbValues[0];
            const resultDateReleased = result.props.date_released.dbValues[0];
            const resultSampleSize = result.props.a2SampleSize.dbValues[0];

            for (let i=1; i <= parseInt(resultSampleSize); i++) {
                inspectDataList.push({
                    inspect_data: parseFloat(result.props[`a2D${String(i).padStart(2,0)}`].dbValues[0]),
                    inspect_dt: this.formatDate(resultDateReleased),
                    insp_id: planItemId,
                    lot_id: resultLOTNo, 
                });
            }
        }
        const specInfo = {
            SPECDATE: planReleasedDate,
            insp_id: planItemId,
            managechart_yn: "N",
            specLower: parseFloat(tmpResult.props.a2Lsl.dbValues[0]),
            specUpper: parseFloat(tmpResult.props.a2Usl.dbValues[0]),
            specMid: parseFloat((parseFloat(tmpResult.props.a2Lsl.dbValues[0]) + parseFloat(tmpResult.props.a2Usl.dbValues[0])) / 2),
            sample_size: parseInt(tmpResult.props.a2SampleSize.dbValues[0]),
        };
        inputData.push({
            InspectDataList: inspectDataList,
            specInfo: {
                chart_code: 'xbarr',
                ...specInfo
            },
        })
        return inputData;
    },
    async getSPCData({inputData}) {
        if (inputData.length) {
            let outputData = [];
            try {
                const spcRes = await fetch('https://qps-detest-idx.singlex.com/web-statistics/spc-stat', {
                    method: 'POST',
                    body: JSON.stringify(inputData),
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8',
                    }
                });
                const text = await spcRes.text();
                const tmp = text.replaceAll(/[^\"a-zA-Z]{1}([a-zA-Z]+)[^\"a-zA-Z]{1}/g, '"$1"')
                outputData = JSON.parse(tmp);
            } catch(e) {
                // SPC 서버 무응답시 유호 프로님께 문의
                alert('SPC 서버가 응답하지 않습니다.');
            }
            return outputData;
        } else {
            return [];
        }
    },
    async joinSamples({inputData, sampleValues, LOTNo}) {
        sampleValues.forEach((v) => {
            inputData[0].InspectDataList.unshift({
                inspect_data: parseFloat(v),
                inspect_dt: this.formatDate(),
                insp_id: inputData[0].specInfo.insp_id,
                lot_id: LOTNo, 
            });
        });
        return inputData;
    },
}

const resultModule = {
    dynamicSort(property) {
        var sortOrder = 1;
        if(property[0] === "-") {
            sortOrder = -1;
            property = property.substr(1);
        }
        return function (a,b) {
            var result = (a["props"][property].uiValues[0]  < b["props"][property].uiValues[0]) ? -1 : (a["props"][property].uiValues[0] > b["props"][property].uiValues[0]) ? 1 : 0;
            return result * sortOrder;
        }
    },
    dynamicSort2(property1, property2) {
        var sortOrder = 1;
        if(property1[0] === "-") {
            sortOrder = -1;
            property1 = property1.substr(1);
        }
        return function (a,b) {
            /* next line works with strings and numbers, 
             * and you may want to customize it to your needs
             */
            var result = (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  < b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? -1 : (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  > b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? 1 : 0;
            return result * sortOrder;
        }
    },
    async getInputTypes() {
        if (INPUT_TYPES.length < 1) {
            const result = await AwcObjectUtil.getInitialLOVValues("a2InsInputType", TYPE_NAMES[CURRENT_MODE].iPCheckItem);
            result.lovValues.forEach((i) => {
                INPUT_TYPES.push({
                        displayName: i.propDisplayValues.lov_values[0],
                        value: i.propInternalValues.lov_values[0],
                    });
            });
        }
    },
    async getMeasureMachineLOV() {
        try {
            INSP_REQ.getAllInspectionResults().then( ( results ) => {
                for (const obj of results) {
                    let measureMachineList = [{
                        text: '',
                        value: '',
                    }];

                    if( obj.props.a2MeasureMachine.dbValues.length > 0 && obj.props.a2MeasureMachine.dbValues[0] != null ) {
                        for(let i = 0; i < obj.props.a2MeasureMachine.dbValues.length; i++){
                            measureMachineList.push({
                                text: obj.props.a2MeasureMachine.uiValues[i],
                                value: obj.props.a2MeasureMachine.dbValues[i],
                            });
                        }
                    }

                    MEASURE_MACHINE_LOV[obj.uid] = measureMachineList;
                }
            } );
        } catch(e) {
            // 
        }
    },
    async getPrincipal() {
        if (PRINCIPAL.length < 1) {
            const result = await AwcObjectUtil.getInitialLOVValues("a2Principal2", "A2QPartPTResult");
            result.lovValues.forEach((i) => {
                PRINCIPAL.push({
                    displayName: i.propDisplayValues.lov_values[0],
                    value: i.propInternalValues.lov_values[0],
                });
            });
        }
    },
    async getSupplierStatus() {
        if (SUPPLIER_STATUS.length < 1) {
            const result = await AwcObjectUtil.getInitialLOVValues("a2SupplierStatus", "A2QPartPTResult");
            result.lovValues.forEach((i) => {
                SUPPLIER_STATUS.push({
                    displayName: i.propDisplayValues.lov_values[0],
                    value: i.propInternalValues.lov_values[0],
                });
            });
        }
    },
    async getSupplierRequestList(data) {
        let supplierRequestList = INSP_REQ.modelObject.props.a2SupplierRequestList;
        let length = supplierRequestList.dbValues.length;
        for(let i = 0; i < length; i++){
            data.a2SupplierRequestListValues.dbValue.push({
                "propDisplayValue": supplierRequestList.displayValues[i],
                "dispValue": supplierRequestList.displayValues[i],
                "propInternalValue": supplierRequestList.dbValues[i]
            });
        }
    },
    async getBedCodes( grid  ) {
            BAD_CODE_LIST_VALUES.dbValue = [
                {
                    propDisplayValue: "",
                    dispValue: "",
                    propInternalValue: ""
                }
            ];
            
            const defectCode = CURRENT_MODE.includes( "prod" ) ? "a2DefectClass3Object" : "a2DefectClass2Object";
            if( grid && grid.store ) {
                let lovValues = BAD_CODE_LIST_VALUES.dbValue.concat( await Promise.all( grid.store.data.rawData.map( async ( row ) => {
                    if( row[ defectCode ] ) {
                        const defectObj = AwcObjectUtil.getObject( row[ defectCode ] );
                        await AwcObjectUtil.getProperty( defectObj, "object_name" );
                        return {
                            propDisplayValue: defectObj.props.object_name.dbValues[0],
                            dispValue: defectObj.props.object_name.dbValues[0],
                            propInternalValue: defectObj.uid
                        }
                    }
                } )
                ) );
                lovValues = lovValues.filter( ( lov ) => {
                    return lov !== undefined;
                } );
                BAD_CODE_LIST_VALUES.dbValue = lovValues;
            } else {
                INSP_REQ.getAllInspectionResults().then( async ( insps ) => {
                    let target = await Promise.all( insps.map( async ( insp ) => {
                        await AwcObjectUtil.getProperty( insp, defectCode );
                        if( insp.props[ defectCode ].dbValues[0] ) {
                            return insp;
                        }
                    } ) );
                    target = target.filter( ( obj ) => {
                        return obj !== undefined;
                    } );
    
                    if( target.length > 0 ) {
                        target.sort( ( a, b ) => {
                            return parseInt( a.props.a2Index.dbValues[0] ) - parseInt( b.props.a2Index.dbValues[0] );
                        } );
                        let lovValues = BAD_CODE_LIST_VALUES.dbValue.concat( await Promise.all( target.map( async ( insp ) => {
                            let defectObj = await AwcObjectUtil.getObject( insp.props[ defectCode ].dbValues[0] );
                            await AwcObjectUtil.getProperty( defectObj, "object_name" );
                            return {
                                propDisplayValue: defectObj.props.object_name.dbValues[0],
                                dispValue: defectObj.props.object_name.dbValues[0],
                                propInternalValue: defectObj.uid
                            }
                        } ) ) );
                        lovValues = lovValues.filter( ( lov ) => {
                            return lov !== undefined;
                        } );
                        BAD_CODE_LIST_VALUES.dbValue = lovValues;
                    }
                } );
            }
    },
    async getJudgLOV() {
        if (JUDG.LOV.length < 1) {
            const A2QJudgementLOV = await AwcObjectUtil.getInitialLOVValues("a2Result", TYPE_NAMES[CURRENT_MODE].inspectionResult);
            A2QJudgementLOV.lovValues.forEach((i) => {
            JUDG.LOV.push({
                    displayName: i.propDisplayValues.lov_values[0],
                    value: i.propInternalValues.lov_values[0],
                });
            });
        }
        return JUDG.LOV;
    },
    async getResultLOV() {
        if (RESULT.LOV.length < 1) {
            const A2InspectionResultLOV = await AwcObjectUtil.getInitialLOVValues("a2Result", TYPE_NAMES[CURRENT_MODE].iRItemRevision);
            A2InspectionResultLOV.lovValues.forEach((i) => {
                RESULT.LOV.push({
                    displayName: i.propDisplayValues.lov_values[0],
                    value: i.propInternalValues.lov_values[0],
                });
            });
        }
        return RESULT.LOV;
    },
    setCurrentMode({reqModelObj}) {
        // if (reqModelObj.type === 'A2QProdIRItemRevision') {
        if (/ProdIR/.test(reqModelObj.type)) {
            CURRENT_MODE = 'prod'; 
        // } else if (reqModelObj.type === 'A2QPartIRItemRevision') {
        } else if (/PartIR/.test(reqModelObj.type)) {
            CURRENT_MODE = 'part';
        } else if (/ProdPTR/.test(reqModelObj.type)) {
            CURRENT_MODE = 'prodPTR';
        } else if (/PartPTR/.test(reqModelObj.type)) {
            CURRENT_MODE = 'partPTR';
        } else {
            AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "inspResultUnknownType"));
        }
    },
    async judgmentSheet({data}) {
        // 진행 - N/A가 하나라도 있으면
        // 불 - N/A가 없고 불이 하나라도 있으면
        // 합 - 전부 합격이고 모든 sampleSize가 0이 아니고, 모든 샘플측정값이 있으면
        // N/A - 처음에만
        let allRows = SAMPLE_GRID_INSTANCE.getData();
        let result = undefined;
        let isPart = CURRENT_MODE == "part" || CURRENT_MODE == "partPTR";
        let rows = isPart ? allRows.filter(row => row.principal == "InSide") : allRows;

        // 샘플 사이즈가 0인게 있으면 진행중

        if (rows.length < 1) {
            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultNoItems"));
            return undefined;
        }

        if (rows.find( row => row.sampleSize < 1 && row.sampleMethod === 'Variable')) {
            result = RESULT.P;
        } else  {
            result = rows.reduce((c, row) => {
                if (c !== RESULT.S) {
                    return c;
                } else {
                    if (row.result === JUDG.OK) {
                        if (row.sampleSize > 0) {
                            return RESULT.S;
                        } else {
                            AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultExistSampleSizeZero"));
                            return RESULT.P;
                        }
                    }
                    else if (row.result === JUDG.NA) return RESULT.P;
                    else if (row.result === JUDG.NG) return RESULT.F;
                    else return RESULT.N;
                }
            }, RESULT.S);
        }

        
        if(isPart){
            const checkUid = data.sheetListBox.dbValue; 
            const sheetModelObj = await AwcObjectUtil.loadObjects(checkUid);
            let supplierResult = sheetModelObj.props.a2SupplierResult.dbValues[0];
            let lgResult = result;

            if(!allRows.find(row => row.principal == "InSide")){ //principal이 사내인 체크항목이 없으면 사내 판정 합격처리
                lgResult = RESULT.S;
            }
            
            if(!allRows.find(row => row.principal == "OutSide")){ //principal이 협력사인 체크항목이 없으면 협력사 판정 합격처리
                supplierResult = RESULT.S;
            }
            
            if(supplierResult == RESULT.N || supplierResult == RESULT.P || lgResult == RESULT.N || lgResult == RESULT.P){
                result = RESULT.P;
            }else if(supplierResult == RESULT.F || lgResult == RESULT.F){
                result = RESULT.F;
            }else{
                result = RESULT.S;
            }

            this.setSheetJudgment(data, 'lgJudgment', lgResult);
            this.setSheetJudgment(data, 'supplierJudgment', supplierResult);
        }

        this.setSheetJudgment(data, 'judgment', result);
    },
    judgmentReq(results) {
        const countN = results.filter((i) => i === RESULT.N || i === null).length;

        if (results.length === countN) {
            return RESULT.N;
        } else {
            return results.reduce((c, r) => {
                if (c !== RESULT.S) {
                    return c;
                } else {
                    if (r === RESULT.S)  return RESULT.S;
                    else if (r === RESULT.P ) return RESULT.P;
                    else if (r === RESULT.N || r === null) return RESULT.P;
                    else if (r === RESULT.F) return RESULT.F;
                    else return RESULT.N;
                }
            }, RESULT.S);
        }

    },
    async getSavedSheetJudgment({data}, gridObjectDatas) {
        const checkUid = data.sheetListBox.dbValue; 
        const sheetModelObj = await AwcObjectUtil.loadObjects(checkUid);
        const result = sheetModelObj.props.a2Result.dbValues[0];
        this.setSheetJudgment(data, 'judgment', result);
        if(CURRENT_MODE == "part" || CURRENT_MODE == "partPTR"){
            const lgResult = sheetModelObj.props.a2LGResult.dbValues[0];
            const supplierResult = sheetModelObj.props.a2SupplierResult.dbValues[0];
            this.setSheetJudgment(data, 'lgJudgment', lgResult);
            this.setSheetJudgment(data, 'supplierJudgment', supplierResult);

            if(gridObjectDatas.find(row => row.principal == "InSide")){
                document.querySelector('aw-label[prop="data.lgJudgment"]').classList.remove("hidden");
            }else{
                document.querySelector('aw-label[prop="data.lgJudgment"]').classList.add("hidden");
            }

            if(gridObjectDatas.find(row => row.principal == "OutSide")){
                document.querySelector('aw-label[prop="data.supplierJudgment"]').classList.remove("hidden");
            }else{
                document.querySelector('aw-label[prop="data.supplierJudgment"]').classList.add("hidden");
            }
        }
    },
    setSheetJudgment(data, key, result) {
        if (!result) {
            result = RESULT.N;
        }
        const selected = RESULT.LOV.find(i => i.value === result);
        if (selected) {
            data[key].uiValue = selected.displayName;
            data[key].dbValue = selected.value;

            const el = document.querySelector('aw-label[prop="data.' + key + '"] .aw-widgets-propertyLabelTopValueContainer');
            if (el) {
                el.classList.remove('result-color-ok');
                el.classList.remove('result-color-no');
                if (selected.value === RESULT.S) el.classList.add('result-color-ok');
                if (selected.value === RESULT.F) el.classList.add('result-color-no');
            }
        }
    },
    setInspectionTemplateName(name) {
        let el = document.getElementById( "controlPanel" );
        let data = viewModelService.getViewModelUsingElement( el );
        uwPropertyService.setValue( data[ "inspectionTemplateName" ], name );
        uwPropertyService.setDisplayValue( data[ "inspectionTemplateName" ], [ name ] );
    },
    setSelectedItem(name) {
        let el = document.getElementById( "controlPanel" );
        let data = viewModelService.getViewModelUsingElement( el );
        uwPropertyService.setValue( data[ "selectedItem" ], name );
        uwPropertyService.setDisplayValue( data[ "selectedItem" ], [ name ] );
    },
    // setBedCode({data, failureCode}) {
        // data.bedCodeListBox.uiValue = failureCode.uiValues[0];
        // data.bedCodeListBox.dbValue = failureCode.dbValues[0];
        // data.bedCodeListBox.dispValue = failureCode.dbValues[0];
    // },
    async getSavedSheetBedCode({data}) {
        const checkUid = data.sheetListBox.dbValue; 
        const sheetModelObj = await AwcObjectUtil.getObject(checkUid);
        const defectCheck = CURRENT_MODE.includes( "prod" ) ? "a2DefectClass3Object" : "a2DefectClass2Object";
        await AwcObjectUtil.getProperty( sheetModelObj, defectCheck );
        if( sheetModelObj.props[ defectCheck ].dbValues[0] ) {
            const defectCode = AwcObjectUtil.getObject( sheetModelObj.props[ defectCheck ].dbValues[0] );
            await AwcObjectUtil.getProperty( defectCode, "object_name" );
            data.bedCodeListBox.uiValue = defectCode.props.object_name.dbValues[0];
            data.bedCodeListBox.dbValue = defectCode.uid;
            data.bedCodeListBox.dispValue = defectCode.uid;
        }
        // this.setBedCode({data, failureCode});
    },
    createGridRow(vmo) {
        let inspItem = "";
        let inspName = vmo.props.object_name.dbValues[0] ? vmo.props.object_name.dbValues[0]: "";
        if( CURRENT_MODE === "part" ) {
            inspName = `${vmo.props.a2Class1String.dbValues[0]}/${vmo.props.a2Class2String.dbValues[0]}`;
        }
        if(CURRENT_MODE == "prod") {
            let group1 = vmo.props.a2Group1.dbValues[0] ? vmo.props.a2Group1.dbValues[0] : "";
            let group2 = vmo.props.a2Group2.dbValues[0] ? vmo.props.a2Group2.dbValues[0] : "";
            let group3 = vmo.props.a2Group3.dbValues[0] ? vmo.props.a2Group3.dbValues[0] : "";
            let group4 = vmo.props.a2Group4.dbValues[0] ? vmo.props.a2Group4.dbValues[0] : "";
            let group5 = vmo.props.a2Group5.dbValues[0] ? vmo.props.a2Group5.dbValues[0] : "";
            if((group5.includes(inspName) || group5 == "") && inspItem == "") {
                inspItem = group4;
            }
            if (group4 == "" && inspItem == "") {
                inspItem = group3;
            }
            if (group3 == "" && inspItem == "") {
                inspItem = group2;
            }
            if (group2 == "" && inspItem == "") {
                inspItem = group1;
            }
        } else {
            try {
                inspItem = vmo.props.a2CheckSheetObject.uiValue;
                inspItem = inspItem.substring( inspItem.indexOf("-")+1, inspItem.length );
            } catch (e) {
                //
            }
        }

        let rowData = {
            id              : vmo.props.a2Id.dbValues[0],
            uid             : vmo.uid,
            type            : vmo.type,
            inspItem        : inspItem,
            inspName        : inspName,
            index           : Number(vmo.props.a2Index.dbValues[0] ? vmo.props.a2Index.dbValues[0]: ""),
            insInputType    : vmo.props.a2InsInputType.dbValues[0] ? vmo.props.a2InsInputType.dbValues[0]: "",
            judgInitValue   : vmo.props.a2JudgeInitValue.dbValues[0] ? vmo.props.a2JudgeInitValue.dbValues[0]: "",
            coInitValue     : vmo.props.a2ConInitValue.dbValues[0] ? String(parseFloat(vmo.props.a2ConInitValue.dbValues[0])): "",
            spec            : vmo.props.a2InsSpec.dbValues[0] ? vmo.props.a2InsSpec.dbValues[0]: "",
            sampleSize      : vmo.props.a2SampleSize.dbValues[0] ? String(parseFloat(vmo.props.a2SampleSize.dbValues[0])): "",
            image           : vmo.thumbnail,
            reference       : vmo.props.IMAN_specification.dbValues.length > 0 ? vmo.props.IMAN_specification.dbValues: "",
            ac              : vmo.props.a2Ac.dbValues[0] ? String(parseFloat(vmo.props.a2Ac.dbValues[0])): "",
            re              : vmo.props.a2Re.dbValues[0] ? String(parseFloat(vmo.props.a2Re.dbValues[0])): "",
            failureQty      : vmo.props.a2FailureQty.dbValues[0] ? vmo.props.a2FailureQty.dbValues[0]: "0",
            lsl             : vmo.props.a2LslEmpty.dbValues[0] == "1" ? "" : String(vmo.props.a2Lsl.displayValues[0]),
            usl             : vmo.props.a2UslEmpty.dbValues[0] == "1" ? "" : String(vmo.props.a2Usl.displayValues[0]),
            lslEmpty        : vmo.props.a2LslEmpty.dbValues[0] == "1",
            uslEmpty        : vmo.props.a2UslEmpty.dbValues[0] == "1",
            sample1         : vmo.props.a2D01.dbValues[0] ? vmo.props.a2D01.dbValues[0]: "",
            sample2         : vmo.props.a2D02.dbValues[0] ? vmo.props.a2D02.dbValues[0]: "",
            sample3         : vmo.props.a2D03.dbValues[0] ? vmo.props.a2D03.dbValues[0]: "",
            sample4         : vmo.props.a2D04.dbValues[0] ? vmo.props.a2D04.dbValues[0]: "",
            sample5         : vmo.props.a2D05.dbValues[0] ? vmo.props.a2D05.dbValues[0]: "",
            sample6         : vmo.props.a2D06.dbValues[0] ? vmo.props.a2D06.dbValues[0]: "",
            sample7         : vmo.props.a2D07.dbValues[0] ? vmo.props.a2D07.dbValues[0]: "",
            sample8         : vmo.props.a2D08.dbValues[0] ? vmo.props.a2D08.dbValues[0]: "",
            sample9         : vmo.props.a2D09.dbValues[0] ? vmo.props.a2D09.dbValues[0]: "",
            sample10        : vmo.props.a2D10.dbValues[0] ? vmo.props.a2D10.dbValues[0]: "",
            sample11        : vmo.props.a2D11.dbValues[0] ? vmo.props.a2D11.dbValues[0]: "",
            sample12        : vmo.props.a2D12.dbValues[0] ? vmo.props.a2D12.dbValues[0]: "",
            sample13        : vmo.props.a2D13.dbValues[0] ? vmo.props.a2D13.dbValues[0]: "",
            sample14        : vmo.props.a2D14.dbValues[0] ? vmo.props.a2D14.dbValues[0]: "",
            sample15        : vmo.props.a2D15.dbValues[0] ? vmo.props.a2D15.dbValues[0]: "",
            sample16        : vmo.props.a2D16.dbValues[0] ? vmo.props.a2D16.dbValues[0]: "",
            sample17        : vmo.props.a2D17.dbValues[0] ? vmo.props.a2D17.dbValues[0]: "",
            sample18        : vmo.props.a2D18.dbValues[0] ? vmo.props.a2D18.dbValues[0]: "",
            sample19        : vmo.props.a2D19.dbValues[0] ? vmo.props.a2D19.dbValues[0]: "",
            sample20        : vmo.props.a2D20.dbValues[0] ? vmo.props.a2D20.dbValues[0]: "",
            spcResult       : vmo.props.a2SPCResult.dbValues[0] ? vmo.props.a2SPCResult.dbValues[0]: "",
            sampleMethod    : vmo.props.a2SampleMethod.dbValues[0] ? vmo.props.a2SampleMethod.dbValues[0]: "",
            a2TargetValue   : vmo.props.a2TargetValue.dbValues[0] ? vmo.props.a2TargetValue.displayValues[0] : "",
            a2TargetRange   : vmo.props.a2TargetRange.displayValues[0] ? vmo.props.a2TargetRange.displayValues[0] : "",
            description     : vmo.props.object_desc.dbValues[0] ? vmo.props.object_desc.dbValues[0]: "",
            NGQty           : vmo.props.a2NGQty.dbValues[0] ? vmo.props.a2NGQty.dbValues[0]: "",
            file            : vmo.props.TC_Attaches.dbValues.length > 0 ? vmo.props.TC_Attaches.dbValues[vmo.props.TC_Attaches.dbValues.length-1]: "",
            files           : vmo.props.TC_Attaches,
            isCTQ           : vmo.props.a2IsCTQ.dbValues[0] ? vmo.props.a2IsCTQ.dbValues[0]: "",
            CTQMgmtMethod   : vmo.props.a2CTQMgmtMethod.dbValues[0] ? vmo.props.a2CTQMgmtMethod.dbValues[0]: "",
            CTQMgmtSpec     : vmo.props.a2CTQMgmtSpec.dbValues[0] ? String(parseFloat(vmo.props.a2CTQMgmtSpec.dbValues[0])): "",
            CTQLotCount     : vmo.props.a2CTQLotCount.dbValues[0] ? vmo.props.a2CTQLotCount.dbValues[0]: "",
            basedOnId       : vmo.props.a2BasedOnId.dbValues[0] ? vmo.props.a2BasedOnId.dbValues[0]: "",
            LOTNo           : vmo.props.a2QLotNo.dbValues ? vmo.props.a2QLotNo.dbValues: "",
            a2ContinousDigit: vmo.props.a2ContinousDigit.dbValues[0] ? vmo.props.a2ContinousDigit.dbValues[0]: "",
            // a2MeasureMachine: vmo.props.a2MeasureMachine.dbValues[0],
            principal       : CURRENT_MODE == "part" || CURRENT_MODE == "partPTR" ? vmo.props.a2Principal2.dbValues[0] : "",
            principalDisp   : CURRENT_MODE == "part" || CURRENT_MODE == "partPTR" ? vmo.props.a2Principal2.uiValue : "",
            supplierResult  : CURRENT_MODE == "part" || CURRENT_MODE == "partPTR" ? vmo.props.a2SupplierResult.dbValues[0] : "",
            lgResult        : CURRENT_MODE == "part" || CURRENT_MODE == "partPTR" ? vmo.props.a2LGResult.dbValues[0] : "",
            a2MachineClass1 : vmo.props.a2MachineClass1.dbValues[0] ? vmo.props.a2MachineClass1.dbValues[0] : "",
            a2MachineClass2 : vmo.props.a2MachineClass2.dbValues[0] ? vmo.props.a2MachineClass2.dbValues[0] : "",
            a2MachineClass3 : vmo.props.a2MachineClass3.dbValues[0] ? vmo.props.a2MachineClass3.dbValues[0] : "",
            a2MachineClass4 : vmo.props.a2MachineClass4.dbValues[0] ? vmo.props.a2MachineClass4.dbValues[0] : "",
            // spcValue: 0,
            props           : {inspItem: {uiValues: [inspItem]},inspName: {uiValues: [inspName]}},
            a2DefectClass1Object     : vmo.props.a2DefectClass1Object.dbValues[0] ? vmo.props.a2DefectClass1Object.dbValues[0] : "",
            a2DefectClass2Object     : vmo.props.a2DefectClass2Object.dbValues[0] ? vmo.props.a2DefectClass2Object.dbValues[0] : "",
            a2DefectClass3Object     : vmo.props.a2DefectClass3Object && vmo.props.a2DefectClass3Object.dbValues[0] ? vmo.props.a2DefectClass3Object.dbValues[0] : "",
            // badCodeExist    : vmo.props.a2FailureCode.dbValues[0] ? true : false
        }

        rowData.result = vmo.props.a2Result.dbValues[0] ? vmo.props.a2Result.dbValues[0]: rowData.judgInitValue;
        if(CURRENT_MODE == "part" || CURRENT_MODE == "partPTR"){
            rowData.result = rowData.principal == "InSide" ? rowData.lgResult : rowData.supplierResult;
            if(rowData.principal == "InSide"){
                rowData.result = rowData.result ? rowData.result : rowData.judgInitValue;
            }
        }
        rowData.result = rowData.result ? rowData.result : JUDG.NA;

        return rowData;
    },
    async saveReqJudgment({data}) {
        const results = [];
        const lgResults = [];
        const supplierResults = [];
        const isPart = CURRENT_MODE == "part" || CURRENT_MODE == "partPTR";
        let props = isPart ? ["a2Result", "a2LGResult", "a2SupplierResult"] : ["a2Result"];

        for (const sheet of data.sheetListValues.dbValue) {
            const sheetUid = sheet.propInternalValue;
            const sheetModelObj = await AwcObjectUtil.getObject(sheetUid);
            await AwcObjectUtil.getProperty(sheetModelObj, props, true);
            const result = sheetModelObj.props.a2Result.dbValues[0];
            results.push(result);

            if(isPart){
                const lgResult = sheetModelObj.props.a2LGResult.dbValues[0];
                const supplierResult = sheetModelObj.props.a2SupplierResult.dbValues[0];
                lgResults.push(lgResult);
                supplierResults.push(supplierResult);
            }
        }
        const result = await resultModule.judgmentReq(results);
        const reqModelObj = INSP_REQ.getModelObject();
        let values = [result];

        if(isPart){
            const lgResult = await resultModule.judgmentReq(lgResults);
            const supplierResult = await resultModule.judgmentReq(supplierResults);
            values = [result, lgResult, supplierResult];
        }

        await AwcObjectUtil.setProperties(reqModelObj, props, values);
    },
    async saveSheetJudgment({data}) {
        const checkUid = data.sheetListBox.dbValue; 
        const sheetModelObj = await AwcObjectUtil.getObject(checkUid);
        const result = data.judgment.dbValue;

        let props = ['a2Result'];
        let values = [result];

        if(CURRENT_MODE == "part" || CURRENT_MODE == "partPTR"){
            const lgResult = data.lgJudgment.dbValue;
            props = ['a2Result', 'a2LGResult'];
            values = [result, lgResult];

            const rows = SAMPLE_GRID_INSTANCE.getData();
            if(!rows.find(row => row.principal == "OutSide")){ //시트에 principal이 협력사인 체크항목이 없을경우 합격처리하기위해
                const supplierResult = data.supplierJudgment.dbValue;
                props.push('a2SupplierResult');
                values.push(supplierResult);
            }
        }

        await AwcObjectUtil.setProperties(sheetModelObj, props, values);
    },
    async setCheckSheet(data, checkSheets){
        data.sheetListValues.dbValue = [];
        await AwcObjectUtil.getProperties(checkSheets, ["a2Id", "a2RevId", "a2Index", "a2IsDeleted"], true);
        checkSheets.sort(this.dynamicSort("a2Index"));
        for(let i = 0; i < checkSheets.length; i++) {
            if( checkSheets[i].props.a2IsDeleted.dbValues[0] == "YES" ) {
                continue;
            }
            data.sheetListValues.dbValue.push({
                propDisplayValue: checkSheets[i].props.object_name.dbValues[0],
                propDisplayDescription: checkSheets[i].props.a2Id.dbValues[0] + "/" + checkSheets[i].props.a2RevId.dbValues[0],
                dispValue: checkSheets[i].props.object_name.dbValues[0],
                propInternalValue: checkSheets[i].uid,
                iconName: "typeFormTask48"
            });
        }
        if (checkSheets.length) {
            data.sheetListBox.dbValue;
            uwPropertyService.setValue(data.sheetListBox, data.sheetListValues.dbValue[0].dbValue);
        }
    },
    //list SERIAL data once sheet is selected
    async getSerialList(data){
        let checkUid = data.sheetListBox.dbValue;
        let sheetModelObj = await AwcObjectUtil.getObject(checkUid); 
        let sheetId = sheetModelObj.props.a2Id.dbValues[0];
        let sheetRevId = sheetModelObj.props.a2RevId.dbValues[0];
        let serialData = [];

        const res = await AwcQueryUtil.executeSavedQuery("_Inspection_getSerial", [
            "A2CheckSheetId", "A2CheckSheetRevId"
        ], [ sheetId, sheetRevId ]);

        if (res) {
            await AwcObjectUtil.getProperties(res, ["a2SerialNumber", "a2IsDeleted"], true);
            for (const queryResult of res) {
                serialData.push({
                    seq: queryResult.props.object_name.dbValues[0],
                    serial: queryResult.props.a2SerialNumber.dbValues[0]
                });
            }
            serialData.sort((a,b) => a.seq > b.seq ? 1 : -1);
        }
        gridModule.renderSerialGrid({data: serialData});
    },
    async saveSerialList({data}, allSaveCheck) {
        SERIAL_GRID_INSTANCE.blur();
        const serialVal = SERIAL_GRID_INSTANCE.getData();
        let objType = "A2QInspectionSerial";
        let checkUid = data.sheetListBox.dbValue;
        let sheetModelObj = await AwcObjectUtil.getObject(checkUid);
        let sheetId = sheetModelObj.props.a2Id.dbValues[0];
        let sheetRevId = sheetModelObj.props.a2RevId.dbValues[0];
        let arr = new Array();
        let delData = { objects: [] };
        if( !serialVal.every( val => val.serial ) && serialVal.length > 0 ) {
            return false;
        }
        //if there are no list to save
        if(!serialVal.length){
            AwcQueryUtil.executeSavedQuery("_Inspection_getSerial", ["A2CheckSheetId", "A2CheckSheetRevId"], [sheetId, sheetRevId]).then( (response) => {
                if (response) {
                    AwcObjectUtil.getProperty(response, ["a2IsDeleted"], true).then ( async () => {
                        for(const uid of response.map(obj => obj.uid)){
                            delData.objects.push({uid});
                        }
                        soaService.post('Core-2006-03-DataManagement', 'deleteObjects', delData);
                    })
                    SERIAL_GRID_INSTANCE.resetData(serialVal);
                }
            })
        }
        //if there is a list to save
        serialVal.forEach( async (val) => {
            //search Query to get a2IsDeleted props to set it as "YES"
            AwcQueryUtil.executeSavedQuery("_Inspection_getSerial", ["A2CheckSheetId", "A2CheckSheetRevId"], [sheetId, sheetRevId]).then( async (res) => {
                AwcObjectUtil.getProperty(res, ["a2IsDeleted"], true).then(async () => {
                    for(let i = 0; i < res.length; i++){
                        //AwcObjectUtil.setProperty(res[i], "a2IsDeleted", isDel);
                        for(const uid of res.map(obj => obj.uid)){
                            delData.objects.push({uid});
                        }
                        soaService.post('Core-2006-03-DataManagement', 'deleteObjects', delData);
                    }
                })
                //create Objects after ascertain delete action from user
                arr.push( await AwcObjectUtil.createAttachAndSubmitObjects(
                    [
                        //object_name, #1, sheetId, sheetRevId
                        {a2SerialNumber: val.serial ? val.serial: ""},    
                        {object_name: val.seq},
                        {a2CheckSheetId: sheetId ? sheetId: ""},
                        {a2CheckSheetRevId: sheetRevId ? sheetRevId: ""}
                    ],
                    objType
                ) );
            })
        });
        if( !allSaveCheck ) {
            AwcNotificationUtil.show("INFO", locale.getLocalizedText(localeText, "inspResultSaveSuccess"));
        }
        return true;
    },
    async saveBedCode({data}){
        //when sheet is empty
        if(!data.sheetListBox.dbValue){
            alert("empty sheet");
        }
        const sheetUid = data.sheetListBox.dbValue; 
        const sheetModelObj = await AwcObjectUtil.getObject(sheetUid);
        const selectCode = CURRENT_MODE.includes( "prod" ) ? "a2DefectClass3Object" : "a2DefectClass2Object";
        await AwcObjectUtil.getProperty(sheetModelObj, selectCode );
        await AwcObjectUtil.setProperty(sheetModelObj, selectCode, data.bedCodeListBox.dbValue ? data.bedCodeListBox.dbValue : "" );

        //if user saves without no failure code data
        // if(sheetModelObj.props.a2FailureCode.dbValues[0] == null){
        //     // 
        // }
    },
    async saveGrid({data}) {
        SAMPLE_GRID_INSTANCE.blur();
        const gotSampleData = SAMPLE_GRID_INSTANCE.getData();
        const inputData = [];

        gotSampleData.forEach((v) => {
            const item = {
                objectInfo: {
                    uid: v.uid,
                    type: v.type,
                },
                data: [{
                    name: 'a2SampleSize',
                    value: String(v.sampleSize),
                }, {
                    name: 'a2FailureQty',
                    value: String(v.failureQty),
                }, {
                    name: 'object_desc',
                    value: v.description,
                }, {
                    name: 'a2NGQty',
                    value: String(v.NGQty),
                }, {
                    name: 'a2DefectClass1Object',
                    value: v.a2DefectClass1Object,
                }, {
                    name: 'a2DefectClass2Object',
                    value: v.a2DefectClass2Object,
                }, {
                    name: 'a2SPCResult',
                    value: v.spcResult,
                }, /* {
                    name: 'a2MeasureMachine',
                    value: v.a2MeasureMachine,
                } */],
            }

            if(CURRENT_MODE == "part" || CURRENT_MODE == "partPTR"){
                if(v.principal != "InSide"){
                    return;
                }
                item.data.push({
                    name: 'a2LGResult',
                    value: v.result,
                });
            }else{
                item.data.push({
                    name: 'a2Result',
                    value: v.result,
                },
                {
                    name: 'a2DefectClass3Object',
                    value: v.a2DefectClass3Object,
                });
            }

            const sampleKeys = Object.keys(v).filter(i => /^sample\d+$/.test(i));
            sampleKeys.forEach((i) => {
                item.data.push({
                    name: `a2D${i.match(/\d+/)[0].padStart(2, '0')}`,
                    value: v[i] === STRING.BLOCK ? STRING.EMPTY : v[i],
                })
            });
            inputData.push(item);
        });

        inputData.forEach(async (v) => {
            const names = [];
            const values = [];
            v.data.forEach((d) => {
                names.push(d.name) 
                values.push(d.value);
            });

            await AwcObjectUtil.setProperties4({
                uid: v.objectInfo.uid,
                type: v.objectInfo.type,
            }, names, values);
        });

        appCtxService.unRegisterCtx( "selectedItem" );
        appCtxService.unRegisterCtx( "selectedEle" );
    },
}

export async function removeRowSerialGrid() {
    const rowKey = SERIAL_GRID_INSTANCE.getRowCount()
    if (rowKey) {
        SERIAL_GRID_INSTANCE.removeRow(rowKey-1);
    }
}
export function addRowSerialGrid() {
    const rowKey = SERIAL_GRID_INSTANCE.getRowCount();
    SERIAL_GRID_INSTANCE.appendRow({
        seq: `#${rowKey + 1}`,
        serial: '',
    }, {
        focus: true,
    });
}
export function updateSampleExcelFile(fromData, data){
    if (fromData.value != ""){
        const reader = new FileReader();
        reader.onload = function (e) {
            const xlsx = require('xlsx');
            var data = e.target.result;
            var workbook = xlsx.read(data,{type:'binary'});
            const sheetName = workbook.SheetNames[0];
            const firstSheet = xlsx.utils.sheet_add_aoa(workbook.Sheets[sheetName], [gridModule.getExcelColumns({instance: SAMPLE_GRID_INSTANCE})], {origin: "A1"});
            let rows = gridModule.convertSampleData(xlsx.utils.sheet_to_json(firstSheet, {defval : ""}), true);
            if( !_.isArray( rows ) ) {
                AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, rows ) );
                return;
            } else {
                for (const index in rows) {
                    const row = rows[index];
                    const gridRow = SAMPLE_GRID_INSTANCE.getRow(index);
                    let sampleSize = parseInt(gridRow.sampleSize) <= MAX_SAMPLE_SIZE ? parseInt(gridRow.sampleSize) : MAX_SAMPLE_SIZE;
                    let principal = gridRow.principal;
                    for (const key of Object.keys(row)) {
                        let value = row[key];
                        if( (/^sample\d+$/.test(key) && sampleSize >= parseInt(key.replace(/[^0-9]/g, "")))/*  && principal == "InSide" */ ) {
                            if( CURRENT_MODE.includes( "part" ) && principal !== "InSide" ) continue;
                            if( row.insInputType === "Descrete" ) continue;
                            if( $.isNumeric(value) && row.insInputType === "Coutinuous" ){
                                let continousDigit = SAMPLE_GRID_INSTANCE.getRow(index).a2ContinousDigit;
                                let temp = 1;
                                for(let i = 0; i < continousDigit; i++){
                                    temp *= 10;
                                }
                                value *= temp;
                                value = Math.floor(value);
                                value /= temp;
                            }
                            SAMPLE_GRID_INSTANCE.setValue(index, key, String(value));
                        }
                    }
                    gridEvents.setFalseCountColumnFromSampleColumn({instance: SAMPLE_GRID_INSTANCE, rowKey: index});
                }
            }

            AwcNotificationUtil.show("INFO", locale.getLocalizedText(localeText, "inspResultUploadSuccess"));
            // gridEvents.setVisibleSampleColumns(SAMPLE_GRID_INSTANCE);
        }
        reader.readAsBinaryString(data.files[0]);
        appCtxService.ctx.HostedFileNameContext = undefined;
        document.getElementById('fileUploadForm').reset();
        data.files = {};
        data.fileName = undefined;
        data.fileNameNoExt = undefined;
        data.validFile = false;
    }
}
export function exportExcel() {
    let ctx = appCtxService.ctx;
    SAMPLE_GRID_INSTANCE.export('xlsx', {
        includeHiddenColumns: true,
        fileName: `${ctx.selected.props.a2InspTypeName.dbValues[0]}${locale.getLocalizedText("lgspQmsInspectionMessages", "sampleResult")}`,
        columnNames: gridModule.getExcelColumns({instance: SAMPLE_GRID_INSTANCE}),
    });
}
export async function saveBedCode(data){
    await resultModule.saveBedCode({data});
    AwcNotificationUtil.show("INFO", locale.getLocalizedText(localeText, "inspResultSaveSuccess"));
}
export async function saveSerialList(data) {
    if( !await resultModule.saveSerialList({data}, false) ) {
        AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "emptySNumber"));
    }
}
export async function saveSheet(data) {
    if( !await resultModule.saveSerialList({data}, true) ) {
        AwcNotificationUtil.show("ERROR", locale.getLocalizedText(localeText, "emptySNumber"));
        return;
    }
    await resultModule.saveGrid({data});
    await resultModule.saveSheetJudgment({data});
    await resultModule.saveReqJudgment({data});
    await resultModule.saveBedCode({data});
    FLAG_CHANGE = false;
    AwcNotificationUtil.show("INFO", locale.getLocalizedText(localeText, "inspResultSaveSuccess"));
}
export async function judgmentSheet(data) {
    resultModule.judgmentSheet({data});
}
export async function changedSheet(data, currentValue) {
    // currentValue => 선택된 체크시트 uid

    if (FLAG_CHANGE) {
        AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultChangeWithoutSave"), ['YES', 'NO'], [
            async () => {
                await changeSheet();
            },
            async (payload) => {
                // 
            }
        ]);
    } else {
        await changeSheet();
    }

    async function changeSheet() {
        await gridModule.destroySampleGrid();
        await gridModule.destroySerialGrid();

        const gridObjectDatas = []; 
        return INSP_REQ.getInspectionResultsBySheet(currentValue).then( async (inspectionResults) => {
            for (const inspectionResult of inspectionResults) {
                gridObjectDatas.push(resultModule.createGridRow(inspectionResult));
            }

            // gridObjectDatas.sort(resultModule.dynamicSort2("inspItem", "inspName"));
            gridObjectDatas.sort(function(a, b){
                //ASC
                if(a.index > b.index) return 1;
                if(a.index < b.index) return -1;
                if(a.principalDisp > b.principalDisp) return 1;
                if(a.principalDisp < b.principalDisp) return -1;
            });

            resultModule.getSavedSheetJudgment({data}, gridObjectDatas).then( () => {
                // BadCode => 체크 시트에 저장된 불량코드
                resultModule.getBedCodes( SAMPLE_GRID_INSTANCE ).then(() => {
                    // SavedSheetBadCode => 각 grid에 입력된 값 중 불합격 값
                    resultModule.getSavedSheetBedCode({data});
                    gridModule.renderSampleGrid({data: gridModule.convertSampleData(gridObjectDatas)}, false);
                    FLAG_CHANGE = false;
                });
            })
            resultModule.getSerialList(data);
        });
    }


    // if (FLAG_CHANGE) {
    //     await resultModule.saveGrid({data});
    //     await resultModule.saveSheetJudgment({data});
    //     await resultModule.saveBedCode({data});
    //     await resultModule.saveSerialList({data});
    //     FLAG_CHANGE = false;
    // }

    // gridModule.destroySampleGrid();
    // gridModule.destroySerialGrid();

    // return INSP_REQ.getInspectionResultsBySheet(currentValue).then( async (inspectionResults) => {
    //     for (const inspectionResult of inspectionResults) {
    //         gridObjectDatas.push(resultModule.createGridRow(inspectionResult));
    //     }
    //     gridObjectDatas.sort(resultModule.dynamicSort2("inspItem", "inspName"));
    //     resultModule.getSavedSheetJudgment({data}).then( () => {
    //         resultModule.getBedCodes().then(() => {
    //             resultModule.getSavedSheetBedCode({data});
    //             FLAG_CHANGE = false;
    //         });
    //     })
    //     resultModule.getSerialList(data);
    // });
}
export function setSuccessCheckedSample() {
    gridModule.setCheckedSample(JUDG.OK);
}
export function setFailCheckedSample() {
    gridModule.setCheckedSample(JUDG.NG);
}
export async function closePopup() {
    if (FLAG_CHANGE) {
        AwcNotificationUtil.show("WARNING", locale.getLocalizedText(localeText, "inspResultCloseWithoutSave"), ['YES', 'NO'], [
            async () => {
                await close();
            },
            async (payload) => {
                // 
            }
        ]);
    } else {
        await close();
    }

    async function close() {
        await gridModule.destroySampleGrid();
        await gridModule.destroySerialGrid();
        SAMPLE_GRID_INSTANCE = undefined;
        AwcPanelUtil.closePopup();
    }
}

export async function loaded(data, ctx) {
    FLAG_CHANGE = false;
    const intervalId = setInterval(async () => {
        if ( document.getElementById('sampleGrid') ) {
            
            clearInterval(intervalId);
            hideLeftPanel();

            INSP_REQ = new InspectionRequest(appCtxService.ctx.selected);
            const reqStatus = await INSP_REQ.getA2Status();
            if (reqStatus === 'Receipt') {
                EDIT_MODE = true;
            } else {
                EDIT_MODE = false;
            }
            data.editMode = EDIT_MODE;
            
            if (INSP_REQ.getModelObject()) {
                BAD_CODE_LIST_VALUES = data.bedCodeListValues;
                resultModule.setCurrentMode({reqModelObj:INSP_REQ.getModelObject()});
                
                await resultModule.setInspectionTemplateName(await INSP_REQ.getA2InspTypeName());
                await resultModule.setCheckSheet(data, await INSP_REQ.getCheckSheets());
                await resultModule.getResultLOV();
                await resultModule.getJudgLOV();
                await resultModule.getInputTypes();
                // await resultModule.getMeasureMachineLOV();
                await resultModule.getPrincipal();
                await resultModule.getSupplierStatus();
                await resultModule.getSupplierRequestList(data);
                // await resultModule.getBedCodes( SAMPLE_GRID_INSTANCE );
                
                // let controlPanelEl = document.getElementById('controlPanel');
                // controlPanelEl.setAttribute( "style", `height:${screen.height/1.3}px;` );
            }
        }
    } );
}

export const hideNGPanel = () => {
    $( "#rightVerticalSeparator" ).hide();
    $( "#NGCodePanel" ).hide();
    if( SAMPLE_GRID_INSTANCE ) {
        SAMPLE_GRID_INSTANCE.refreshLayout();
        SERIAL_GRID_INSTANCE.refreshLayout();
    }
}

export async function showLeftPanel() {
    $("#leftPanel").show();
    $("#leftVerticalSeparator").show();
    $("#btnHideLeftPanel").show();
    $("#btnShowLeftPanel").hide();
    if( SAMPLE_GRID_INSTANCE ) {
        SAMPLE_GRID_INSTANCE.refreshLayout();
        SERIAL_GRID_INSTANCE.refreshLayout();
    }
}

export async function hideLeftPanel() {
    $("#leftPanel").hide();
    $("#leftVerticalSeparator").hide();
    $("#btnHideLeftPanel").hide();
    $("#btnShowLeftPanel").show();
    if( SAMPLE_GRID_INSTANCE ) {
        SAMPLE_GRID_INSTANCE.refreshLayout();
        SERIAL_GRID_INSTANCE.refreshLayout();
    }
}

export async function openResultLink() {
    let ctx = appCtxService.ctx;
    let type = ctx.selected.type;
    let insHref = window.location.href;
    let newtestUrl = "qps-test.singlex.com/";
    //let newtestUrl = "http://lgsp:3001/";
    let detestUrl = "qps-detest.singlex.com/";
    let devUrl = "qps-dev.singlex.com/";
    let devToolUrl = "http://localhost:3001/";
    let urlParam = "";

    if (insHref.indexOf(devUrl) > -1 || insHref.indexOf(devToolUrl) > -1) {
        urlParam = "https://qms-dev.singlex.com/app/qp/limitset/main?contentOnly&limitSctnCode=";
    } else if (insHref.indexOf(detestUrl) > -1) {
        urlParam = "https://qms-lge-stg.singlex.com/app/qp/limitset/main?contentOnly&limitSctnCode=";
    } else if (insHref.indexOf(newtestUrl) > -1) {
        urlParam = "https://qms-lge-stg.singlex.com/app/qp/limitset/main?contentOnly&limitSctnCode=";
    } else {
        return;
    }

    if (type === "A2QPartIRItemRevision") {
        await AwcObjectUtil.getProperties(ctx.selected, ['a2SupplierString', 'a2PartString']);

        urlParam = urlParam.concat("PART&supplierCode=");
        urlParam = urlParam.concat(ctx.selected.props.a2SupplierString.dbValues[0] + "&progrsLevelCode=CUST_APPR,APPLY_APPR,NEED_REQ,LMT_APPR&schPartNo=");
        if (ctx.selected.props.a2PartString.dbValues.length === 0) {
            return;
        } else if (ctx.selected.props.a2PartString.dbValues.length === 1) {
            urlParam = urlParam.concat(ctx.selected.props.a2PartString.dbValues[0]);
        } else {

            let a2PartString = ctx.selected.props.a2PartString.dbValues;
            let urlString = "";
            for (let i = 0; i < a2PartString.length; i++) {
                if (i == a2PartString.length -1) {
                    urlString = urlString.concat(a2PartString[i]);
                } else {
                    urlString = urlString.concat(a2PartString[i] + ",");
                }
            }
            urlParam = urlParam.concat(urlString);
        }
    } else if (type === "A2QProdIRItemRevision") {
        await AwcObjectUtil.getProperty(ctx.selected, 'a2ModelSuffix');
        urlParam = urlParam.concat("PROD&progrsLevelCode=CUST_APPR,APPLY_APPR,NEED_REQ,LMT_APPR&schModelCode=");
        if (ctx.selected.props.a2ModelSuffix.dbValues.length === 0) {
            return;
        } else if (ctx.selected.props.a2ModelSuffix.dbValues.length === 1) { 
            urlParam = urlParam.concat(ctx.selected.props.a2ModelSuffix.dbValues[0]);
        } else {

            let modelSuffixs = ctx.selected.props.a2ModelSuffix.dbValues;
            let urlString = "";
            for (let i = 0; i < modelSuffixs.length; i++) {
                if (i == modelSuffixs.length -1) {
                    urlString = urlString.concat(modelSuffixs[i]);
                } else {
                    urlString = urlString.concat(modelSuffixs[i] + ",");
                }
            }
            urlParam = urlParam.concat(urlString);
        }
    } else {
        return;
    }
    window.open(urlParam);
    
}

export async function openSupplierPartInspRequest(data) {
    let supplierInspRequestId = data.a2SupplierRequestList.dbValue;
    let url = window.location.origin + "/#/com.siemens.splm.clientfx.tcui.xrt.showObject?pageId=tc_xrt_IRResultView&uid=" + supplierInspRequestId
    window.open(url);
}

export const saveBadCode = ( data ) => {
    
    SAMPLE_GRID_INSTANCE.setValue( appCtxService.ctx.selectedItem.rowKey, 'a2DefectClass1Object', data.a2DefectClass1Object.dbValue, false );
    SAMPLE_GRID_INSTANCE.setValue( appCtxService.ctx.selectedItem.rowKey, 'a2DefectClass2Object', data.a2DefectClass2Object.dbValue, false );
    if( CURRENT_MODE === "prod" || CURRENT_MODE == "prodPTR" ) {
        SAMPLE_GRID_INSTANCE.setValue( appCtxService.ctx.selectedItem.rowKey, 'a2DefectClass3Object', data.a2DefectClass3Object.dbValue, false );
        uwPropertyService.resetValues( data.a2DefectClass3Object );
    }
    uwPropertyService.resetValues( data.a2DefectClass1Object );
    uwPropertyService.resetValues( data.a2DefectClass2Object );
    resultModule.getBedCodes( SAMPLE_GRID_INSTANCE );
}

export const resetBadCode = async ( data, ctx ) => {
    
    let deleteArr = [ "a2DefectClass1Object", "a2DefectClass2Object", "a2DefectClass3Object" ];
    if( CURRENT_MODE.includes( "part") ) {
        deleteArr = deleteArr.filter( ( prop ) => {
            return prop !== "a2DefectClass3Object";
        } );
    }

    let row = SAMPLE_GRID_INSTANCE.getRow( appCtxService.ctx.selectedItem.rowKey );
    // let prevDef = row[ deleteArr[ deleteArr.length - 1 ] ];
    SAMPLE_GRID_INSTANCE.setValue( appCtxService.ctx.selectedItem.rowKey, "a2DefectClass1Object", "", false );
    SAMPLE_GRID_INSTANCE.setValue( appCtxService.ctx.selectedItem.rowKey, "a2DefectClass2Object", "", false );
    if( CURRENT_MODE.includes( "prod" ) ) {
        SAMPLE_GRID_INSTANCE.setValue( appCtxService.ctx.selectedItem.rowKey, "a2DefectClass3Object", "", false );
    }
    // const targetResult = AwcObjectUtil.getObject( SAMPLE_GRID_INSTANCE.store.data.rawData[ appCtxService.ctx.selectedItem.rowKey ].uid );

    // let soaInputParam = {
    //     info: [{
    //         object: targetResult,
    //         vecNameVal: [
    //         ]
    //     }]
    // };
    // for( const prop of deleteArr ) {
    //     soaInputParam.info[0].vecNameVal.push( { name:prop, values:[ "" ] } );
    // }
    // await soaService.post( 'Core-2010-09-DataManagement', 'setProperties', soaInputParam );
    resultModule.getBedCodes( SAMPLE_GRID_INSTANCE );

    // let sheet = AwcObjectUtil.getObject( data.sheetListBox.dbValue );
    // await AwcObjectUtil.getProperties( sheet, deleteArr );
    
    // if( prevDef === sheet.props[ deleteArr[ deleteArr.length - 1 ] ].dbValues[0] ) {
    //     soaInputParam.info[0].object = sheet;
    //     await soaService.post( 'Core-2010-09-DataManagement', 'setProperties', soaInputParam );
    // }
}

export default exports = {
    addRowSerialGrid,
    removeRowSerialGrid,
    updateSampleExcelFile,
    exportExcel,
    saveBedCode,
    saveSerialList,
    saveSheet,
    judgmentSheet,
    changedSheet,
    setSuccessCheckedSample,
    setFailCheckedSample,
    closePopup,
    loaded,
    showLeftPanel,
    hideLeftPanel,
    openResultLink,
    openSupplierPartInspRequest,
    hideNGPanel,
    saveBadCode,
    resetBadCode
}
app.factory('A2InspectionResultService', () => exports);