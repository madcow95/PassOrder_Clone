/**
 * QMSCommonService
 *
 * @module js/QMSCommonService
 */

 import app from 'app';
 import AwcObjectUtil from 'js/AwcObjectUtil';
 import locale from 'js/AwcLocalizationUtil';
 import AwcQueryUtil from 'js/AwcQueryUtil';
 import viewModelObjectSvc from 'js/viewModelObjectService';
 import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
 import eventBus from 'js/eventBus';
 import viewModelService from 'js/viewModelService';
 import soaService from 'soa/kernel/soaService';
 import AwcPanelUtil from 'js/AwcPanelUtil';
 import uwPropertyService from 'js/uwPropertyService';
 
 var exports = {};
 let localeText = "lgspQmsNewInspectionMessages";
 
 
 export async function createPTTreeFolder (data, ctx) {
     let createType = data.objCreateInfo.createType;
 
     let propertyPolicyOverride = {
             vAttachInfo: [
                 { typeName: createType, propName: 'a2Id' }
             ]
         };
     let pattern = await soaService.post( 'Core-2008-06-DataManagement', 'getNRPatternsWithCounters', propertyPolicyOverride );
     let a2Id = await AwcObjectUtil.getNextIds( createType, 'a2Id', pattern.patterns[0].patternStrings[0] );
     let a2Index = 10;
 
     let searchEntries = ["A2ParentId", "A2ParentRevId"];
     let a2ParentId = "";
     let a2ParentRevId = "";
     let a2QualityId = "";
     let a2QualityRevId = "";
     
     await AwcObjectUtil.getProperties(ctx.xrtSummaryContextObject, ["item_id", "item_revision_id", "a2Id", "a2RevId", "a2InspectionObject", "a2CheckSheetObject", "a2OrgCode", "a2ProdGroupCode", "a2PartGroupCode", "a2QualityId", "a2QualityRevId"]);
     
     if(createType.includes("CheckSheet")){
         a2ParentId = ctx.xrtSummaryContextObject.props.item_id.dbValue;
         a2ParentRevId = ctx.xrtSummaryContextObject.props.item_revision_id.dbValue;
         a2QualityId = a2ParentId;
         a2QualityRevId = a2ParentRevId;
     }else{
         a2ParentId = ctx.xrtSummaryContextObject.props.a2Id.dbValue;
         a2ParentRevId = ctx.xrtSummaryContextObject.props.a2RevId.dbValue;
         a2QualityId = ctx.xrtSummaryContextObject.props.a2QualityId.dbValue;
         a2QualityRevId = ctx.xrtSummaryContextObject.props.a2QualityRevId.dbValue;
     }
 
     let objArr = await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "contents", true);
     if(objArr.length > 0){
         objArr = AwcObjectUtil.getObjects(objArr);
         await AwcObjectUtil.getProperty(objArr, "a2Index");
         a2Index += Math.max.apply(Math, objArr.map(temp => temp.props.a2Index.dbValues[0]));
     }
     
     let a2InspectionObject = ctx.xrtSummaryContextObject.uid;
     if(!ctx.xrtSummaryContextObject.type.includes("PTItem")){
         await AwcObjectUtil.getProperties(ctx.xrtSummaryContextObject , ["a2InspectionObject"], true);
         a2InspectionObject =  ctx.xrtSummaryContextObject.props.a2InspectionObject.dbValues[0];
     }
 
     let properties = [
         {object_name: data.object_name.dbValue},
         {a2ParentId: a2ParentId},
         {a2ParentRevId: a2ParentRevId},
         {a2Id: a2Id},
         {a2Index: String(a2Index)},
         {a2InspectionObject: a2InspectionObject},
         {a2QualityId: a2QualityId},
         {a2QualityRevId: a2QualityRevId}
     ];
 
     let elem = document.getElementById("objNavTree");
     let declView = viewModelService.getViewModelUsingElement(elem);
     let selected = declView.dataProviders.objNavTreeDataProvider.selectedObjects[0];
     if(selected.type.includes("Sheet")) {
         await AwcObjectUtil.getProperties(selected, ["object_name", "a2Index"], false);
         properties.push({a2CheckSheetObject: selected.uid});
         // if(createType.includes("Item")) {
         //     properties.push({a2Group1: selected.props.object_name.dbValues[0]});
         //     properties.push({a2SortedIndex1: selected.props.a2Index.dbValues[0]});
         // }
     } else {
         if ( selected.props.a2CheckSheetObject &&  selected.props.a2CheckSheetObject.dbValues && selected.props.a2CheckSheetObject.dbValues.length > 0 ) {
             properties.push({a2CheckSheetObject: selected.props.a2CheckSheetObject.dbValues[0]});
         }
         if(createType.includes("Item")) {
             let uidPath = declView.dataProviders.objNavTreeDataProvider.selectionModel.getSelection()[0].split(",").reverse();
             uidPath = AwcObjectUtil.getObjects(uidPath);
             await AwcObjectUtil.getProperties(uidPath, ["object_name", "a2Index"], false);
             let j = 1;
             for(let i=2; i< uidPath.length; i++ ) {
                 let parent = uidPath[i]
                 let group = {};
                 group["a2Group" + j] = parent.props.object_name.dbValues[0];
                 properties.push(group);
                 let sortedIndex = {};
                 sortedIndex["a2SortedIndex" + j] = parent.props.a2Index.dbValues[0];
                 properties.push(sortedIndex);
                 j++;
             }
         }
     }
 
     if(createType.includes("CheckItem")){
         let lsl = data.a2Lsl.dbValue;
         let usl = data.a2Usl.dbValue;
         let targetValue = data.a2TargetValue.dbValue;
 
         if(data.a2InsInputType.dbValue == "Continuous"){
             let errMsg;
             if(lsl !== "" && usl !== "" && !(lsl < usl)){
                 errMsg = "invalidLslUsl";
             }else if(lsl !== "" && lsl > targetValue){
                 errMsg = "invalidLslTargetValue";
             }else if(usl !== "" && usl < targetValue){
                 errMsg = "invalidUslTargetValue";
             }
 
             if(errMsg){
                 AwcNotificiationUtil.show("WARNING", locale.getLocalizedText( "lgspQmsNewInspectionMessages", errMsg ));
                 return;
             }
         }
 
         properties.push({a2InsInputType: data.a2InsInputType.dbValue});
         properties.push({a2InsSpec: data.a2InsSpec.dbValue});
         properties.push({a2JudgeInitValue: data.a2JudgeInitValue.dbValue});
         properties.push({a2ConInitValue: String(data.a2ConInitValue.dbValue)});
         properties.push({a2ContinousDigit: String(data.a2ContinousDigit.dbValue)});
         properties.push({a2QContinuousUnit: data.a2QContinuousUnit.dbValue});
         properties.push({a2TargetValue: String(data.a2TargetValue.dbValue)});
         properties.push({a2Lsl: String(lsl)});
         properties.push({a2LslEmpty: String(lsl === "")});
         properties.push({a2Usl: String(usl)});
         properties.push({a2UslEmpty: String(usl === "")});
 
         if(createType == "A2QPartPTCheckItem"){
             properties.push({ a2Principal2: data.a2Principal2.dbValue });
         }
     }
     
     // 객체 생성
     AwcObjectUtil.createRuntimeObject(properties, createType).then( async (res) => {
         let object = null;
         for (const created of res.output[0].objects) {
             if (created.type == createType) {
                 object = created;
                 break;
             }
         }
         eventBus.publish( 'primaryWorkarea.reset' );
         eventBus.publish( "ObjectSet_1_Provider.plTable.reload");
         AwcPanelUtil.closeCommandPanel();
         return;
     }).catch( (e) => {
         AwcNotificiationUtil.show("INFO", e.message);
     });
 }
 
 export function openQPTPPanel(ctx, type) {
     if(type.includes("PTPCreateRuntime") && !ctx.pselected) {
         AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "createTestPlanFailed"));
         return; 
     }
     AwcPanelUtil.openCommandPanel(type);
 }
 
 export async function createQPTPPreAction(data, ctx) {
     let template;
     if(ctx.pselected.type == 'A2QProdPTItemRevision' || ctx.pselected.type == 'A2QPartPTItemRevision'){
         template = ctx.pselected;
     }else if(ctx.selected.type == 'A2QProdPTItemRevision' || ctx.selected.type == 'A2QPartPTItemRevision'){
         template = ctx.selected;
     }else{
         await AwcObjectUtil.getProperty(ctx.selected, "a2InspectionObject");
         template = await AwcObjectUtil.loadObjects(ctx.selected.props.a2InspectionObject.dbValues[0]);
     }
 
     await AwcObjectUtil.getProperties(template, ["object_string", "a2OrgCode", "a2ProdGroupCode"]);
     
     let temp = async function(data, ctx, template, type){
         if(data.a2TemplateType == null){
             setTimeout( () => {
                 temp(data, ctx, template, type);
             }, 10);
         }else{
             if(type == "A2QProdPTTempSearchObject"){
                 uwPropertyService.setValue(data.a2OrgCode, template.props.a2OrgCode.dbValues[0]);
                 uwPropertyService.setValue(data.a2ProdGroupCode, template.props.a2ProdGroupCode.dbValues[0]);
                 uwPropertyService.setWidgetDisplayValue(data.a2OrgCode, [template.props.a2OrgCode.dbValues[0]]);
                 uwPropertyService.setWidgetDisplayValue(data.a2ProdGroupCode, [template.props.a2ProdGroupCode.dbValues[0]]);
             }
             
             uwPropertyService.setValue(data.a2TemplateType, template.props.object_string.dbValues[0]);
             uwPropertyService.setValue(data.a2TestTemplateId, template.uid);
         }
     }
 
     temp(data, ctx, template, ctx.locationContext.modelObject.type);
 }
 
 export async function createQPTPAction(data, ctx) {
     let createType = data.objCreateInfo.createType;
     
     let testTempId = data.a2TestTemplateId.dbValue;
     let testTemp = AwcObjectUtil.getObject(testTempId);
     
     let object_name = testTemp.props.object_name.dbValues[0];
     let item_id = testTemp.props.item_id.dbValues[0];
     let item_revision_id = testTemp.props.item_revision_id.dbValues[0];
     let a2TemplateType = data.a2TemplateType.dbValue;/* item_id + "/" + item_revision_id + "-" + object_name; */
     let a2OrgCode = testTemp.props.a2OrgCode.dbValues[0];
 
     let props = [
         {a2TemplateType: a2TemplateType},
         {a2InspTypeName: object_name},
         {a2OrgCode: a2OrgCode}
     ];
     let searchArr = [];
     if(createType == "A2QProdPTPCreateRuntime"){
         let a2ProdGroupCode = data.a2ProdGroupCode.dbValue;
         let a2ModelSuffix = data.a2ModelSuffix.dbValue;
         let a2ModelName = data.a2ModelSuffix.uiValue;
         a2ModelName = a2ModelName.substr(a2ModelName.indexOf("/") + 1, a2ModelName.length);
 
         props.push({a2ModelSuffix: a2ModelSuffix});
         props.push({a2ModelName: a2ModelName});
         props.push({a2ProdGroupCode: a2ProdGroupCode});
         searchArr = [ "_Inspection_getProdPTPlan", ["a2SearchOrgCodeRT", "a2SearchProdGroupCodeRT", "a2SearchModelSuffixRT", "a2SearchTemplateTypeRT"], [a2OrgCode, a2ProdGroupCode, a2ModelSuffix, item_id ]];
         
     }else if(createType == "A2QPartPTPCreateRuntime"){
         let a2PartGroupCode = await AwcObjectUtil.getProperty(testTemp, "a2PartGroupCode", true);
         a2PartGroupCode = a2PartGroupCode[0];
         let SupplierString = data.a2SupplierString.dbValue;
         let PartString = data.a2PartString.dbValue;
         let partName = data.a2PartString.uiValue;
         let supplierName = data.a2SupplierString.uiValue;
         partName = partName.substr(partName.indexOf("/") + 1, partName.length);
         supplierName = supplierName.substr(supplierName.indexOf("/") + 1, supplierName.length);
 
         props.push({a2SupplierString: SupplierString});
         props.push({a2SupplierName: supplierName});
         props.push({a2PartString: PartString});
         props.push({a2PartName: partName});
         props.push({a2PartGroupCode: a2PartGroupCode});
         searchArr = [ "_Inspection_getPartPTPlan", ["a2SearchOrgCodeRT", "a2SearchPartGroupCodeRT", "a2SearchPartStringRT", "a2SearchSupplierStringRT", "a2SearchTemplateTypeRT"], [a2OrgCode, a2PartGroupCode, PartString, SupplierString, item_id ]];
     }
     
     await AwcQueryUtil.executeSavedQuery( searchArr[0], searchArr[1], searchArr[2] ).then( ( searchResult ) => {
         if( searchResult && searchResult.length > 0 ) {
             AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "existPlan"), ["Yes", "No"], [
                 () => {
                     AwcObjectUtil.createRuntimeObject(props, createType).then( async () => {
                         AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "testPlanCreateSuccess"));
                         AwcPanelUtil.closeCommandPanel();
                         return;
                     }).catch( (e) => {
                         AwcNotificiationUtil.show("INFO", e.message);
                     });
                 },
                 () => {}
             ])
         } else {
             AwcObjectUtil.createRuntimeObject(props, createType).then( async () => {
                 AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "testPlanCreateSuccess"));
                 AwcPanelUtil.closeCommandPanel();
                 return;
             }).catch( (e) => {
                 AwcNotificiationUtil.show("INFO", e.message);
             });
         }
     })
 }
 
 export function createQPTPSimPreAction(data, ctx) {
     let planKey = "a2ProdInspectionPlan";
     let typeKey = "a2ProductTypeId";
     let valueKey = "a2ProductTypeIdValues";
     let queryName = "_Inspection_getProdPTPlan";
     let serchEntries = ["a2SearchModelSuffixRT"];
     let searchValues = ["*"];
     let targetType = "A2QProdPTPItemRevision";
     if(data._internal.viewId == "A2QPartPTPSimCreateRuntime"){
         planKey = "a2PartInspectionPlan";
         typeKey = "a2PartTypeId";
         valueKey = "a2PartTypeIdValues"
         queryName = "_Inspection_getPartPTPlan";
         serchEntries = ["a2SearchPartStringRT", "a2SearchSupplierStringRT"];
         searchValues = ["*", "*"];
         targetType = "A2QPartPTPItemRevision";
         
     }
 
     if(data[planKey] == null){
         setTimeout( () => {
             createQPTPSimPreAction(data, ctx);
         }, 10 );
     }else{
         data[planKey] = data[typeKey];
         ctx[valueKey] = {
             "type": "STRING",
             "dbValue": [{
                 "propDisplayValue": "",
                 "propDisplayDescription": "",
                 "dispValue": "",
                 "propInternalValue": "",
                 "iconName": ""
             }]
         };
         
         AwcQueryUtil.executeSavedQuery(queryName,  serchEntries, searchValues).then( async (results) => {
             if(results) {
                 let LastedRevArr = [];
                 await AwcObjectUtil.getProperties(results, ["release_status_list"], true);
                 let sortedArray = [];
                 for (const sortElement of results) {
                     if( sortElement.type != targetType || sortElement.props.a2IsDeleted.dbValues[0] == "YES") continue;
                     if( sortElement.props.release_status_list.dbValues.length > 0 ) sortedArray.push( sortElement.props.items_tag.dbValues[0] );
                 }
                 LastedRevArr = await _getLatestRev( sortedArray );
                 LastedRevArr.sort(_dynamicSort2("item_id", "item_revision_id"));
                 for (const modelObject of LastedRevArr) {
                     let vmo = viewModelObjectSvc.constructViewModelObjectFromModelObject(modelObject);
                     let displayString = vmo.props.item_id.dbValues[0] + "/" + vmo.props.item_revision_id.dbValues[0];
                     var listBoxRow = {
                         "propDisplayValue": displayString,
                         "propDisplayDescription": vmo.props.object_name.dbValues[0],
                         "dispValue": displayString,
                         "propInternalValue": vmo.uid,
                         "iconName": "typeQcControlInspectionPlan48"
                     };
                     ctx[valueKey].dbValue.push(listBoxRow);
                 }
                 return;
             } else {
                 ctx[valueKey].dbValue = null;
             }
         });
     }
 }
 
 export async function createQPTPSimAction(data, ctx) {
     let createType = data.objCreateInfo.createType;
     let inspectionPlanUid = createType == "A2QProdPTPSimCreateRuntime" ? data.a2ProductTypeId.dbValue : data.a2PartInspectionPlan.dbValue;
     let inspectionPlan = await AwcObjectUtil.loadObjects(inspectionPlanUid);
      
     let inspId = inspectionPlan.props.item_id.dbValues[0];
     let inspRevId = inspectionPlan.props.item_revision_id.dbValues[0];
     let a2TemplateType = new String();
     let props = [];
     let searchArr = [];

     if(data.objCreateInfo.createType == "A2QProdPTPSimCreateRuntime"){
         await AwcObjectUtil.getProperties(inspectionPlan, ["a2ModelSuffix", "a2ModelName", "a2InspTypeName", "a2TemplateType", "a2OrgCode", "a2ProdGroupCode"], true);
         let a2ModelSuffix = data.a2ModelSuffix.dbValue;
         let a2ModelName = data.a2ModelSuffix.selectedLovEntries[0].propDisplayDescription;
         let inspName = `[${ inspectionPlan.props.a2InspTypeName.dbValues[0] }] ${ a2ModelSuffix } ${ locale.getLocalizedText(localeText, "inspPlan") }`;
         a2TemplateType = inspId + "/" + inspRevId + "-" + inspName;
         let a2OrgCode = inspectionPlan.props.a2OrgCode.dbValues[0] ? inspectionPlan.props.a2OrgCode.dbValues[0] : "";
         let a2ProdGroupCode = inspectionPlan.props.a2ProdGroupCode.dbValues[0] ? inspectionPlan.props.a2ProdGroupCode.dbValues[0] : "";
         props = [
             {a2ModelSuffix: a2ModelSuffix}, 
             {a2ModelName:  a2ModelName}, 
             {a2TemplateType: a2TemplateType},
             {a2InspTypeName: inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : ""},
             {a2OrgCode: a2OrgCode},
             {a2ProdGroupCode: a2ProdGroupCode},
             {a2ProdInspectionPlan: inspectionPlan.props.item_id.dbValues[0] + "/" + inspectionPlan.props.item_revision_id.dbValues[0] + "-" +  inspectionPlan.props.object_name.dbValues[0]}
         ];

         searchArr = [ "_Inspection_getProdPTPlan", ["a2SearchOrgCodeRT", "a2SearchProdGroupCodeRT", "a2SearchModelSuffixRT", "a2SearchTemplateTypeRT"], [a2OrgCode, a2ProdGroupCode, a2ModelSuffix, inspectionPlan.props.a2TemplateType.dbValues[0] ]];

     }else if(data.objCreateInfo.createType == "A2QPartPTPSimCreateRuntime"){
         await AwcObjectUtil.getProperties(inspectionPlan, ["a2SupplierString", "a2SupplierName", "a2TemplateType", "a2InspTypeName", "a2OrgCode", "a2PartGroupCode", "a2PartString", "a2PartName"], true);
         let a2PartString = data.a2PartString.dbValue;
         let a2PartName = data.a2PartString.selectedLovEntries[0].propDisplayDescription;
         let a2SupplierString = data.a2SupplierString.dbValue;
         let a2SupplierName = data.a2SupplierString.selectedLovEntries[0].propDisplayDescription;
         let inspName = `[${ inspectionPlan.props.a2InspTypeName.dbValues[0] }] ${ a2PartString }(${ a2SupplierString }) ${ locale.getLocalizedText(localeText, "inspPlan") }`;
         a2TemplateType = inspId + "/" + inspRevId + "-" + inspName;
         let a2OrgCode = inspectionPlan.props.a2OrgCode.dbValues[0] ? inspectionPlan.props.a2OrgCode.dbValues[0] : "";
         let a2PartGroupCode = inspectionPlan.props.a2PartGroupCode.dbValues[0] ? inspectionPlan.props.a2PartGroupCode.dbValues[0] : "";
         props = [
             {a2SupplierString: a2SupplierString},
             {a2SupplierName: a2SupplierName},
             {a2TemplateType: a2TemplateType},
             {a2InspTypeName: inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : ""},
             {a2OrgCode: inspectionPlan.props.a2OrgCode.dbValues[0] ? inspectionPlan.props.a2OrgCode.dbValues[0] : ""},
             {a2PartString: a2PartString},
             {a2PartName: a2PartName},
             {a2PartGroupCode: inspectionPlan.props.a2PartGroupCode.dbValues[0] ? inspectionPlan.props.a2PartGroupCode.dbValues[0] : ""},
             {a2PartInspectionPlan: inspectionPlan.props.item_id.dbValues[0] + "/" + inspectionPlan.props.item_revision_id.dbValues[0] + "-" +  inspectionPlan.props.object_name.dbValues[0]}
         ]

         searchArr = [ "_Inspection_getPartPTPlan", ["a2SearchOrgCodeRT", "a2SearchPartGroupCodeRT", "a2SearchPartStringRT", "a2SearchSupplierStringRT", "a2SearchTemplateTypeRT"], [a2OrgCode, a2PartGroupCode, a2PartString, a2SupplierString, inspectionPlan.props.a2TemplateType.dbValues[0] ] ];
     }

     await AwcQueryUtil.executeSavedQuery( searchArr[0], searchArr[1], searchArr[2] ).then( ( searchResult ) => {
        if( searchResult && searchResult.length > 0 ) {
            AwcNotificiationUtil.show( "INFO", locale.getLocalizedText(localeText, "existPlan"), ["Yes", "No"], [
                () => {
                    AwcObjectUtil.createRuntimeObject(props, createType).then( async () => {
                        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "testPlanCreateSuccess"));
                        AwcPanelUtil.closeCommandPanel();
                        return;
                    }).catch( (e) => {
                        AwcNotificiationUtil.show("INFO", e.message);
                    });
                },
                () => {}
            ])
        } else {
            AwcObjectUtil.createRuntimeObject(props, createType).then( async () => {
                AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "testPlanCreateSuccess"));
                AwcPanelUtil.closeCommandPanel();
                return;
            }).catch( (e) => {
                AwcNotificiationUtil.show("INFO", e.message);
            });
        }
    });
 }
 
 export function  A2QPTPCheckItemCreate() {
     AwcPanelUtil.openCommandPanel("A2QPTPCheckItemCreate");
 }
 
 export async function initPTPCheckItem(data,ctx){
     await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "contents");
     let contents = AwcObjectUtil.getObjects(ctx.xrtSummaryContextObject.props.contents.dbValue);
     await AwcObjectUtil.getProperty(contents, "object_name");
 
     for(let obj of contents) {
         var listBoxRow = {
             "propDisplayValue": obj.props.object_name.dbValues[0],
             "propDisplayDescription": obj.props.object_name.dbValues[0],
             "dispValue": obj.props.object_name.dbValues[0],
             "propInternalValue": obj.uid,
             "iconName": "typeProductModelGroup48"
         };
         data.a2CheckSheetValues.dbValue.push(listBoxRow);
     }
 }
 
 export async function createPTPCheckItem(data, ctx){
     let lsl = data.a2Lsl.dbValue;
     let usl = data.a2Usl.dbValue;
     let targetValue = data.a2TargetValue.dbValue;
 
     if(data.a2InsInputType.dbValue == "Continuous"){
         let errMsg;
         if(lsl !== "" && usl !== "" && !(lsl < usl)){
             errMsg = "invalidLslUsl";
         }else if(lsl !== "" && lsl > targetValue){
             errMsg = "invalidLslTargetValue";
         }else if(usl !== "" && usl < targetValue){
             errMsg = "invalidUslTargetValue";
         }
 
         if(errMsg){
             AwcNotificiationUtil.show("WARNING", locale.getLocalizedText( "lgspQmsNewInspectionMessages", errMsg ));
             return;
         }
     }
 
     let createType = data.objCreateInfo.createType == "A2QProdPTCheckItem" ? "A2QProdPTPCheckItem" : "A2QPartPTPCheckItem";
 
     let propertyPolicyOverride = {
         vAttachInfo: [
             { typeName: createType, propName: 'a2Id' }
         ]
     };
 
     let pattern = await soaService.post('Core-2008-06-DataManagement', 'getNRPatternsWithCounters', propertyPolicyOverride);
     let a2Id = await AwcObjectUtil.getNextIds(createType, 'a2Id', pattern.patterns[0].patternStrings[0]);
     let workingDBArr = await AwcObjectUtil.getProperty(ctx.xrtSummaryContextObject, "a2WorkingView", true);
 
     let array = [];
     let indexArr = [];
     workingDBArr.forEach( ( uid, i ) => {
         array.push( AwcObjectUtil.getObject( uid ) );
         indexArr.push( Number( array[i].props.a2Index.dbValues[0] ) );
     });
 
     let max = null;
     if( indexArr.length > 0 ) {
         max = indexArr.reduce( ( previous, current ) => {
             return previous > current ? previous : current;
         });
     }
 
     let checkSheet = await AwcObjectUtil.getObject(data.a2CheckSheet.dbValue);
     await AwcObjectUtil.getProperties(checkSheet, ["a2InspTypeName", "a2InspectionObject", "a2CheckSheetObject", "a2Id", "a2RevId"]);
 
     let props = [
         { object_name: data.object_name.dbValues[0] },
         { a2InsInputType: data.a2InsInputType.dbValues[0] },
         { a2InsSpec: data.a2InsSpec.displayValues[0] },
         { a2JudgeInitValue: data.a2JudgeInitValue.dbValues[0] },
         { a2ConInitValue: data.a2ConInitValue.displayValues[0] },
         { a2ContinousDigit: data.a2ContinousDigit.displayValues[0] },
         { a2QContinuousUnit: data.a2QContinuousUnit.dbValues[0] },
         { a2TargetValue: data.a2TargetValue.displayValues[0] },
         { a2Lsl: data.a2Lsl.displayValues[0] },
         { a2LslEmpty: String(data.a2Lsl.dbValue === "")},
         { a2Usl: data.a2Usl.displayValues[0] },
         { a2UslEmpty: String(data.a2Usl.dbValue === "")},
         { a2CheckSheetObject: checkSheet.uid },
         { a2InspectionObject: ctx.xrtSummaryContextObject.uid },
         { a2Index: String( max + 10 ) },
         { a2ParentId: checkSheet.props.a2Id.dbValues[0] },
         { a2ParentRevId: checkSheet.props.a2RevId.dbValues[0] },
         { a2Id: a2Id }
     ];
 
     // 생성시 선택한 Check Sheet가 a2Group1 속성에 들어가야한다.
     if(createType == "A2QPartPTPCheckItem"){
         props.push(
             { a2Principal2: data.a2Principal2.dbValue }
         );
     }
 
     AwcObjectUtil.createRuntimeObject(props, createType).then( ( res ) => {
         let table = document.getElementById( "ObjectSet_1_Provider" );
         let table2 = viewModelService.getViewModelUsingElement( table );
         let vmCol = table2.dataProviders.ObjectSet_1_Provider.viewModelCollection.loadedVMObjects;
         vmCol.sort( ( a, b ) => {
             return Number( a.props.a2Index.dbValues[0] ) - Number( b.props.a2Index.dbValues[0] );
         });
         AwcPanelUtil.closeCommandPanel();
         eventBus.publish( 'primaryWorkarea.reset' );
     });
 }
 
 export function createPartPTRPreAction(data, ctx) {
     if(data.a2InspectionPlan == null){
         setTimeout( () => {
             createPartPTRPreAction(data, ctx);
         }, 10 );
     } else{
         data.a2InspectionPlan = data.a2PartInspectionPlanListBox;
     }
 }
 
 export async function validateRelease(ctx){
     let workflowName;
     let obj = ctx.xrtSummaryContextObject
     let type = obj.type;
     let errMsg;
     let attachCount;
     let attachmentTypes;
     let attachments = [];
 
     let validationProperties = ["a2Plant", "a2LOTQty_1", "a2QLotNo", "a2DueDate", "HasParticipant"];
     await AwcObjectUtil.getProperties( obj, validationProperties );
 
     if(AwcObjectUtil.isReleased(obj)) {
         errMsg = locale.getLocalizedText(localeText, "ApprovalAlreadyCompleted");
 
     }else if(AwcObjectUtil.isInProcess(obj)) {
         errMsg = locale.getLocalizedText("A2ChangeLocalizationMessages", "ActionInprogressError");
 
     }else if(obj.props.HasParticipant.dbValues.length <= 0) {
         errMsg = locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed") + "\n" + locale.getLocalizedText("lgspQmsNewInspectionMessages", "NoParticipants");
 
     }else if(type == "A2QProdPTPItemRevision" || type == "A2QPartPTPItemRevision"){
         attachCount = 1;
         attachmentTypes = [ 1 ];
         workflowName = "[QMS] Approve Test Plan";
         attachments = [ ctx.xrtSummaryContextObject.uid ]
         await AwcObjectUtil.getProperty(obj, ["a2SeverityLevel", "a2WorkingView"]);
         let a2WorkingView = AwcObjectUtil.getObjects(obj.props.a2WorkingView.dbValue);
         let sampleMethodList = a2WorkingView.map(obj => obj.props.a2SampleMethod.dbValues[0]);
         
         if(sampleMethodList.includes(null)){
             errMsg = locale.getLocalizedText(localeText, "EnterSampleMethod");
         }else if(sampleMethodList.includes("AQL") && !obj.props.a2SeverityLevel.dbValue){
             errMsg = locale.getLocalizedText(localeText, "EnterSeverity");
         }
         
        let targetRangeList = a2WorkingView.map( ( obj ) => {
            if( obj.props.a2InsInputType.dbValues[0] === "Continuous" && !obj.props.a2TargetRange.dbValues[0] ) {
                return obj;
            }
        } );
        targetRangeList = targetRangeList.filter( obj => obj !== undefined );
        if( targetRangeList.length > 0 ) {
            AwcNotificiationUtil.show("ERROR", locale.getLocalizedText( localeText, "NoEnterTargetRange" ) );
            return;
        }
 
     }else if( type == "A2QProdPTRItemRevision" ){
         
         attachCount = 1;
         attachmentTypes = [ 1 ];
         workflowName = "[QMS] Approve Test Request";
         attachments = [ ctx.xrtSummaryContextObject.uid ]
         let validationProperties = ["a2Plant", "a2LOTQty_1", "a2QLotNo", "a2DueDate"];
         await AwcObjectUtil.getProperty(obj, validationProperties);
 
         let properties = [];
         for (const propName of validationProperties) {
             if ( !obj.props[propName].dbValues || !obj.props[propName].dbValues.length > 0 || !obj.props[propName].dbValues[0] ) {
                 properties.push(obj.props[propName].propertyDisplayName);
             }
         }
 
         if(properties.length > 0) {
             errMsg = locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed") + "\n" + locale.getLocalizedText("lgspQmsNewInspectionMessages", "NecessaryPropertyMissing") + "\n" + properties.join(" ");
         }
     } else if( type == "A2QPartPTRItemRevision" ) {
        
        let properties = [];
        for (const propName of validationProperties) {
            if ( !obj.props[propName].dbValues || !obj.props[propName].dbValues.length > 0 || !obj.props[propName].dbValues[0] ) {
                properties.push(obj.props[propName].propertyDisplayName);
            }
        }

        if(properties.length > 0) {
            errMsg = locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed") + "\n" + locale.getLocalizedText("lgspQmsNewInspectionMessages", "NecessaryPropertyMissing") + "\n" + properties.join(" ");
        }

         await AwcObjectUtil.getProperties( ctx.xrtSummaryContextObject, [ "a2PartString", "a2PartName" ] );
         let inputData = {
             infos: [{
                 itemId: ctx.xrtSummaryContextObject.props.a2PartString.dbValues[0],
                 revIds: [ "00" ],  
             }],
             nRev: 0,
             pref: {
                 prefs: [{
                     relationTypeName: "",
                     objectTypeNames: [""]
                 }]
             }
         }
         let partObj = await soaService.post( "Core-2007-01-DataManagement", "getItemFromId", inputData );
         attachCount = 2;
         attachmentTypes = [ 1, 3 ];
         workflowName = "[QMS] Approve Test Request";
         attachments = [ ctx.xrtSummaryContextObject.uid, partObj.output[0].itemRevOutput[0].itemRevision.uid ]
     }

     if(errMsg){
         AwcNotificiationUtil.show("WARNING", errMsg);
         return false;
     }
 
     return {
         workflowName : workflowName,
         attachCount : attachCount,
         attachmentTypes : attachmentTypes,
         attachments : attachments
     };
 }
 
 export async function A2QPTItemRevisionRelease(data, ctx){
 
     let workflowData = await validateRelease( ctx );
 
     if(!workflowData.workflowName) return;
 
     let soaInputParam = {
         name: workflowData.workflowName,
         description: " ",
         contextData:{
             attachmentCount : workflowData.attachCount,
             attachments: workflowData.attachments,
             processTemplate : workflowData.workflowName,
             attachmentTypes : workflowData.attachmentTypes,
         }
     }
     await AwcObjectUtil.setProperty( ctx.xrtSummaryContextObject, "a2Requester", ctx.user.uid );
     soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( ()=>{
         AwcNotificiationUtil.show("INFO", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateSuccess"))
     }).catch( (e) => {
         AwcNotificiationUtil.show("ERROR", locale.getLocalizedText("A2InspectionLocalizationMessages", "WorkflowCreateFailed")+"\n"+e.message);
     }).finally( () => {
         eventBus.publish('cdm.relatedModified', {
             refreshLocationFlag: true,
             relatedModified: [ctx.xrtSummaryContextObject]
         });
     });
 }
 
 export function A2ModelSuffixChanged(data, ctx) {
     uwPropertyService.setDisplayValue( data.a2ModelSuffix, [ data.a2ModelSuffix.dbValues[0] + "/" + data.a2ModelSuffix.selectedLovEntries[0].propDisplayDescription ] );
     uwPropertyService.setWidgetDisplayValue( data.a2ModelSuffix, [ data.a2ModelSuffix.dbValues[0] + "/" + data.a2ModelSuffix.selectedLovEntries[0].propDisplayDescription ] );
     ctx.a2InspectionPlanListBoxValues = {
         "type": "STRING",
         "dbValue": [{
             "propDisplayValue": "",
             "propDisplayDescription": "",
             "dispValue": "",
             "propInternalValue": "",
             "iconName": ""
         }]
     };
     
     AwcQueryUtil.executeSavedQuery("_Inspection_getProdPTPlan", 
         ["a2SearchModelSuffixRT"], 
         [data.a2ModelSuffix.dbValue]
     ).then( async (results) => {
         if(results) {
             let LastedRevArr = [];
             await AwcObjectUtil.getProperties(results, ["release_status_list", "a2LatestYNRT"], true);
             let sortedArray = [];
             for (const sortElement of results) {
                 if( sortElement.type != "A2QProdPTPItemRevision" || sortElement.props.a2IsDeleted.dbValues[0] == "YES") continue;
                 if( sortElement.props.release_status_list.dbValues.length > 0 ) sortedArray.push(sortElement.props.items_tag.dbValues[0]);
             }
             LastedRevArr = await _getLatestRev( sortedArray );
             LastedRevArr.sort(_dynamicSort2("item_id", "item_revision_id"));
             
             for (const modelObject of LastedRevArr) {
                 let vmo = viewModelObjectSvc.constructViewModelObjectFromModelObject(modelObject);
                 let displayString = vmo.props.item_id.dbValues[0] + "/" + vmo.props.item_revision_id.dbValues[0];
                 var listBoxRow = {
                     "propDisplayValue": displayString,
                     "propDisplayDescription": vmo.props.object_name.dbValues[0],
                     "dispValue": displayString,
                     "propInternalValue": vmo.uid,
                     "iconName": "typeQcControlInspectionPlan48"
                 };
                 ctx.a2InspectionPlanListBoxValues.dbValue.push(listBoxRow);
             }
             return;
         }
     });
 }
 
 export function a2PartPTRPropChanged(data, ctx, propName) {
     if( data[propName].dbValue ) {
         uwPropertyService.setDisplayValue( data[propName], [ data[propName].dbValues[0] + "/" + data[propName].selectedLovEntries[0].propDisplayDescription ] );
         uwPropertyService.setWidgetDisplayValue( data[propName], [ data[propName].dbValues[0] + "/" + data[propName].selectedLovEntries[0].propDisplayDescription ] );
     } else {
         uwPropertyService.setDisplayValue( data[propName], [ ""] );
         uwPropertyService.setWidgetDisplayValue( data[propName], [ "" ] );
         ctx.a2PartInspectionPlanListBoxValues.dbValue = "";
     }
 
     if( data.a2PartString.dbValue && data.a2SupplierString.dbValue ) {
         ctx.a2PartInspectionPlanListBoxValues = {
             "type": "STRING",
             "dbValue": [{
                 "propDisplayValue": "",
                 "propDisplayDescription": "",
                 "dispValue": "",
                 "propInternalValue": "",
                 "iconName": ""
             }]
         };
         
         AwcQueryUtil.executeSavedQuery("_Inspection_getPartPTPlan", 
             ["a2SearchPartStringRT", "a2SearchSupplierStringRT"], 
             [data.a2PartString.dbValue == null ? "*" : data.a2PartString.dbValue , data.a2SupplierString.dbValue == null ? "*" : data.a2SupplierString.dbValue]
         ).then( async (results) => {
             if(results) {
                 let LastedRevArr = [];
                 await AwcObjectUtil.getProperties(results, ["release_status_list", "a2LatestYNRT", "a2IsDeleted"], true);
                 let sortedArray = [];
                 for (const sortElement of results) {
                     if( sortElement.type != "A2QPartPTPItemRevision" || sortElement.props.a2IsDeleted.dbValues[0] == "YES") continue;
                     if( sortElement.props.release_status_list.dbValues.length > 0 ) sortedArray.push( sortElement.props.items_tag.dbValues[0] );
                 }
                 LastedRevArr = await _getLatestRev( sortedArray );
                 LastedRevArr.sort(_dynamicSort2("item_id", "item_revision_id"));
                 for (const modelObject of LastedRevArr) {
                     let vmo = viewModelObjectSvc.constructViewModelObjectFromModelObject(modelObject);
                     let displayString = vmo.props.item_id.dbValues[0] + "/" + vmo.props.item_revision_id.dbValues[0];
                     var listBoxRow = {
                         "propDisplayValue": displayString,
                         "propDisplayDescription": vmo.props.object_name.dbValues[0],
                         "dispValue": displayString,
                         "propInternalValue": vmo.uid,
                         "iconName": "typeQcControlInspectionPlan48"
                     };
                     ctx.a2PartInspectionPlanListBoxValues.dbValue.push(listBoxRow);
                 }
                 return;
             }
         });
     }
 }
 
 let _getLatestRev = async ( rev ) => {
     let itemsUidArrSet = new Set( rev );
     let itemsUidArr = [...itemsUidArrSet]
     let itemsArr = new Array();
     let returnArr = new Array();
 
     itemsUidArr.forEach( ( uid ) => {
         itemsArr.push( AwcObjectUtil.getObject( uid ) );
     });
 
     await AwcObjectUtil.getProperty( itemsArr, "revision_list" );
     itemsArr.forEach( ( item ) => {
         let arrIndex = item.props.revision_list.dbValues.length > 1 ? item.props.revision_list.dbValues.length - 2 : item.props.revision_list.dbValues.length - 1;
         returnArr.push( AwcObjectUtil.getObject( item.props.revision_list.dbValues[ arrIndex ] ) );
     });
     return returnArr;
 }
 
 function _dynamicSort2(property1, property2) {
     var sortOrder = 1;
     if(property1[0] === "-") {
         sortOrder = -1;
         property1 = property1.substr(1);
     }
     return function (a,b) {
         /* next line works with strings and numbers, 
          * and you may want to customize it to your needs
          */
         var result = (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  < b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? -1 : (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  > b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? 1 : 0;
         return result * sortOrder;
     }
 }
 
 export async function createQPTRAction(data, ctx) {
     let createType = data.objCreateInfo.createType;
     let a2InspectionPlan = data.a2InspectionPlan.dbValue;       //검사 기준
 
     let inspectionPlan = await AwcObjectUtil.loadObjects(a2InspectionPlan);
     await AwcObjectUtil.getProperties(inspectionPlan, ["a2ModelSuffix", "a2InspTypeName", "a2TemplateType", "a2SeverityLevel", "a2BasedOnId"], true);
     let inspTypeName = inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : "";
     let basedOnId = inspectionPlan.props.a2BasedOnId.dbValues[0];
     let templateType = basedOnId.substring(0, basedOnId.indexOf("/"));
 
     let props = [
         {a2TemplateType: templateType},
         {a2InspTypeName: inspTypeName},
         {a2InspectionPlan: a2InspectionPlan}
     ];
 
     if(createType == "A2QProdPTRCreateRuntime"){
         props.push({a2ModelSuffix: data.a2ModelSuffix.dbValue ? data.a2ModelSuffix.dbValue : ""});
         props.push({a2RequestName: "[" +  inspTypeName +"]" + " " + data.a2ModelSuffix.dbValue + " 시험의뢰"});
     }else if(createType == "A2QPartPTRCreateRuntime"){
         props.push({a2PartString: data.a2PartString.dbValues[0]});
         props.push({a2SupplierString: data.a2SupplierString.dbValues[0]});
     }
 
     AwcObjectUtil.createRuntimeObject(props, createType).then( async (res) => {
         AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRCreateRuntimeSuc"));
         AwcPanelUtil.closeCommandPanel();
         
         let viewModelElement = document.getElementById('inspectionRequestHeader');
         let viewModel = viewModelService.getViewModelUsingElement(viewModelElement);   //테이블명으로 vmo 가져오기
         // cosole.log(viewModel);
     }).catch( (e) => {
         // cosole.log(e);
     })
 }
 
 export function testResultOpen(data, ctx) {
     //validation추가. 생성, 대기 완료일때 검색 의뢰 결과창X
     if( !ctx.selected.props.a2Status ) {
         AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "SPCNoSelectResult"));
         return false;
     }
     let myStatus = ctx.selected.props.a2Status.dbValue;
     if ( myStatus == "Create" ) {
         AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidCreateStatus"));
     } else if ( myStatus == "Stand By" ){
         AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidStandStatus"));
     } else if ( myStatus == "Reject" ){
         AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidRejectStatus"));
     } else {
         AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);
     }
 }
 
 export function testRequestConfirm(data, ctx) {
     let selected = ctx.selected;
     if( selected.type != "A2QProdPTRItemRevision" && selected.type != "A2QPartPTRItemRevision" ) {
         AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "PTRTypeInvalid"));
         return;
     }
     if( selected.props.a2Status.dbValues[0] != "Receipt" ) {
         AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "PTRStatusInvalid"));
         return;
     }
     if( selected.props.a2Result.dbValues[0] != "OK" && selected.props.a2Result.dbValues[0] != "NG" ) {
         AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "PTRResultInvalid"));
         return;
     }
     AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "PTRConfirmCheck"), ["YES", "NO"], 
     [
         function() {
             AwcObjectUtil.getProperty(ctx.selected, "HasParticipant").then( () => {
                 if(ctx.selected.props.HasParticipant.dbValues.length > 0) {
                     let soaInputParam = {
                         name: "[QMS] Confirm Test Request",
                         description: " ",
                         contextData:{
                             attachmentCount : 1,
                             attachments: [ctx.selected.uid],
                             processTemplate : "[QMS] Confirm Test Request",
                             attachmentTypes : [1],
                         }
                     }
                     soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( (e)=>{
                         AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "PTRConfirmSuccess"));
                         // cosole.log(e);
                     }).catch( (e) => {
                         AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "PTRConfirmFailed") +"\n"+e.message);
                     }).finally( () => {
                         eventBus.publish('cdm.relatedModified', {
                             refreshLocationFlag: true,
                             relatedModified: [ctx.selected]
                         });
                         return;
                     }); 
                 } else {
                     AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "PTRConfirmFailed") +"\nThere's no participants in this test request.");
                     return;
                 }
             })
         },
         function() {
             AwcPanelUtil.closeCommandPanel();
             AwcPanelUtil.closePopup();
         }
     ]);
     return;
 }
 
 export default exports = {
     createPTTreeFolder,
     openQPTPPanel,
     createQPTPPreAction,
     createQPTPAction,
     createQPTPSimPreAction,
     createQPTPSimAction,
     A2QPTPCheckItemCreate,
     initPTPCheckItem,
     createPTPCheckItem,
     createPartPTRPreAction,
     A2QPTItemRevisionRelease,
     A2ModelSuffixChanged,
     a2PartPTRPropChanged,
     createQPTRAction,
     testResultOpen,
     testRequestConfirm
 };
 app.factory('A2QPTItemService', () => exports);