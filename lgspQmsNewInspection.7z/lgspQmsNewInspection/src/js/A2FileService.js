import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import appCtxService from 'js/appCtxService';
import locale from 'js/AwcLocalizationUtil';
import _ from 'lodash';
import AwPromiseService from 'js/awPromiseService';
import soaService from 'soa/kernel/soaService';
import uwPropertyService from 'js/uwPropertyService';
import AwcNotificationUtil from 'js/AwcNotificiationUtil'
import $ from 'jquery';

var exports = {};
let localeText = "lgspQmsNewInspectionMessages";


/**
 *  업로드 파일 커맨드 패널을 여는 함수
 */
export function openFilePanel( data, ctx ){
    AwcPanelUtil.openCommandPanel("A2UploadFile");
    retrieveSpecFile();
}

export function openFilePanel2( data, ctx ){ // 추후 삭제 by 임해철
    AwcPanelUtil.openCommandPanel("A2UploadFile2");
    retrieveSpecFile();
}

/**
 * 업로드 하기 위해서 첨부한 파일을 삭제하는 함수.
 * 서버에 업로드 하기 전 시점에 동작하는 함수이다.
 * @param {*} fileData 
 */
export let clearUploadedFile = function(fileData){
    $('#fileUploadForm')[0].reset();
    fileData.files = {};
    fileData.fileName = undefined;
    fileData.fileNameNoExt = undefined;
    fileData.validFile = false;
}

/**
 * 파일 업로드를 위한 함수.
 * ObjectSet_1_Provider 로 하드코딩 되어있으나, 사용 점을 생각해보면 문제 될 일은 없어보인다.
 * 향후 리팩토링 시 ObjectSet_1 대신 실제 테이블을 가져오는 다른 로직을 써야할 듯 함.
 * 
 * @param {*} fileData 
 */
export let uploadFile = async function(fileData){
    // uploadFileToDataset2 함수를 통해, Dataset을 반환받는다.
    let result = await uploadFileToDataset2(fileData);


    let selected = appCtxService.ctx.selected;
    let obj = appCtxService.ctx.xrtSummaryContextObject;
    //업로드 파일을 받은 데이터셋의 타입을 확인한다 
    let fileType = fileData.fileExt;
    fileType = fileType.toLowerCase();

    //IMAN_reference 로 할당할 지, IMAN_specification으로 할당 할 지를 결정하기 위해 데이터셋의 타입으로 구분한다.
    // ( promise를 반환받으므로, await 를 쓸거면 .then 을 쓰지 말고, 아니면 await를 뺄 것. )
    if(fileType == "bmp" || fileType == "jpg" || fileType ==  "png" || fileType ==  "gif"){
        await AwcObjectUtil.createRelation("IMAN_reference", selected, result).then( (res) => {
            eventBus.publish( 'cdm.relatedModified', {
                refreshLocationFlag: false,
                relatedModified: [obj]
            } );
            AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "uploadComp"));
            AwcPanelUtil.closeCommandPanel();
        });
    }else{
        await AwcObjectUtil.createRelation("IMAN_specification", selected, result).then( (res) => {
            eventBus.publish( 'cdm.relatedModified', {
                refreshLocationFlag: false,
                relatedModified: [obj]
            } );
            AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "uploadComp"));
            AwcPanelUtil.closeCommandPanel();
        });
    }

}

//recall uploaded file within "IMAN_specification"
export async function retrieveSpecFile(ctx, data){
    let selected = appCtxService.ctx.selected;

    let specFileName = selected.props.IMAN_specification.uiValues;
    let specFileUid = selected.props.IMAN_specification.dbValues;  
    let fileUid = null;
    let fileName = null;
    if (selected.props.IMAN_reference) {
        fileName = selected.props.IMAN_reference.displayValues;
        fileUid = selected.props.IMAN_reference.dbValues;
    }
  

    let mappedData = new Array();   //vmo
    let mappedData2 = new Array();   //vmo
    let fileData = new Array();     //array

    //viewmodel 
    mappedData = specFileName.map((elem, i)=>{
        return{
            name: specFileName[i],
            uid: specFileUid[i]
        };
    });
    if (fileName && fileUid) {
        mappedData2 = fileName.map((elem, i)=>{
            return{
                name: fileName[i],
                uid: fileUid[i]
            };
        });
    }
    
    //array
    for(const data of mappedData){
        fileData.push(
            createFileModelObjProp({
                propertyName: data.uid,
                displayName: data.name
            })
        );
    }
    if (fileName && fileUid) {
        for( const data2 of mappedData2 ) {
            fileData.push(
                createFileModelObjProp({
                    propertyName: data2.uid,
                    displayName: data2.name
                })
            );
        }
    }
    let specData = {
        retrievedFile: fileData,
        totalFound: fileData.length
    };

    appCtxService.registerCtx('specData', specData);
    return specData;
}

// let _getRelationType = ( prop ) => {

// }

//Create ViewModelObj
let createFileModelObjProp = function( mappedData ){
    let propertyDisplayName = mappedData.displayName;
    let propertyName = mappedData.propertyName;
    let viewProp = uwPropertyService.createViewModelProperty(propertyName, propertyDisplayName, 'BOOLEAN', [], []);

	uwPropertyService.setIsRequired(viewProp, false);
	uwPropertyService.setIsArray(viewProp, false);
	uwPropertyService.setIsNull(viewProp, false);
	uwPropertyService.setPropertyLabelDisplay(viewProp, 'PROPERTY_LABEL_AT_RIGHT');
    uwPropertyService.setReferenceType(viewProp)

    return viewProp;
}

function _uploadAndGetFile2() {
    var deferred = AwPromiseService.instance.defer();
    let formComponent = document.createElement("formData");
    formComponent.setAttribute("name", "");
    formComponent.setAttribute("type", "file");
    formComponent.setAttribute("accept", ".bmp, .jt, .cgm, .dwg, .dxf, .exp, .gif, .jpg, .xls, .xlsx, .ppt, .pptx, .doc, .docx, .mpp, .pdf, .asm, .dft, .par, .psm, .pwd, .tif, .txt, .zip, .mht, .avi, .swf, .mp4, .mkv, .mpg, .mpeg, .wmv, .mov, .csv, .alz" );
    let inputComponent = document.createElement("input");
    inputComponent.setAttribute("type", "file");
    inputComponent.setAttribute("name", "file_0");
    inputComponent.setAttribute("style", "display: block; visibility: hidden; width: 0; height: 0;");
    inputComponent.setAttribute("accept", ".bmp, .jt, .cgm, .dwg, .dxf, .exp, .gif, .jpg, .xls, .xlsx, .ppt, .pptx, .doc, .docx, .mpp, .pdf, .asm, .dft, .par, .psm, .pwd, .tif, .txt, .zip, .mht, .avi, .swf, .mp4, .mkv, .mpg, .mpeg, .wmv, .mov, .csv, .alz" );
    inputComponent.onchange = async function () {
        let file = inputComponent.files[0];
        if (file) {
            deferred.resolve(file);
        } else {
            deferred.reject(null);
        }
    }
    inputComponent.click();
    return deferred.promise;
}

/**
 * 
 * @param {*} result 
 * @param {*} file 
 */
function _uploadFile2(result, file) {
    let ticketURL = result.ticket;
    var deferred = AwPromiseService.instance.defer();
    var request = new XMLHttpRequest();

    var formData = new FormData();
    formData.append("fmsFile", file.files[0], file.fileName);
    formData.append("fmsTicket", ticketURL);
    request.onload = function () {
        if (this.status >= 200 && this.status < 300) {
            deferred.resolve(request.response);
        } else {
            deferred.reject({
                status: request.status,
                statusText: request.statusText
            });
        }
    };
    request.open("POST", document.location.origin + "/fms/fmsupload/", true);
    request.setRequestHeader("X-XSRF-TOKEN", _getCookieValue2("XSRF-TOKEN"));
    request.send(formData);
}

function _getCookieValue2 (key) {
    let cookieKey = key + "="; 
    let result = "";
    const cookieArr = document.cookie.split(";");
    
    for(let i = 0; i < cookieArr.length; i++) {
        if(cookieArr[i][0] === " ") {
            cookieArr[i] = cookieArr[i].substring(1);
        }
        if(cookieArr[i].indexOf(cookieKey) === 0) {
            result = cookieArr[i].slice(cookieKey.length, cookieArr[i].length);
            return result;
        }
    }
    return result;
}

/**
 * 
 * @param {*} file 
 */
function _createDatasets2(file) {
    let childName = "";
    let type = "";
    let isAscii = false; // 업로드 파일이 Ascii인지 체크한다.

    if (file) {
        if (file.fileName.includes(".")) {
            type = file.fileName.split(".")[file.fileName.split(".").length - 1];
            childName = file.fileName.slice(0, -(type.length + 1));
            file.ext = type;
            file.fileNameNoExt = childName;      //file.onlyname = childName
        }
    }

    const deferred = AwPromiseService.instance.defer();
    const selectedType = [];

    if ( file.ext === null || file.ext === undefined || file.ext === "" ) {
        return null;
    }

    type = file.ext.toLowerCase();

    // Image
    if ( type === "bmp" ) {
        selectedType.push( "Bitmap", "Bitmap", "Plain", "Image" );
    } else if ( type === "gif" ) {
        selectedType.push( "GIF", "GIF", "Plain", "GIF_Reference" );
    } else if ( type === "jpg" ) {
        selectedType.push( "JPEG", "JPEG", "Plain", "JPEG_Reference" );
    } else if ( type === "png" ) {
        selectedType.push( "Image", "Image", "Plain", "Image" );
    } else if ( type === "psd" ) {
        selectedType.push( "Photoshop", "Photoshop", "Plain", "Photoshop" );

    // Video
    } else if ( type === "avi" ) {
        selectedType.push( "Fnd0VideoData", "Fnd0VideoData", "Plain", "Fnd0AVI" );
    } else if ( type === "swf" ) {
        selectedType.push( "Fnd0VideoData", "Fnd0VideoData", "Plain", "Fnd0SWF" );
    } else if ( type === "mp4" ) {
        selectedType.push( "Fnd0VideoData", "Fnd0VideoData", "Plain", "Fnd0MP4" );
    } else if ( type === "mkv" || type === "mpg" || type === "mpeg" || type === "wmv" || type === "mov" ) {
        selectedType.push( "MISC", "MISC", "Plain", "MISC_BINARY" );

    // 3D Model, CAD...
    } else if ( type === "asm" ) {
        selectedType.push( "SE Assembly", "SE Assembly", "Plain", "SE-assembly" );
    } else if ( type === "cgm" ) {
        selectedType.push( "DrawingSheet", "DrawingSheet", "Plain", "Sheet" );
    } else if ( type === "dft" ) {
        selectedType.push( "SE Draft", "SE Draft", "Plain", "SE-draft" );
    } else if ( type === "dwg" ) {
        selectedType.push( "DWG", "DWG", "Plain", "DWG" );
    } else if ( type === "dxf" ) {
        selectedType.push( "DXF", "DXF", "Plain", "DXF" );
    }  else if ( type === "jt" ) {
        selectedType.push( "DirectModel", "DirectModel", "Plain", "JTPART" );
    } else if ( type === "par" ) {
        selectedType.push( "SE Part", "SE Part", "Plain", "SE-part" );
    } else if ( type === "psm" ) {
        selectedType.push( "SE SheetMetal", "SE SheetMetal", "Plain", "SE-sheetMetal" );
    } else if ( type === "pwd" ) {
        selectedType.push( "SE Weldment", "SE Weldment", "Plain", "SE-weldment" );
    } else if ( type === "tif" ) {
        selectedType.push( "TIF", "TIF", "Plain", "TIF_Reference" );
        
    // Compressed File
    } else if ( type === "zip" ) {
        selectedType.push( "Zip", "Zip", "Plain", "ZIPFILE" );
    } else if ( type === "alz" ) {
        selectedType.push( "Zip", "Zip", "Plain", "A2ALZ" );

    // Document
    } else if ( type === "doc" ) {
        selectedType.push( "MSWord", "MSWord", "Plain", "word" );
    } else if ( type === "docx" ) {
        selectedType.push( "MSWordX", "MSWordX", "Plain", "word" );
    } else if ( type === "mpp" ) {
        selectedType.push( "MSProject", "MSProject", "Plain", "Ms_Project_Doc" );
    } else if ( type === "pdf" ) {
        selectedType.push( "PDF", "PDF", "Plain", "PDF_Reference" );
    } else if ( type === "ppt" ) {
        selectedType.push( "MSPowerPoint", "MSPowerPoint", "Plain", "powerpoint" );
    } else if ( type === "pptx" ) {
        selectedType.push( "MSPowerPointX", "MSPowerPointX", "Plain", "powerpoint" );
    } else if ( type === "txt" ) {
        selectedType.push( "Text", "Text", "Plain", "Text" );
        isAscii = true;
    } else if ( type === "xls" ) {
        selectedType.push( "MSExcel", "MSExcel", "Plain", "excel" );
    } else if ( type === "xlsx" ) {
        selectedType.push( "MSExcelX", "MSExcels", "Plain", "excel" );
    } else if ( type === "csv" ) {
        selectedType.push( "MISC", "MISC", "Plain", "MISC_TEXT" );
    }

    let inputParam = {
        input: [{
            clientId: "0",
            name: file.fileName,
            type: selectedType[0],
            datasetFileInfos: [{
                clientId: "1",
                fileName: file.fileName,
                namedReferenceName: selectedType[3],
                isText: isAscii,
                allowReplace: true
            }]
        }]
    }
    soaService.post('Core-2010-04-DataManagement', 'createDatasets', inputParam).then((res) => {
        let result = {
            "modelObject": res.datasetOutput[0].dataset,
            "ticket": res.datasetOutput[0].commitInfo[0].datasetFileTicketInfos[0].ticket
        }
        deferred.resolve(result);
    }).catch( () => {
        AwcNotificiationUtil.show( "ERROR", locale.getLocalizedText( localeText, "wrongFile" ) );
    });
    return deferred.promise;
}

/**
 * 
 * @param {*} targetDataset 
 * @param {*} file 
 * @param {*} ticket 
 */
function _commitDatasetFiles2(targetDataset, file, ticket) {
    const deferred = AwPromiseService.instance.defer();
    const selectedType = [ ];

    if ( file.ext === null || file.ext === undefined || file.ext === "" ) {
        return null;
    }

    const type = file.ext.toLowerCase();

    // Image
    if ( type === "bmp" ) {
        selectedType.push( "Bitmap", "Bitmap", "Plain", "Image" );
    } else if ( type === "gif" ) {
        selectedType.push( "GIF", "GIF", "Plain", "GIF_Reference" );
    } else if ( type === "jpg" ) {
        selectedType.push( "JPEG", "JPEG", "Plain", "JPEG_Reference" );
    } else if ( type === "png" ) {
        selectedType.push( "Image", "Image", "Plain", "Image" );
    } else if ( type === "psd" ) {
        selectedType.push( "Photoshop", "Photoshop", "Plain", "Photoshop" );

    // Video
    } else if ( type === "avi" ) {
        selectedType.push( "Fnd0VideoData", "Fnd0VideoData", "Plain", "Fnd0AVI" );
    } else if ( type === "swf" ) {
        selectedType.push( "Fnd0VideoData", "Fnd0VideoData", "Plain", "Fnd0SWF" );
    } else if ( type === "mp4" ) {
        selectedType.push( "Fnd0VideoData", "Fnd0VideoData", "Plain", "Fnd0MP4" );
    } else if ( type === "mkv" || type === "mpg" || type === "mpeg" || type === "wmv" || type === "mov" ) {
        selectedType.push( "MISC", "MISC", "Plain", "MISC_BINARY" );

    // 3D Model, CAD...
    } else if ( type === "asm" ) {
        selectedType.push( "SE Assembly", "SE Assembly", "Plain", "SE-assembly" );
    } else if ( type === "cgm" ) {
        selectedType.push( "DrawingSheet", "DrawingSheet", "Plain", "Sheet" );
    } else if ( type === "dft" ) {
        selectedType.push( "SE Draft", "SE Draft", "Plain", "SE-draft" );
    } else if ( type === "dwg" ) {
        selectedType.push( "DWG", "DWG", "Plain", "DWG" );
    } else if ( type === "dxf" ) {
        selectedType.push( "DXF", "DXF", "Plain", "DXF" );
    }  else if ( type === "jt" ) {
        selectedType.push( "DirectModel", "DirectModel", "Plain", "JTPART" );
    } else if ( type === "par" ) {
        selectedType.push( "SE Part", "SE Part", "Plain", "SE-part" );
    } else if ( type === "psm" ) {
        selectedType.push( "SE SheetMetal", "SE SheetMetal", "Plain", "SE-sheetMetal" );
    } else if ( type === "pwd" ) {
        selectedType.push( "SE Weldment", "SE Weldment", "Plain", "SE-weldment" );
    } else if ( type === "tif" ) {
        selectedType.push( "TIF", "TIF", "Plain", "TIF_Reference" );
        
    // Compressed File
    } else if ( type === "zip" ) {
        selectedType.push( "Zip", "Zip", "Plain", "ZIPFILE" );
    } else if ( type === "alz" ) {
        selectedType.push( "Zip", "Zip", "Plain", "A2ALZ" );

    // Document
    } else if ( type === "doc" ) {
        selectedType.push( "MSWord", "MSWord", "Plain", "word" );
    } else if ( type === "docx" ) {
        selectedType.push( "MSWordX", "MSWordX", "Plain", "word" );
    } else if ( type === "mpp" ) {
        selectedType.push( "MSProject", "MSProject", "Plain", "Ms_Project_Doc" );
    } else if ( type === "pdf" ) {
        selectedType.push( "PDF", "PDF", "Plain", "PDF_Reference" );
    } else if ( type === "ppt" ) {
        selectedType.push( "MSPowerPoint", "MSPowerPoint", "Plain", "powerpoint" );
    } else if ( type === "pptx" ) {
        selectedType.push( "MSPowerPointX", "MSPowerPointX", "Plain", "powerpoint" );
    } else if ( type === "txt" ) {
        selectedType.push( "Text", "Text", "Plain", "Text" );
    } else if ( type === "xls" ) {
        selectedType.push( "MSExcel", "MSExcel", "Plain", "excel" );
    } else if ( type === "xlsx" ) {
        selectedType.push( "MSExcelX", "MSExcels", "Plain", "excel" );
    } else if ( type === "csv" ) {
        selectedType.push( "MISC", "MISC", "Plain", "MISC_TEXT" );
    }

    let inputParam = {
        commitInput: [{
            dataset: targetDataset,
            createNewVersion: true,
            datasetFileTicketInfos: [{
                datasetFileInfo: {
                    clientId: "1",
                    fileName: file.fileName,
                    namedReferencedName: selectedType[3],
                    isText: false,
                    allowReplace: true
                },
                ticket: ticket
            }]
        }]
    }
    soaService.post('Core-2006-03-FileManagement', 'commitDatasetFiles', inputParam).then((res) => {
        // let keys = Object.keys(res.modelObjects);
        // res = res.modelObjects[keys[0]];
        // deferred.resolve(res);
        let keys = Object.keys(res.modelObjects);
        for(const key of keys){
            if(AwcObjectUtil.instanceOf(res.modelObjects[key], "Dataset")){
                deferred.resolve(res.modelObjects[key]);
                return;
            }
        }
        deferred.resolve(null);
    });
    return deferred.promise;
}

/**
 * 
 * @param {*} file 
 */
export async function uploadFileToDataset2(file) {
    if (!file) {
        file = await _uploadAndGetFile2();
    }
    if (file) {
        let result = await _createDatasets2(file);
        _uploadFile2(result, file);
        let dataset = await _commitDatasetFiles2(result.modelObject, file, result.ticket);
        return dataset;
    }
    return null;
}

export let deleteFile = async ( data ) => {
    let obj = appCtxService.ctx.xrtSummaryContextObject;
    let selected = appCtxService.ctx.selected;
    let vmos = data.viewModelCollection.loadedVMObjects;
    let specUidArr = [];
    let refUidArr = [];
    vmos.forEach( ( vmo ) => {
        if( !Array.isArray( vmo.dbValue ) && vmo.dbValue ) {
            if( selected.props.IMAN_specification.dbValues.length > 0 ) {
                for( const uid of selected.props.IMAN_specification.dbValues ) {
                    if( vmo.propertyName == uid ) {
                        specUidArr.push( vmo.propertyName );
                    }
                }
            }
            if (selected.props.IMAN_reference) {
                if( selected.props.IMAN_reference.dbValues.length > 0 ) {
                    for( const uid of selected.props.IMAN_reference.dbValues ) {
                        if( vmo.propertyName == uid ) {
                            refUidArr.push( vmo.propertyName );
                        }
                    }
                }
            }
        }
    } );
    if( (specUidArr.length == 0 && refUidArr.length == 0) || (specUidArr.length == 0 &&!selected.props.IMAN_reference)) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "noSelected") );
        return false;
    }
    let specObjArr = [];
    let refObjArr = [];
    specUidArr.forEach( ( uid ) => {
        specObjArr.push( AwcObjectUtil.getObject( uid ) );
    } );
    refUidArr.forEach( ( uid ) => {
        refObjArr.push( AwcObjectUtil.getObject( uid ) );
    } );
    _deleteAttach( selected, specObjArr, "IMAN_specification" ).then( async () => {
        if (selected.props.IMAN_reference) {
            await _deleteAttach( selected, refObjArr, "IMAN_reference" );
        }
        eventBus.publish( 'cdm.relatedModified', {
            refreshLocationFlag: false,
            relatedModified: [obj]
        } );
        AwcPanelUtil.closeCommandPanel();
        
    });
}

let _deleteAttach = async ( pObj, delObjs, refType ) => {
    for( const obj of delObjs ) {
        let delRelInput = {
            input:
                [{
                    relationType: refType,
                    primaryObject: pObj,
                    secondaryObject: obj,
                    userData: { uid: 'AAAAAAAAAAAAAA', type: 'unknownType' }
                }]
        }
        soaService.post( 'Core-2006-03-DataManagement', 'deleteRelations', delRelInput ).then( async () => {
            await soaService.post( 'Core-2006-03-DataManagement', 'deleteObjects', { objects: [ obj ] } );
        } );
    }
}
export default exports = {
    openFilePanel,
    openFilePanel2,
    uploadFile,
    clearUploadedFile,
    retrieveSpecFile,
    deleteFile
};
app.factory('A2FileService', () => exports);