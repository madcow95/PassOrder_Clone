/**
 * QMSCommonService
 *
 * @module js/A2InspectionTemplateService
 */

import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import AwcPanelUtil from 'js/AwcPanelUtil';
import soaService from 'soa/kernel/soaService';
import uwPropertyService from 'js/uwPropertyService';
import viewModelService from 'js/viewModelService';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import locale from 'js/AwcLocalizationUtil';
import _ from 'lodash';
import $ from 'jquery';

let localeText = "lgspQmsNewInspectionMessages";
var exports = {};

/**
 * Array.sort의 매개변수에서 Sorting을 도와주는 함수
 * @param {*} property Object의 Property 명
 * @returns 
 */
function _dynamicSortProperty(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
        return result * sortOrder;
    }
}
/**
 * Array.sort 의 매개변수에서 Sorting을 도와주는 함수.
 * @param {*} property Teamcenter ModelObject의 Property 명
 * @returns 
 */
function _dynamicSortModelObject(property) {
    var sortOrder = 1;
    if(property[0] === "-") {
        sortOrder = -1;
        property = property.substr(1);
    }
    return function (a,b) {
        var result = (a["props"][property].uiValues[0] < b["props"][property].uiValues[0]) ? -1 : (a["props"][property].uiValues[0] > b["props"][property].uiValues[0]) ? 1 : 0;
        return result * sortOrder;
    }
}

/**
 * clearArr 에 담긴 속성들을 DeclView에서 초기화 시킨다.
 * @param {DeclView} data 
 * @param {Array<string>} clearArr - 클리어할 속성 명 
 */
let _LOVValueClear = ( data, clearArr ) => {
    clearArr.forEach( ( target ) => {
        uwPropertyService.setDisplayValue( data[ target ], [ "" ] );
        uwPropertyService.setWidgetDisplayValue( data[target], [ "" ] );
        uwPropertyService.setValue( data[ target ], [ "" ] );
    });
}

/**
 * 
 * @param {DeclView} data 
 * @param {*} disArr 
 * @param {*} target 
 */
let _setLOVDisplay = async ( data, disArr, target ) => {
    if( disArr.displayValues ) {
        disArr.displayValues = _.filter( disArr.displayValues, ( o ) => { return _.startsWith(o, "MP")} );
        disArr.sort(_dynamicSortProperty("displayValues"));
        for(let i = 0; i < disArr.displayValues.length; i++) {
            let listBoxRow = {
                "propDisplayValue": disArr.displayValues[i],
                "propDisplayDescription": disArr.displayValues[i],
                "dispValue": disArr.displayValues[i],
                "propInternalValue": disArr.dbValues[i],
                "iconName": "typeProductModelGroup48"
            };
            data[target].dbValue.push(listBoxRow);
        }
    } else {
        disArr = _.filter( disArr, ( o ) => { return o.type.includes("IP") || o.type.includes("PTP") || o.type.includes("IR")} );
        await AwcObjectUtil.getProperties( disArr, ["object_string", "a2IsDeleted"] );
        disArr = _.filter( disArr, ( o ) => { return o.props.a2IsDeleted.dbValues[0] === "NO"} );
        disArr.sort(_dynamicSortModelObject("object_string"));
        data[ target ].dbValue = data[ target ].dbValue.concat( disArr.map( ( obj ) => {
            return {
                "propDisplayValue": obj.props.object_string.dbValues[0],
                "propDisplayDescription": obj.props.object_string.dbValues[0],
                "dispValue": obj.props.object_string.dbValues[0],
                "propInternalValue": obj.uid,
                "iconName": "typeProductModelGroup48"
            }
        } ) );
        // for( const disTarget of disArr ) {
        //     let listBoxRow = {
        //         "propDisplayValue": disTarget.props.object_string.dbValues[0],
        //         "propDisplayDescription": disTarget.props.object_string.dbValues[0],
        //         "dispValue": disTarget.props.object_string.dbValues[0],
        //         "propInternalValue": disTarget.uid,
        //         "iconName": "typeProductModelGroup48"
        //     };
        //     data[target].dbValue.push( listBoxRow );
        // }
    }
}

export let onInit = ( data, ctx ) => {
    const interval = setInterval( async () => {
        if( ctx.xrtSummaryContextObject ) {
            if( data.objCreateInfo ) {
                clearInterval( interval );
                let IPSheetArr = [];
                await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "contents" );
                await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, 'a2OrgCode' );

                ctx.xrtSummaryContextObject.props.contents.dbValues.forEach( ( uid ) => {
                    IPSheetArr.push( AwcObjectUtil.getObject( uid ) );
                });
                if( IPSheetArr.length > 0 || data.objCreateInfo.createType == "A2QPartInspResultRuntime") {
                    _setLOVDisplay( data, IPSheetArr, "a2CheckSheetValues" );
                    LOVChanged( data, ctx );

                    if( data.objCreateInfo.createType == "A2QPartIPCheckItemRuntime" || data.objCreateInfo.createType == "A2QPartInspResultRuntime" ) {
                        data.a2ObjectName.isRequired = false;
                        data.a2OrgCode.uiValue = ctx.xrtSummaryContextObject.props.a2OrgCode.uiValue;
                        data.a2OrgCode.dbValue = ctx.xrtSummaryContextObject.props.a2OrgCode.dbValue;
                        data.a2OrgCode.valueUpdated = true;
                        uwPropertyService.setValue( data.a2ObjectName, "N/A" );
                        uwPropertyService.updateViewModelProperty( data.a2OrgCode );
                        uwPropertyService.setIsEnabled( data.a2OrgCode, false );
                    }
                }
                
            }
        }
    })
}

export let LOVChanged = ( data, ctx ) => {
    const interval = setInterval( () => {
        if( ctx.xrtSummaryContextObject ) {
            if( data.objCreateInfo ) {
                clearInterval( interval );
                let targetClass = document.getElementsByClassName( "aw-widgets-propertyContainer" );
                if( data.objCreateInfo.createType.includes( 'CheckItem' ) || data.objCreateInfo.createType == 'A2QPartInspResultRuntime' ) {
                    if( data.a2InsInputType.dbValues[0] != "Continuous") {
                        /**
                         * Todo display 공통 함수 만들어서 코드 줄이기
                         */
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "TargetValue" ) ) || target.innerText.includes( "LSL" ) || target.innerText.includes( "USL" ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "InitValue" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "ConDigit") ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "ConUnit" ) ) ) {
            
                                target.setAttribute( 'style', 'display:none;' );
                            }
                        }
                    } else {
                        data.a2TargetRange.hasLov = false;
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "TargetValue" ) ) || target.innerText.includes( "LSL" ) || target.innerText.includes( "USL" ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "InitValue" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "ConDigit" ) ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "ConUnit" ) ) ) {
                                    
                                target.setAttribute( 'style', 'display:"";' );
                            }
                        }
                        for( const target of targetClass ) {
                            if( data.a2TargetRange.dbValue ) {
                                if( !data.a2TargetRange.dbValue.includes( "USL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) ) {
                                        uwPropertyService.setValue( data.a2Usl, "" );
                                        target.setAttribute( 'style', 'display:none;' );
                                    } else {
                                        target.setAttribute( 'style', 'display:;' );
                                    }
                                } else if( !data.a2TargetRange.dbValue.includes( "LSL" ) && !data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                        uwPropertyService.setValue( data.a2Lsl, "" );
                                        target.setAttribute( 'style', 'display:none;' );
                                    } else {
                                        target.setAttribute( 'style', 'display:;' );
                                    }
                                } else if( data.a2TargetRange.dbValue.includes( "Target" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                        uwPropertyService.setValue( data.a2Usl, "" );
                                        uwPropertyService.setValue( data.a2Lsl, "" );
                                        target.setAttribute( 'style', 'display:none;' );
                                    }
                                } else if( data.a2TargetRange.dbValue.includes( "LSL" ) && data.a2TargetRange.dbValue.includes( "USL" ) ) {
                                    if( target.innerText.includes( locale.getLocalizedText( localeText, "a2Usl" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "a2Lsl" ) ) ) {
                                        target.setAttribute( 'style', 'display:;' );
                                    }
                                }
                            }
                        }
                        setTimeout( () => {
                            data.a2TargetRange.isRequired = true;
                            data.a2TargetRange.hasLov = true;
                        }, 200 );
                    }
                }
            }
        }
    })
}

export let a2CheckSheetLOVChanged = async ( data, ctx ) => {
    _LOVValueClear( data, [ "a2CheckGroup", "a2CheckSet" ] );
    data.a2CheckGroupValues.dbValue.splice(1, data.a2CheckGroupValues.dbValue.length);
    data.a2CheckSetValues.dbValue.splice(1, data.a2CheckSetValues.dbValue.length);
    let CheckSheet = await AwcObjectUtil.getObject( data.a2CheckSheet.dbValue );
    let CheckSheetArr = [];

    CheckSheet.props.contents.dbValues.forEach( ( uid ) => {
        CheckSheetArr.push( AwcObjectUtil.getObject( uid ) );
    })
    let type = null;
    const CheckGroupExistCheck = CheckSheetArr.some( obj => obj.type === "A2QProdIPCheckGroup" );
    if( CheckSheetArr.length > 0 && CheckGroupExistCheck )  {
        type = "a2CheckGroupValues";
    } else {
        data.a2CheckGroupValues.dbValue.splice(1, data.a2CheckGroupValues.dbValue.length);
        data.a2CheckSetValues.dbValue.splice(1, data.a2CheckSetValues.dbValue.length);
        type = "a2CheckSetValues";
    }
    _setLOVDisplay( data, CheckSheetArr, type );
}

export let a2CheckGroupLOVChanged = async ( data, ctx ) => {
    _LOVValueClear( data, [ "a2CheckSet" ] );
    data.a2CheckSetValues.dbValue.splice( 1, data.a2CheckSetValues.dbValue.length );

    if( data.a2CheckGroup.dbValue ) {
        let CheckGroup = await AwcObjectUtil.getObject( data.a2CheckGroup.dbValue );

        if( CheckGroup.type === "A2QProdIPCheckSet" ) {
            _LOVValueClear( data, [ "a2CheckGroup" ] );
            uwPropertyService.setDisplayValue( data.a2CheckGroup, [ CheckGroup.props.object_string.dbValues[0] ] );
            await AwcObjectUtil.getProperty( CheckGroup, "object_string" );

            setTimeout( () => {
                uwPropertyService.setValue( data.a2CheckSet, [ CheckGroup.uid ] );
                uwPropertyService.setDisplayValue( data.a2CheckSet, [ CheckGroup.props.object_string.dbValues[0] ] );
            }, 200 );
        } else {
            uwPropertyService.setDisplayValue( data.a2CheckGroup, [ CheckGroup.props.object_string.dbValues[0] ] );
            let CheckGroupArr = [];
            CheckGroup.props.contents.dbValues.forEach( ( uid ) => {
                CheckGroupArr.push( AwcObjectUtil.getObject( uid ) );
            } );
            _setLOVDisplay( data, CheckGroupArr, "a2CheckSetValues" );
        }
    } else {
        data.a2CheckSetValues.dbValue.splice( 1, data.a2CheckSetValues.dbValue.length );
        _LOVValueClear( data, [ "a2CheckSet" ] );
    }
}

export default exports = {
    onInit,
    a2CheckSheetLOVChanged,
    a2CheckGroupLOVChanged,
    LOVChanged
};
app.factory('A2InspectionPlanService', () => exports);