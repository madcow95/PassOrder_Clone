/**
 * QMSCommonService
 *
 * @module js/A2InspectionTemplateService
 */

 import app from 'app';
 import AwcObjectUtil from 'js/AwcObjectUtil';
 import eventBus from 'js/eventBus';
 import viewModelObjectSvc from 'js/viewModelObjectService';
 import AwcQueryUtil from 'js/AwcQueryUtil';
 import AwcPanelUtil from 'js/AwcPanelUtil';
 import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
 import locale from 'js/AwcLocalizationUtil';
 import soaService from 'soa/kernel/soaService';
 import uwPropertyService from 'js/uwPropertyService';
 import AwcPageUtil from 'js/AwcPageUtil';
 import viewModelService from 'js/viewModelService';
 
 var exports = {};
 let localeText = "lgspQmsNewInspectionMessages";
 
 let _LOVValueClear = ( data, clearArr ) => {
     clearArr.forEach( ( target ) => {
         uwPropertyService.setDisplayValue( data[target], [ "" ] );
         uwPropertyService.setWidgetDisplayValue( data[target], [ "" ] );
         data[target].dbValue = "";
     })
 }
 
 let _setLOVDisplay = async ( data, disArr, target ) => {
     if( disArr.displayValues ) {
         for(let i = 0; i < disArr.displayValues.length; i++) {
             var listBoxRow = {
                 "propDisplayValue": disArr.displayValues[i],
                 "propDisplayDescription": disArr.displayValues[i],
                 "dispValue": disArr.displayValues[i],
                 "propInternalValue": disArr.dbValues[i],
                 "iconName": "typeProductModelGroup48"
             };
             data[target].dbValue.push(listBoxRow);
         }
     } else {
         for( const disTarget of disArr ) {
             await AwcObjectUtil.getProperty( disTarget, "object_name" );
             var listBoxRow = {
                 "propDisplayValue": disTarget.props.object_string.dbValues[0],
                 "propDisplayDescription": disTarget.props.object_name.dbValues[0],
                 "dispValue": disTarget.props.object_string.dbValues[0],
                 "propInternalValue": disTarget.uid,
                 "iconName": "typeProductModelGroup48"
             };
             data[target].dbValues.push( listBoxRow );
         }
     }
 }
 
export let onInit = async ( data, ctx ) => {
    const interval = setInterval( async () => {
        if( ctx.xrtSummaryContextObject ) {
            if( data.objCreateInfo ) {
                clearInterval( interval );
                let IPSheetArr = [];
                await AwcObjectUtil.getProperty( ctx.xrtSummaryContextObject, "contents" );
                ctx.xrtSummaryContextObject.props.contents.dbValues.forEach( ( uid ) => {
                    IPSheetArr.push( AwcObjectUtil.getObject( uid ) );
                });
                if( IPSheetArr.length > 0 ) {
                    _setLOVDisplay( data, IPSheetArr, "a2PartCheckSheetValues" );
                    LOVChanged( data, ctx );
                }
            }
        }
    })
 }
 
export let LOVChanged = ( data, ctx ) => {
    const interval = setInterval( () => {
        if( ctx.xrtSummaryContextObject ) {
            if( data.objCreateInfo ) {
                clearInterval( interval );
                let targetClass = document.getElementsByClassName( "aw-widgets-propertyContainer" );
                if( data.objCreateInfo.createType.includes( 'CheckItem' ) ) {
                    if( data.a2InsInputType.dbValues[0] != "Continuous") {
                        /**
                         * Todo display 공통 함수 만들어서 코드 줄이기
                         */
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "TargetValue" ) ) || target.innerText.includes( "LSL" ) || target.innerText.includes( "USL" ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "InitValue" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "ConDigit") ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "ConUnit" ) ) ) {
            
                                target.setAttribute( 'style', 'display:none;' );
                            }
                        }
                    } else {
                        for( const target of targetClass ) {
                            if( target.innerText.includes( locale.getLocalizedText( localeText, "TargetValue" ) ) || target.innerText.includes( "LSL" ) || target.innerText.includes( "USL" ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "InitValue" ) ) || target.innerText.includes( locale.getLocalizedText( localeText, "ConDigit" ) ) ||
                                target.innerText.includes( locale.getLocalizedText( localeText, "ConUnit" ) ) ) {
                                    
                                target.setAttribute( 'style', 'display:"";' );
                            }
                        }
                    }
                }
            }
        }
    })
}
 
 export default exports = {
     onInit
 };
 app.factory('A2InspectionPlanService', () => exports);