/**
 * QMSCommonService
 *
 * @module js/A2InspectionTemplateService
 */

import app from 'app';
import AwcObjectUtil from 'js/AwcObjectUtil';
import eventBus from 'js/eventBus';
import AwcPanelUtil from 'js/AwcPanelUtil';
import AwcNotificiationUtil from 'js/AwcNotificiationUtil';
import soaService from 'soa/kernel/soaService';
import appCtxService from 'js/appCtxService';
import locale from 'js/AwcLocalizationUtil';
import uwPropertyService from 'js/uwPropertyService';
import viewModelService from 'js/viewModelService';
import viewModelObjectSvc from 'js/viewModelObjectService';
import AwcQueryUtil from 'js/AwcQueryUtil';
import AwPromiseService from 'js/awPromiseService';

var exports = {};
let localeText = "lgspQmsNewInspectionMessages";

/**
 *검사결과생성 
 */
export let A2QProdIRCreateAction = (data, ctx) => {
    // cosole.log(ctx.selected);
    AwcPanelUtil.openCommandPanel( "A2QProdIRCreateRuntime" );
}

export let a2InspectionResultOpen = async (data, ctx) => {
    let tenantID = ctx.preferences.A2_SITE_TENANT_ID[0];

    let selected = appCtxService.ctx.selected;
    //validation추가. 생성, 대기 완료일때 검색 의뢰 결과창X
    
    if( !selected.props.a2Status ) {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "SPCNoSelectResult"));
        return false;
    }
    let myStatus = selected.props.a2Status.dbValue;
    if ( myStatus == "Create" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidCreateStatus"));
    } else if ( myStatus == "Stand By" ){
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidStandStatus"));
    } else if ( myStatus == "Reject" ){
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "invalidRejectStatus"));
    } else {

        // LG 이노텍인 경우
        if(tenantID === "L1300" && selected.type == "A2QPartIRItemRevision"){
            // SCS 4M 초품 Check
            // 부품 검사 의뢰 a2SCS4MNo 속성값이 존재하는 SCS 4M 대상으로 판단.
            await AwcObjectUtil.getProperties(ctx.selected, ["a2SCS4MNo","a2InspItemList","a2SCS4MChecked"]);
            let scs4MNo = ctx.selected.props.a2SCS4MNo.dbValues[0];
            let scs4MCheck = ctx.selected.props.a2SCS4MChecked.dbValues[0];

            // a2SCS4MChecked 값이 Null(4M Check 1번만 수행 해야 함), a2SCS4MNo 값이 존재하는 경우 SCS 4M Check Confirm 기능 수행
            if(scs4MNo && !scs4MCheck)
            {
                await AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "4MConfirmCheck"), ["Yes", "No"], [
                    //YES button function
                    async function () {
                        await AwcObjectUtil.setProperty(ctx.selected, "a2SCS4MChecked",  "true" );

                        // 검사결과가 존재하지 않으면 의뢰 Header만 생성된 개체이므로 검사 기준을 바탕으로 검사결과를 복제 후 검사결과 입력 창으로 이동
                        if( !ctx.selected.props.a2InspItemList.dbValues[0] ){
                            await AwcObjectUtil.setProperty(ctx.selected, "a2EventProperty",  "DRIVESUBITEMS" );
                        }

                        AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);


                        // let a2InspItemList = AwcObjectUtil.getObjects(ctx.selected.props.a2InspItemList.dbValue);
                        // let aaa = a2InspItemList.map(obj => ctx.selected.props.a2InspItemList.dbValues[0]);

                    },
                    //NO button function
                    async function () {
                        await AwcObjectUtil.setProperty(ctx.selected, "a2SCS4MChecked",  "false" );

                        // 검사결과가 존재하지 않으면 의뢰 Header만 생성된 개체이므로 합격 상태로 변경 후 자동 Release 처리
                        if( !ctx.selected.props.a2InspItemList.dbValues[0] ){
                            await AwcObjectUtil.setProperty(ctx.selected, "a2Result",  "OK" );
                            _inspectionRequestHeaderRelease(ctx);                  
                        }else{
                            AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);            
                        }

                    }
                ]);

            }else{
                AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);            
            }
        }else{
            AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);            
        }

        
    }
 }


 let _inspectionRequestHeaderRelease = ( ctx ) => { 


    let soaInputParam = {
        name: "[QMS] Inspection Header Release",
        description: " ",
        contextData:{
            attachmentCount : 1,
            attachments: [ctx.selected.uid],
            processTemplate : "[QMS] Inspection Header Release",
            attachmentTypes : [1],
        }
    }
    soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( async (e)=>{
        
    }).catch( (e) => {
        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "IRConfirmFailed") +"\n"+e.message);
    }).finally( async () => {
        eventBus.publish('cdm.relatedModified', {
            refreshLocationFlag: true,
            relatedModified: [ctx.selected]
        });
    }); 
}


export let A2QProdIRCreateItem = async (data, ctx, type) => {
    let createType = data.objCreateInfo.createType;       //A2QProdIRCreateRuntime
    
    let a2ModelSuffix = data.a2ModelSuffix.dbValue;        
    let a2InspectionPlan = data.a2InspectionPlan.dbValue;       //검사 기준
    let a2RequestType = data.a2RequestType.dbValue;

    let inspectionPlan = await AwcObjectUtil.loadObjects(a2InspectionPlan);
    await AwcObjectUtil.getProperties(inspectionPlan, ["a2ModelSuffix", "a2InspTypeName", "a2TemplateType", "a2SeverityLevel", "a2BasedOnId"], true)
    let inspTypeName = inspectionPlan.props.a2InspTypeName.dbValues[0] ? inspectionPlan.props.a2InspTypeName.dbValues[0] : "";
    let basedOnId = inspectionPlan.props.a2BasedOnId.dbValues[0];
    let templateType = basedOnId.substring(0, basedOnId.indexOf("/"));
    
    AwcObjectUtil.createRuntimeObject(
        [
            {a2ModelSuffix: data.a2ModelSuffix.dbValue ? data.a2ModelSuffix.dbValue : ""}, 
            {a2TemplateType: templateType},
            {a2InspTypeName: inspTypeName},
            {a2InspectionPlan: a2InspectionPlan},
            {a2RequestName: "[" +  inspTypeName +"]" + " " + a2ModelSuffix + " 검사의뢰"},
            {a2RequestType: a2RequestType},
            {a2ProgramPlan: data.a2ProgramPlan.dbValue ? data.a2ProgramPlan.dbValue : ""}
        ],
        createType
    ).then( async () => {
        //추가 예외처리 필요
        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRCreateRuntimeSuc"));
        AwcPanelUtil.closeCommandPanel();
        
        let viewModelElement = document.getElementById('inspectionRequestHeader');
        let viewModel = viewModelService.getViewModelUsingElement(viewModelElement);   //테이블명으로 vmo 가져오기
        // cosole.log(viewModel);
        //a2InspectionRequestSearch(viewModel, ctx, false);
    }).catch( (e) => {
        // cosole.log(e);
    })

}

function leftPad(value) { if (value >= 10) { return value; } return `0${value}`; } function toStringByFormatting(source, delimiter = '-') { const year = source.getFullYear(); const month = leftPad(source.getMonth() + 1); const day = leftPad(source.getDate()); return [year, month, day].join(delimiter); }

 /**
  * events to show either yes or no. created to display alerts only once.
  */
 const EventEmitter = require('events');
 const myEvent = new EventEmitter();

 myEvent.on('YES', () => {
     //AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRSuc"));
     // cosole.log("search comp");
 });

 myEvent.on('NO', () => {
    //AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "IRNoConditionMet"));
    // cosole.log("no condition met")
});

/**
 * 검색 의뢰 결과 팝업. OOTB가 제공해주는 닫기 버튼 실행 X
 */
export let A2QIR = (data, ctx) => {
    // cosole.log("검색의뢰결과 클릭");
    AwcPanelUtil.openPopup("A2InspectionResult", "Inspection Result", screen.width - 100, screen.height - 200, true, true, true);
}

//SPC 조회
export function A2QSPCReferenceAction(data, ctx){
    // cosole.log("1");
    if (ctx.selected.type === "A2QProdInspectionResult" || ctx.selected.type === "A2QPartInspectionResult") {
        AwcPanelUtil.openPopup("A2InspectionSPCPopup", "SPC", "1400", "800", true, false, true).then(() => {
        });
    } else {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "SPCNoSelectResult")); 
    }
}

let createFileModelObjProp = function(myData){
    let propertyDisplayName = myData.displayName;
    let propertyName = myData.propertyName;
    let viewProp = uwPropertyService.createViewModelProperty(propertyName, propertyDisplayName, 'BOOLEAN', [], []);

	uwPropertyService.setIsRequired(viewProp, false);
	uwPropertyService.setIsArray(viewProp, false);
	uwPropertyService.setIsNull(viewProp, false);
	uwPropertyService.setPropertyLabelDisplay(viewProp, 'PROPERTY_LABEL_AT_RIGHT');
    uwPropertyService.setWidgetDisplayValue(viewProp, [propertyDisplayName]);
	uwPropertyService.setValue(viewProp, false);

    return viewProp;
}

//open Serial Btn
export async function A2QSNReferenceAction(data, ctx){
    // cosole.log("S/N");
    if (ctx.selected.type === "A2QProdInspectionResult" || ctx.selected.type == "A2QPartInspectionResult" || ctx.selected.type == "A2QProdPTResult" || ctx.selected.type == "A2QPartPTResult") {
        await A2QSNReference();
        AwcPanelUtil.openCommandPanel("A2QInspectionRequestSerial");
    } else {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "serialNoSelect")); 
    }
}

//Retrieve Serial Data
export async function A2QSNReference(){
    let selected = appCtxService.ctx.selected;

    let sheetUid = selected.props.a2CheckSheetObject.dbValues;  //selected.uid

    // cosole.log(sheetUid);

    if(sheetUid == ""){
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "noCheckSheetVal"));
        setTimeout(() => {
            AwcPanelUtil.closeCommandPanel();
        }, (100));
        return;
    }

    let sheetModelObj = await AwcObjectUtil.loadObjects(sheetUid);
    let id = sheetModelObj.props.a2Id.dbValues[0];
    let revId = sheetModelObj.props.a2RevId.dbValues[0];

    const res = await AwcQueryUtil.executeSavedQuery("_Inspection_getSerial", ["A2CheckSheetId", "A2CheckSheetRevId"], [id, revId]);
    let serialData = new Array();
    if(res){
        await AwcObjectUtil.getProperties(res, ["a2SerialNumber", "a2IsDeleted"], true);
        for (const queryResult of res) {
            if(queryResult.props.a2SerialNumber.dbValues[0] == null){
                queryResult.props.a2SerialNumber.dbValues[0] = " ";
            }
            serialData.push({
                seq: queryResult.props.object_name.dbValues[0],
                serial: queryResult.props.a2SerialNumber.dbValues[0],
                uid: queryResult.uid    //needs uid for VMO
            });
        }
        serialData.sort((a,b) => a.seq > b.seq ? 1 : -1);
    }

    //arr -> view model property
    let serialVMO = new Array();
    for(const data of serialData){
        serialVMO.push(
            createFileModelObjProp({
                propertyName: data.serial,
                displayName: data.seq,
                dbValue: [data.uid]
            })
        );
    }

    let serialData2 = {
        retrievedFile: serialVMO,
        totalFound: serialVMO.length,
    };

    appCtxService.registerCtx('serialData2', serialData2);

    return serialData2;
}

//display Serial Number
export function displaySerialNumber(data, ctx, serialData2){
    var deferred = AwPromiseService.instance.defer();

    let selected = ctx.selected;

    let list = [];
    for(let i = 0; i < serialData2.length; i++){
        if(serialData2[i].propertyName == " "){
            list.push(serialData2[i].propertyDisplayName + serialData2[i].propertyName);
        }else {
            list.push(serialData2[i].propertyDisplayName + ":" + serialData2[i].propertyName);
        }
    }

    let res = [];
    for(const data of list) {
        res.push(createFileModelObjProp({
            propertyName: data,
            displayName: data
        }));
    }

    var outputData = {
        searchResults: res,
        totalFound: res.length
    };

    if (res.length) {
        data.isSerials = true;
    }
    deferred.resolve(outputData);

    return deferred.promise; 
}

function _dynamicSort2(property1, property2) {
    var sortOrder = 1;
    if(property1[0] === "-") {
        sortOrder = -1;
        property1 = property1.substr(1);
    }
    return function (a,b) {
        /* next line works with strings and numbers, 
         * and you may want to customize it to your needs
         */
        var result = (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  < b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? -1 : (a["props"][property1].uiValues[0] + "/" + a["props"][property2].uiValues[0]  > b["props"][property1].uiValues[0] + "/" + b["props"][property2].uiValues[0] ) ? 1 : 0;
        return result * sortOrder;
    }
}


export function A2QProdIRCreateRuntimePreAction(data, ctx) {
    if(data.a2InspectionPlan == null){
        setTimeout( () => {
            A2QProdIRCreateRuntimePreAction(data, ctx);
        }, 10 );
    }else{
        data.a2InspectionPlan = data.a2InspectionPlanListBox;
        document.getElementById("requestCreateListBox").setAttribute("style", "visibility: hidden;");
        ctx.a2InspectionPlanListBoxValues = {
            "type": "STRING",
            "dbValue": [{
                "propDisplayValue": "",
                "propDisplayDescription": "",
                "dispValue": "",
                "propInternalValue": "",
                "iconName": ""
            }]
        };
    }
}

let _getLatestRev = async ( rev ) => {
    let itemsUidArrSet = new Set( rev );
    let itemsUidArr = [...itemsUidArrSet]
    let itemsArr = new Array();
    let returnArr = new Array();

    itemsUidArr.forEach( ( uid ) => {
        itemsArr.push( AwcObjectUtil.getObject( uid ) );
    });

    await AwcObjectUtil.getProperty( itemsArr, "revision_list" );
    itemsArr.forEach( ( item ) => {
        let arrIndex = item.props.revision_list.dbValues.length > 1 ? item.props.revision_list.dbValues.length - 2 : item.props.revision_list.dbValues.length - 1;
        returnArr.push( AwcObjectUtil.getObject( item.props.revision_list.dbValues[ arrIndex ] ) );
    });
    return returnArr;
}

export function A2ModelSuffixChanged(data, ctx) {
    uwPropertyService.setDisplayValue( data.a2ModelSuffix, [ data.a2ModelSuffix.dbValues[0] + "/" + data.a2ModelSuffix.selectedLovEntries[0].propDisplayDescription ] );
    uwPropertyService.setWidgetDisplayValue( data.a2ModelSuffix, [ data.a2ModelSuffix.dbValues[0] + "/" + data.a2ModelSuffix.selectedLovEntries[0].propDisplayDescription ] );
    ctx.a2InspectionPlanListBoxValues = {
        "type": "STRING",
        "dbValue": [{
            "propDisplayValue": "",
            "propDisplayDescription": "",
            "dispValue": "",
            "propInternalValue": "",
            "iconName": ""
        }]
    };
    //data.a2RequestName = data.a2ObjectName;
    AwcQueryUtil.executeSavedQuery("_Inspection_getInspectionPlan", 
        ["a2SearchModelSuffixRT"], 
        [data.a2ModelSuffix.dbValue]
    ).then( async (results) => {
        if(results) {
            let LastedRevArr = [];
            await AwcObjectUtil.getProperties(results, ["release_status_list", "a2LatestYNRT"], true);
            let sortedArray = [];
            for (const sortElement of results) {
                if( sortElement.type != "A2QProdIPItemRevision" || sortElement.props.a2IsDeleted.dbValues[0] == "YES") continue;
                if( sortElement.props.release_status_list.dbValues.length > 0 ) sortedArray.push(sortElement.props.items_tag.dbValues[0]);
            }
            LastedRevArr = await _getLatestRev( sortedArray );
            LastedRevArr.sort(_dynamicSort2("item_id", "item_revision_id"));
            // cosole.log({LastedRevArr});
            for (const modelObject of LastedRevArr) {
                let vmo = viewModelObjectSvc.constructViewModelObjectFromModelObject(modelObject);
                let displayString = vmo.props.item_id.dbValues[0] + "/" + vmo.props.item_revision_id.dbValues[0];
                var listBoxRow = {
                    "propDisplayValue": displayString,
                    "propDisplayDescription": vmo.props.object_name.dbValues[0],
                    "dispValue": displayString,
                    "propInternalValue": vmo.uid,
                    "iconName": "typeQcControlInspectionPlan48"
                };
                ctx.a2InspectionPlanListBoxValues.dbValue.push(listBoxRow);
            }
            return;
        }
    });
}

export function A2InspectionRequestConfirm(data, ctx) {
    let selected = ctx.selected;
    if( selected.type != "A2QProdIRItemRevision" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "IRTypeInvalid"));
        return;
    }
    if( selected.props.a2Status.dbValues[0] != "Receipt" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "IRStatusInvalid"));
        return;
    }
    if( selected.props.a2Result.dbValues[0] != "OK" && selected.props.a2Result.dbValues[0] != "NG" ) {
        AwcNotificiationUtil.show("WARNING", locale.getLocalizedText(localeText, "IRResultInvalid"));
        return;
    }
    AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRConfirmCheck"), ["YES", "NO"], 
    [
        function() {
            AwcObjectUtil.getProperty(ctx.selected, "HasParticipant").then( () => {
                if(ctx.selected.props.HasParticipant.dbValues.length > 0) {
                    let soaInputParam = {
                        name: "[QMS] Confirm Inspection Request",
                        description: " ",
                        contextData:{
                            attachmentCount : 1,
                            attachments: [ctx.selected.uid],
                            processTemplate : "[QMS] Confirm Inspection Request",
                            attachmentTypes : [1],
                        }
                    }
                    soaService.post( 'Workflow-2008-06-Workflow', 'createInstance', soaInputParam ).then( (e)=>{
                        AwcNotificiationUtil.show("INFO", locale.getLocalizedText(localeText, "IRConfirmSuccess"));
                        // cosole.log(e);
                    }).catch( (e) => {
                        AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "IRConfirmFailed") +"\n"+e.message);
                    }).finally( () => {
                        eventBus.publish('cdm.relatedModified', {
                            refreshLocationFlag: true,
                            relatedModified: [ctx.selected]
                        });
                        return;
                    }); 
                } else {
                    AwcNotificiationUtil.show("ERROR", locale.getLocalizedText(localeText, "IRConfirmFailed") +"\nThere's no participants in this inspection request.");
                    return;
                }
            })
        },
        function() {
            AwcPanelUtil.closeCommandPanel();
            AwcPanelUtil.closePopup();
        }
    ]);
    return;
}

export function A2QProdIRItemRevisionRelease(data, ctx) {
    
}

export default exports = {
    a2InspectionResultOpen,
    A2QProdIRCreateAction,
    A2QProdIRCreateItem,
    A2QIR,
    A2QSNReferenceAction,
    A2QSPCReferenceAction,
    A2QProdIRCreateRuntimePreAction,
    A2ModelSuffixChanged,
    A2InspectionRequestConfirm,
    A2QSNReference,
    displaySerialNumber,
};
app.factory('A2InspectionRequestService', () => exports);